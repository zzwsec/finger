﻿-- utf-8

-- 域
domain = "/p8-dev"
-- 本地地址
ip = "10.46.97.42"
-- 端口
port = 3340
-- 地址
server = string.format("tcp://0.0.0.0:%d", port)
-- 互联互通
cluster = string.format("tcp://%s:%d", ip, port)
-- 线程数
thread = 8
-- 日志配置
logger = "etc/server.log.ini"
-- 时间偏移量
time_offset = 0
-- 时区
time_zone = 8

-- 服务发现
discovers = {
    "tcp://10.46.97.42:2881",
    "tcp://10.46.97.42:2882",
    "tcp://10.46.97.42:2883",
}

game_db = {
    ["host"] = "127.0.0.1",
    ["user"] = "root",
    ["password"] = "1xBSKI7#*6QRdv",
    ["name"] = "open_game_1",
}

-- 组编号
group_id = 1
-- 区域编号
area_id = 1

-- 游戏服务
game_index_num = 2
-- kingnet回调地址
pay_notify_url = "http://127.0.0.1:8088/p8/api/callback_kingnet.php"

require("etc/services")
require("etc/zones")
require("etc/server")