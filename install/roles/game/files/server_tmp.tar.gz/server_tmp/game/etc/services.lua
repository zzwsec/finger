-- 服务列表
services = {
    activitys = {},
    caves = {},
    crossbosss = {},
    games = {},
    guilds = {},
    gpvps = {},
    mails = {},
    matchs = {},
    players = {},
    pvps = {},
    pvp_ladders = {},
    ranks = {},
}