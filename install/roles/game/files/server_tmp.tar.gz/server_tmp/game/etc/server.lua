﻿-- utf-8

-- 构造服务参数
local function make_options(f, list, ...)
    if list then
        f(list, ...)
    end
end

-- 小区列表
local zone_ids
if zones and area_id then
    zone_ids = zones[area_id]
end

-- 帐号服务
make_options(table.insert, services.accounts, {
    ["domain"] = domain,
    ["db_thread_num"] = 4,
    ["mysql_options"] = account_db,
    ["max_coroutine_num"] = 1000,
})

-- 活动服务
make_options(table.insert, services.activitys, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["script_main"] = "lua/activity/main.lua",
    ["script_path"]= "./lua/?.lua",
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["pre_load_limit"] = 100, 
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["mysql_options"] = game_db,
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 权限服务
make_options(table.insert, services.auths, {
    ["domain"] = domain,
    ["db_thread_num"] = 4,
    ["mysql_options"] = account_db,
    ["max_coroutine_num"] = 1000,
    ["invite_only"] = invite_only,
})

-- 批量邮件服务
make_options(table.insert, services.batchmails, {
    ["domain"] = domain,
    ["db_thread_num"] = 4,
    ["mysql_options"] = common_db,
})


-- 神秘洞窟服务
make_options(table.insert, services.caves, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["script_main"] = "lua/cave/main.lua",
    ["script_path"] = "./lua/?.lua",
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["pre_load_limit"] = 100, 
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["player_cache_time"] = 10 * 60,
    ["check_timeout"] = 1 * 60,
    ["mysql_options"] = game_db,
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 中心服务
make_options(table.insert, services.centers, {
    ["domain"] = domain,
    ["pay_bind_address"] = center_pay_bind_address,
    ["pay_serial_url"] = center_pay_serial_url,
    ["pay_gen_url"] = center_pay_gen_url,
    ["pay_check_url"] = center_pay_check_url,
})

-- 跨服boss服务
make_options(table.insert, services.crossbosss, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["script_main"] = "lua/crossboss/main.lua",
    ["script_path"] = "./lua/?.lua",
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["pre_load_limit"] = 100,
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["player_cache_time"] = 10 * 60,
    ["check_timeout"] = 1 * 60,
    ["mysql_options"] = game_db,
    ["collect_garbage_timeout"] = 1 * 60,
})
-- 好友服务
make_options(table.insert, services.friends, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["db_thread_num"] = 4,
    ["pre_load_limit"] = 100,
    ["mysql_options"] = game_db,
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["max_coroutine_num"] = 1000,
})

-- 游戏服务
local function make_game_options(games, zone_id, zone_index)
    table.insert(games, {
        ["domain"] = domain,
        ["group_id"] = group_id,
        ["area_id"] = area_id,
        ["zone_id"] = zone_id,
        ["zone_ids"] = zone_ids,
        ["zone_index_num"] = game_index_num,
        ["zone_index"] = zone_index,
        ["proto_path"] = "proto/nn_app_service_proto.pb",
        ["script_main"] = "lua/game/main.lua",
        ["script_path"]= "./lua/?.lua",
        ["profile_enable"] = true,
        ["profile_print_timeout"] = 1 * 60,
        ["profile_print_num"] = 20,
        ["collect_garbage_timeout"] = 1 * 60,
        ["max_player_num"] = 5000,
        ["player_max_coroutine_num"] = 100,
        ["player_heartbeat_timeout"] = 2 * 60,
        ["player_token_timeout"] = 2 * 60,
        ["player_cache_timeout"] = 5 * 60,
        ["player_gate_timeout"] = 1 * 60,
        ["event_max_coroutine_num"] = 1000,
        ["friends_max_coroutine_num"] = 1000,
        ["log_max_coroutine_num"] = 100,
        ["log_batch_record_num"] = 100,
        ["dump_zone_loads_timeout"] = 5 * 60,
        ["battle_report_address"] = battle_report_address,
        ["pay_notify_url"] = pay_notify_url,
    })
end
local function make_games(games, zones, area_id)
    for _, zone_id in pairs(zones[area_id]) do
        for zone_index = 0, game_index_num - 1 do
            make_game_options(games, zone_id, zone_index)
        end
    end
end
make_options(make_games, services.games, zones, area_id)

-- 网关服务
make_options(table.insert, services.gates, {
    ["domain"] = domain,
    ["group_id"] = group_id,
    ["bind_address"] = gate_bind_address,
    ["extern_address"] = {
        gate_extern_address,
    },
    ["max_connection_num"] = 5000,
    ["handshake_timeout"] = 5,
    ["downstream_timeout"] = 5 * 60,
    ["report_load_timeout"] = 30,
    ["time_zone"] = time_zone,
})

-- Gm服务
make_options(table.insert, services.gms, {
    ["domain"] = domain,
    ["bind_address"] = gm_bind_address,
    ["script_main"] = "lua/gm/main.lua",
    ["script_path"]= "./lua/?.lua",
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 公会服务
make_options(table.insert, services.guilds, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["script_path"]= "./lua/?.lua",
    ["script_main"] = "lua/guild/main.lua",
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["load_limit"] = 500, 
    ["check_timeout"] = 10,
    ["guild_cache_time"] = 60 * 60,
    ["guild_cache_size"] = 100,
    ["log_max_coroutine_num"] = 100,
    ["log_batch_record_num"] = 100,
    ["mysql_options"] = game_db,
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 登录服务
make_options(table.insert, services.logins, {
    ["domain"] = domain,
    ["bind_address"] = login_bind_address,
    ["apis"] = {
        ["default"] = "http://127.0.0.1:80",
    },
    ["verify_url"] = login_verify_url,
    ["player_limit"] = login_player_num,
    ["online_player_limit"] = login_online_player_num,
    ["verify_token_exp"] = 60 * 60,
    ["white_list_cfg"] = login_white_list_cfg,
    ["limit_create_cfg"] = login_limit_create_cfg,
})

-- 邮件服务
make_options(table.insert, services.mails, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["db_thread_num"] = 4,
    ["mysql_options"] = game_db,
    ["max_coroutine_num"] = 1000,
})

-- 匹配服务
make_options(table.insert, services.matchs, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["pre_load_limit"] = 100, 
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["player_cache_time"] = 10 * 60,
    ["check_timeout"] = 1 * 60,
    ["mysql_options"] = game_db,
    ["ticket_group_limit"] = 16,
})

-- 角色服务
make_options(table.insert, services.players, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["db_thread_num"] = 4,
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["db_flush_wait_time"] = 10,
    ["mysql_options"] = game_db,
    ["max_coroutine_num"] = 1000,
    ["player_cache_size"] = 100,
    ["player_cache_time"] = 10 * 60,
    ["player_load_limit"] = 100,
})

-- 竞技场服务
make_options(table.insert, services.pvps, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["script_main"] = "lua/pvp/main.lua",
    ["script_path"] = "./lua/?.lua",
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["pre_load_limit"] = 100, 
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["player_cache_time"] = 10 * 60,
    ["check_timeout"] = 1 * 60,
    ["mysql_options"] = game_db,
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 竞技场2服务
make_options(table.insert, services.pvp_ladders, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["script_main"] = "lua/pvp_ladder/main.lua",
    ["script_path"] = "./lua/?.lua",
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["pre_load_limit"] = 100, 
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["player_cache_time"] = 10 * 60,
    ["check_timeout"] = 1 * 60,
    ["mysql_options"] = game_db,
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 荣耀竞技场服务
make_options(table.insert, services.gpvps, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["script_main"] = "lua/gpvp/main.lua",
    ["script_path"] = "./lua/?.lua",
    ["db_thread_num"] = 4,
    ["max_coroutine_num"] = 1000,
    ["pre_load_limit"] = 100, 
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["player_cache_time"] = 10 * 60,
    ["check_timeout"] = 1 * 60,
    ["mysql_options"] = game_db,
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 代理服务
make_options(table.insert, services.proxys, {
    ["domain"] = domain,
    ["script_main"] = "lua/proxy/main.lua",
    ["script_path"]= "./lua/?.lua; ./etc/?.lua",
    ["collect_garbage_timeout"] = 1 * 60,
    ["cache_expire_time"] = 60,
})

-- 排行服务
make_options(table.insert, services.ranks, {
    ["domain"] = domain,
    ["area_id"] = area_id,
    ["zone_ids"] = zone_ids,
    ["db_thread_num"] = 4,
    ["db_flush_timeout"] = 1 * 60,
    ["db_flush_rand"] = 2 * 60,
    ["mysql_options"] = game_db,
    ["pre_load_limit"] = 1000,
    ["max_coroutine_num"] = 1000,
    ["script_path"] = "./lua/?.lua",
    ["script_main"] = "lua/rank/main.lua",
    ["collect_garbage_timeout"] = 1 * 60,
})

-- 序号服务
local function make_seqid_options(seqids, ...)
    for _, id in ipairs({ ... }) do
        table.insert(seqids or {}, {
            ["domain"] = domain,
            ["id"] = id,
        })
    end
end
make_options(make_seqid_options, services.seqids, 1)

-- zk服务
make_options(table.insert, services.zks, {
    ["my_id"] = 1,
    ["data_dir"] = "datalog",
    ["servers"] = {
        [1] = "tcp://127.0.0.1:3881",
    },
    ["bind_address"] = "tcp://127.0.0.1:2881",
})