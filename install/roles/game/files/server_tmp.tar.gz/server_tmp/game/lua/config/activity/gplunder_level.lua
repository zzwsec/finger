
-- pm.TbInvadeLevel



return
{
[1] = 
{
	id=1,
	kill=50,
	monster_level=
	{
	
		{
			value=1,
			pr=40,
		},
	
		{
			value=2,
			pr=40,
		},
	
		{
			value=3,
			pr=20,
		},
	},
},
[2] = 
{
	id=2,
	kill=100,
	monster_level=
	{
	
		{
			value=1,
			pr=10,
		},
	
		{
			value=2,
			pr=40,
		},
	
		{
			value=3,
			pr=30,
		},
	
		{
			value=4,
			pr=20,
		},
	},
},
[3] = 
{
	id=3,
	kill=200,
	monster_level=
	{
	
		{
			value=2,
			pr=20,
		},
	
		{
			value=3,
			pr=40,
		},
	
		{
			value=4,
			pr=30,
		},
	
		{
			value=5,
			pr=10,
		},
	},
},
[4] = 
{
	id=4,
	kill=350,
	monster_level=
	{
	
		{
			value=3,
			pr=20,
		},
	
		{
			value=4,
			pr=35,
		},
	
		{
			value=5,
			pr=30,
		},
	
		{
			value=6,
			pr=10,
		},
	
		{
			value=7,
			pr=5,
		},
	},
},
[5] = 
{
	id=5,
	kill=0,
	monster_level=
	{
	
		{
			value=3,
			pr=10,
		},
	
		{
			value=4,
			pr=25,
		},
	
		{
			value=5,
			pr=30,
		},
	
		{
			value=6,
			pr=20,
		},
	
		{
			value=7,
			pr=10,
		},
	
		{
			value=8,
			pr=5,
		},
	},
},
}
