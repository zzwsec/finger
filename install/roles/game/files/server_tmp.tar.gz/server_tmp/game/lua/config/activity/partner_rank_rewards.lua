
-- pm.TbPartnerRankRewards



return
{
[1] = 
{
	id=1,
	index=1,
	condition=
	{
		type=68,
		value=100,
	},
	rewards=
	{
		id=3,
		num=100,
	},
},
[2] = 
{
	id=2,
	index=1,
	condition=
	{
		type=68,
		value=300,
	},
	rewards=
	{
		id=37,
		num=10,
	},
},
[3] = 
{
	id=3,
	index=1,
	condition=
	{
		type=68,
		value=500,
	},
	rewards=
	{
		id=39,
		num=5,
	},
},
[4] = 
{
	id=4,
	index=1,
	condition=
	{
		type=68,
		value=1000,
	},
	rewards=
	{
		id=132,
		num=8,
	},
},
[5] = 
{
	id=5,
	index=1,
	condition=
	{
		type=68,
		value=1500,
	},
	rewards=
	{
		id=33,
		num=200,
	},
},
}
