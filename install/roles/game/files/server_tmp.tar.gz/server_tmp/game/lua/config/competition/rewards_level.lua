
-- pm.TbCompetitionRewardsLevel



return
{
[1] = 
{
	id=1,
	type=1,
	level=1,
	reward_ratio=1.2,
	reward_rank=7,
	condition=
	{
	},
},
[2] = 
{
	id=2,
	type=1,
	level=2,
	reward_ratio=1.5,
	reward_rank=5,
	condition=
	{
	
		{
			type=1,
			value=600,
		},
	
		{
			type=3,
			value=5,
		},
	},
},
[3] = 
{
	id=3,
	type=1,
	level=3,
	reward_ratio=1.8,
	reward_rank=3,
	condition=
	{
	
		{
			type=1,
			value=1200,
		},
	
		{
			type=3,
			value=3,
		},
	},
},
[4] = 
{
	id=4,
	type=2,
	level=1,
	reward_ratio=1.2,
	reward_rank=7,
	condition=
	{
	},
},
[5] = 
{
	id=5,
	type=2,
	level=2,
	reward_ratio=1.5,
	reward_rank=5,
	condition=
	{
	
		{
			type=1,
			value=700000,
		},
	
		{
			type=3,
			value=5,
		},
	},
},
[6] = 
{
	id=6,
	type=2,
	level=3,
	reward_ratio=1.8,
	reward_rank=3,
	condition=
	{
	
		{
			type=1,
			value=800000,
		},
	
		{
			type=3,
			value=3,
		},
	},
},
[7] = 
{
	id=7,
	type=3,
	level=1,
	reward_ratio=1.2,
	reward_rank=7,
	condition=
	{
	},
},
[8] = 
{
	id=8,
	type=3,
	level=2,
	reward_ratio=1.5,
	reward_rank=5,
	condition=
	{
	
		{
			type=1,
			value=900000,
		},
	
		{
			type=3,
			value=5,
		},
	},
},
[9] = 
{
	id=9,
	type=3,
	level=3,
	reward_ratio=1.8,
	reward_rank=3,
	condition=
	{
	
		{
			type=1,
			value=1200000,
		},
	
		{
			type=3,
			value=3,
		},
	},
},
}
