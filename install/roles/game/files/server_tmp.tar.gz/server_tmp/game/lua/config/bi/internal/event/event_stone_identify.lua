
-- pm.TbBiInternalEventEventStoneIdentify



return
{
[1] = 
{
	id=1,
	field="event_id",
	name="事件类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="identify_times",
	name="切割次数",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="identify_color",
	name="鉴定切面颜色",
	type=0,
	opt=1,
	default_value="",
},
}
