
-- pm.TbBiInternalEventBuildLevelupAccelerate



return
{
[1] = 
{
	id=1,
	field="build_id",
	name="建筑id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="level",
	name="建筑等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="accelerate_type",
	name="加速类型",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="accelerate_time",
	name="加速时间",
	type=0,
	opt=1,
	default_value="",
},
}
