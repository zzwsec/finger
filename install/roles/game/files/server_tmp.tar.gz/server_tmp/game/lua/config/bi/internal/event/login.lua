
-- pm.TbBiInternalEventLogin



return
{
[1] = 
{
	id=1,
	field="ip",
	name="ip",
	type=1,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="online",
	name="是否在线",
	type=2,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="duration",
	name="在线时长",
	type=0,
	opt=0,
	default_value="",
},
[4] = 
{
	id=4,
	field="channel",
	name="渠道",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="platform",
	name="平台",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="device",
	name="设备",
	type=1,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="device_id",
	name="设备编号",
	type=1,
	opt=1,
	default_value="",
},
[8] = 
{
	id=8,
	field="level",
	name="等级",
	type=0,
	opt=1,
	default_value="",
},
[9] = 
{
	id=9,
	field="power",
	name="战力",
	type=0,
	opt=1,
	default_value="",
},
[10] = 
{
	id=10,
	field="property",
	name="财力",
	type=0,
	opt=1,
	default_value="",
},
[11] = 
{
	id=11,
	field="mainline",
	name="主线关卡",
	type=0,
	opt=1,
	default_value="",
},
[12] = 
{
	id=12,
	field="trade",
	name="贸易等级",
	type=0,
	opt=1,
	default_value="",
},
[13] = 
{
	id=13,
	field="depth",
	name="挖矿深度",
	type=0,
	opt=1,
	default_value="",
},
[14] = 
{
	id=14,
	field="money",
	name="充值额度",
	type=0,
	opt=1,
	default_value="",
},
}
