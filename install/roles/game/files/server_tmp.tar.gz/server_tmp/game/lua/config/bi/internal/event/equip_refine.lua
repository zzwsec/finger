
-- pm.TbBiInternalEventEquipRefine



return
{
[1] = 
{
	id=1,
	field="equip_position",
	name="装备位置",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="level",
	name="精炼等级",
	type=0,
	opt=1,
	default_value="",
},
}
