﻿local math = require("math")

local M = {}

local AppCommon = require("app.common")

local timer_provider = assert(g_time_provider, "no set application context variablies")

-- 获取系统事件
function M.GetNowTime()
    return AppCommon.GetNowTime(timer_provider)
end

function M.GetNowTimeSec()
    local now_time = AppCommon.GetNowTime(timer_provider)
    return math.floor(now_time / 1000)
end

return M