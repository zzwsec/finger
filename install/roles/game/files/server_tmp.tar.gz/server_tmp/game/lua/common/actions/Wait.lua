local class = require "utils.class"
local Constants = require "core.Constants"

local Action = require 'core.Action'

local Wait = class("Wait", Action)

function Wait:ctor(settings)
    Action.ctor(self, settings)

    self.name = "Wait"
    self.title = "Wait <milliseconds>ms"
    self.milliseconds = assert(settings.milliseconds)
end

function Wait:tick(tick)
    local currTime = tick.nowTime
    local startTime = tick.blackboard:get("startTime", tick.tree.id, self.id)

    if not startTime or startTime == 0 then
        startTime = currTime
        tick.blackboard:set("startTime", currTime, tick.tree.id, self.id)
    end

    if currTime - startTime > self.milliseconds then
        return Constants.SUCCESS
    end
    
    return Constants.RUNNING
end

return Wait
