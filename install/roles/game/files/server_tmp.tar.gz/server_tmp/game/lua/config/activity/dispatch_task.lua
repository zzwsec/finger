
-- pm.TbDispatchTask



return
{
[11501] = 
{
	id=11501,
	desc={key='dispatch_task_desc/11501',text="运送货物"},
	pj=1,
	weight=1500,
	conditions=
	{
	
		{
			type=1,
			value=2,
		},
	
		{
			type=2,
			value=3,
		},
	
		{
			type=3,
			value=1,
		},
	},
	duration=7200,
	rewards=
	{
	
		{
			id=59,
			num=1500,
		},
	},
},
[11502] = 
{
	id=11502,
	desc={key='dispatch_task_desc/11502',text="矿场巡逻"},
	pj=1,
	weight=1500,
	conditions=
	{
	
		{
			type=1,
			value=1,
		},
	
		{
			type=2,
			value=3,
		},
	
		{
			type=3,
			value=1,
		},
	},
	duration=7200,
	rewards=
	{
	
		{
			id=59,
			num=1500,
		},
	},
},
[11503] = 
{
	id=11503,
	desc={key='dispatch_task_desc/11503',text="精铁锻造"},
	pj=2,
	weight=2500,
	conditions=
	{
	
		{
			type=1,
			value=3,
		},
	
		{
			type=2,
			value=4,
		},
	
		{
			type=3,
			value=2,
		},
	},
	duration=14400,
	rewards=
	{
	
		{
			id=59,
			num=2800,
		},
	},
},
[11504] = 
{
	id=11504,
	desc={key='dispatch_task_desc/11504',text="矿镐生产"},
	pj=2,
	weight=2500,
	conditions=
	{
	
		{
			type=1,
			value=2,
		},
	
		{
			type=2,
			value=4,
		},
	
		{
			type=3,
			value=3,
		},
	},
	duration=14400,
	rewards=
	{
	
		{
			id=59,
			num=2800,
		},
	},
},
[11505] = 
{
	id=11505,
	desc={key='dispatch_task_desc/11505',text="座驾保养"},
	pj=3,
	weight=750,
	conditions=
	{
	
		{
			type=1,
			value=3,
		},
	
		{
			type=2,
			value=5,
		},
	
		{
			type=3,
			value=3,
		},
	},
	duration=21600,
	rewards=
	{
	
		{
			id=59,
			num=4200,
		},
	},
},
[11506] = 
{
	id=11506,
	desc={key='dispatch_task_desc/11506',text="宠物训练"},
	pj=3,
	weight=750,
	conditions=
	{
	
		{
			type=1,
			value=2,
		},
	
		{
			type=2,
			value=5,
		},
	
		{
			type=3,
			value=4,
		},
	},
	duration=21600,
	rewards=
	{
	
		{
			id=59,
			num=4200,
		},
	},
},
[11507] = 
{
	id=11507,
	desc={key='dispatch_task_desc/11507',text="讨伐异兽"},
	pj=4,
	weight=250,
	conditions=
	{
	
		{
			type=1,
			value=2,
		},
	
		{
			type=2,
			value=6,
		},
	
		{
			type=3,
			value=4,
		},
	},
	duration=28800,
	rewards=
	{
	
		{
			id=59,
			num=7000,
		},
	},
},
[11508] = 
{
	id=11508,
	desc={key='dispatch_task_desc/11508',text="矿业投资"},
	pj=4,
	weight=250,
	conditions=
	{
	
		{
			type=1,
			value=4,
		},
	
		{
			type=2,
			value=5,
		},
	
		{
			type=3,
			value=3,
		},
	},
	duration=28800,
	rewards=
	{
	
		{
			id=59,
			num=7000,
		},
	},
},
}
