
-- pm.TbInvadeMonster



return
{
[1] = 
{
	id=1,
	level=1,
	name={key='gplunder_monster/1',text="盗贼"},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	score_reward=
	{
		id=70,
		num=1000,
	},
	npc=1099,
	fight=1315,
	npc_attrs=
	{
	
		{
			id=100,
			value=28,
		},
	
		{
			id=101,
			value=320,
		},
	
		{
			id=102,
			value=120,
		},
	
		{
			id=103,
			value=43,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0.1,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[2] = 
{
	id=2,
	level=2,
	name={key='gplunder_monster/2',text="盗贼"},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	score_reward=
	{
		id=70,
		num=2000,
	},
	npc=1099,
	fight=1463,
	npc_attrs=
	{
	
		{
			id=100,
			value=28,
		},
	
		{
			id=101,
			value=357,
		},
	
		{
			id=102,
			value=135,
		},
	
		{
			id=103,
			value=38,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0.1,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[3] = 
{
	id=3,
	level=3,
	name={key='gplunder_monster/3',text="盗贼"},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	score_reward=
	{
		id=70,
		num=4000,
	},
	npc=1099,
	fight=1612,
	npc_attrs=
	{
	
		{
			id=100,
			value=28,
		},
	
		{
			id=101,
			value=10000,
		},
	
		{
			id=102,
			value=151,
		},
	
		{
			id=103,
			value=43,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0.1,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[4] = 
{
	id=4,
	level=4,
	name={key='gplunder_monster/4',text="盗贼"},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	score_reward=
	{
		id=70,
		num=10000,
	},
	npc=1099,
	fight=1794,
	npc_attrs=
	{
	
		{
			id=100,
			value=28,
		},
	
		{
			id=101,
			value=59600,
		},
	
		{
			id=102,
			value=137,
		},
	
		{
			id=103,
			value=48,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0.1,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[5] = 
{
	id=5,
	level=5,
	name={key='gplunder_monster/5',text="盗贼"},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	score_reward=
	{
		id=70,
		num=20000,
	},
	npc=1099,
	fight=1760,
	npc_attrs=
	{
	
		{
			id=100,
			value=28,
		},
	
		{
			id=101,
			value=447000,
		},
	
		{
			id=102,
			value=167,
		},
	
		{
			id=103,
			value=48,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.1,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
}
