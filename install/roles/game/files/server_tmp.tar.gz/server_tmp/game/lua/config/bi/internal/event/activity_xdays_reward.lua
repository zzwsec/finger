
-- pm.TbBiInternalEventActivityXdaysReward



return
{
[1] = 
{
	id=1,
	field="activity_id",
	name="活动id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="open_days",
	name="活动开启天数",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="sequence",
	name="领取奖励序列",
	type=0,
	opt=1,
	default_value="0",
},
}
