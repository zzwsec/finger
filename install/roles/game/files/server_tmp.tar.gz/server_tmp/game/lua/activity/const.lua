local M = {}

-- 活动状态
M.ActiveState = {
    -- 开启
    OPEN    = 1,
    -- 关闭
    CLOSED  = 2,
    -- 运行
    RUNING = 3,
}

-- 活动时间类型(互斥)
M.ActiveTimeMode = {
    GM              = 0,     -- GM
    SERVER          = 1,     -- 开服时间
    PLAYER          = 2,     -- 角色创建时间    
}

-- 活动类型
M.ActiveType = {
    UNKNOWN                 = 0,   -- 未知类型
    XDAYS_LOGIN             = 101, -- 七日登录
    OPEN_SERVER             = 102, -- 开服庆典
    MAIN_LINE               = 103, -- 主线冲榜
    MINE_DEPTH              = 104, -- 挖矿深度
    ASSET                   = 105, -- 资产
    XDAYS_TARGET            = 106, -- 七日任务
    JADE                    = 107, -- 玉石排行活动
    YUANBAO                 = 108, -- 钻石排行活动
    RELIC                   = 109, -- 宠物遗迹活动
    MINE_DEPTH_ADD          = 110, -- 挖矿深度增幅排行榜
    ASSET_ADD               = 111, -- 资产增幅排行榜
    RECHARGE                = 112, -- 累计充值奖励
    RECHARGE_CONTINUE       = 113, -- 连续充值奖励
    DISPATCH_HERO           = 115, -- 佣兵派遣活动
    HERO_STAR               = 116, -- 佣兵升星活动
    BUSINESS                = 117, -- 经商之道活动
    PARTNER_RANK            = 118, -- 伙伴排行活动
    GPLUNDER                = 119, -- 劫掠入侵活动
    HERO_RECRUIT            = 120, -- 佣兵招募活动
    PET_CATCH               = 121, -- 宠物捕捉活动
    PARTNER_GIFT            = 122, -- 伙伴礼物活动
    CRAZY_MINER             = 123, -- 狂热矿工
    ACC_REPAY               = 124, -- 加速返还
    RUIN                    = 125, -- 遗迹探索
}

return M