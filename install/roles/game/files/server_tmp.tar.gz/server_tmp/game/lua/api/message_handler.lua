local Time = require("common.time")
local Log = require("common.logging")

local CounterService = require("api.service.counter.service")
local InviteService = require("api.service.invite.service")
local LeaderboardService = require("api.service.leaderboard.service")

-- 获取排行记录
local function OnHandleGetRecord(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                record = {},
            }
            local result = LeaderboardService.GetRecord(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.record = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("GetRecord", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.leaderboard.lib.GetRecordReq"] = OnHandleGetRecord

-- 批量获取排行记录
local function OnHandleGetRecords(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                records = {},
            }
            local result = LeaderboardService.GetRecords(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.records = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("GetRecords", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.leaderboard.lib.GetRecordsReq"] = OnHandleGetRecords

-- 写排行记录
local function OnHandleWriteRecord(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                record = {},
            }
            local result = LeaderboardService.WriteRecord(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.record = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("WriteRecord", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.leaderboard.lib.WriteRecordReq"] = OnHandleWriteRecord

-- 删除排行记录
local function OnHandleDeleteRecord(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK"
            }
            local result = LeaderboardService.DeleteRecord(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            return response
        end, ErrorHandler)
        Log.Info("DeleteRecord", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.leaderboard.lib.DeleteRecordReq"] = OnHandleDeleteRecord

-- 拉取排行榜
local function OnHandleListRecords(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                records = {},
            }
            
            local result = LeaderboardService.ListRecords(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.records = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("ListRecords", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.leaderboard.lib.ListRecordsReq"] = OnHandleListRecords

-- 创建计数器
local function OnHandleCreateCounter(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                counter = {},
            }
            local result = CounterService.Create(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.counter = result:unwrap()
            return response
        end, ErrorHandler)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.counter.lib.CreateReq"] = OnHandleCreateCounter

-- 获取计数器
local function OnHandleGetCounter(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                counter = {},
            }
            local result = CounterService.Get(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.counter = result:unwrap()
            return response
        end, ErrorHandler)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.counter.lib.GetReq"] = OnHandleGetCounter

-- 批量获取计数器
local function OnHandleBatchGetCounter(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                counters = {},
            }
            local result = CounterService.BatchGet(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.counters = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("BatchGetCounter", "Response: {}", response)   
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.counter.lib.BatchGetReq"] = OnHandleBatchGetCounter

-- 删除计数器
local function OnHandleDeleteCounter(method, message, done) 
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK"
            }
            local result = CounterService.Delete(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            return response
        end, ErrorHandler)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.counter.lib.DeleteReq"] = OnHandleDeleteCounter

-- 增加计数器
local function OnHandleIncrementCounter(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK"
            }
            local result = CounterService.Increment(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.counter = result:unwrap()
            return response
        end, ErrorHandler)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.counter.lib.IncrementReq"] = OnHandleIncrementCounter

-- 减少计数器
local function OnHandleDecrementCounter(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK"
            }
            local result = CounterService.Decrement(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.counter = result:unwrap()
            return response
        end, ErrorHandler)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.counter.lib.DecrementReq"] = OnHandleDecrementCounter


-- 邀请码相关
-- 创建邀请码
local function OnHandleCreateInvite(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                invite = {},
            }
            local result = InviteService.Create(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.invite = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("CreateInvite", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.invite.lib.CreateReq"] = OnHandleCreateInvite

-- 获取邀请码
local function OnHandleGetInvite(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                invite = {},
            }
            local result = InviteService.Get(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.invite = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("GetInvite", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.invite.lib.GetReq"] = OnHandleGetInvite

-- 绑定邀请码
local function OnHandleBindInvite(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                invite = {},
            }
            local result = InviteService.Bind(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.invite = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("BindInvite", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.invite.lib.BindReq"] = OnHandleBindInvite

-- 关联邀请码
local function OnHandleRelationInvite(method, message, done)
    local coro = coroutine.create(function(coro)
        local ok, response = xpcall(function()
            local response = {
                result = "OK",
                records = {},
            }
            local result = InviteService.Relation(coro, message)
            if result:is_err() then
                response.result = result:unwrap_err()
                return response
            end
            response.records = result:unwrap()
            return response
        end, ErrorHandler)
        Log.Info("RelationInvite", "Response: {}", response)
        done(ok and response or {result = "SYSTEM_BUSY"})
    end)
    assert(coroutine.resume(coro, coro))
end
Handlers["app.invite.lib.RelationReq"] = OnHandleRelationInvite









