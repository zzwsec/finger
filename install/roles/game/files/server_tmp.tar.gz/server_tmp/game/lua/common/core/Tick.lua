local class = require "utils.class"

local Tick = class("Tick")

function Tick:ctor()
    self.tree = nil
    self.debug = nil
    self.nowTime = 0
    self.target = nil
    self.blackboard = nil

    self._openNodes = {}
    self._nodeCount = 0
end

function Tick:_enterNode(node)
    self._nodeCount = self._nodeCount + 1
    table.insert(self._openNodes, node)
end

function Tick:_openNode(node)
end

function Tick:_tickNode(node)
end

function Tick:_closeNode(node)
end

function Tick:_exitNode(node)
end

return Tick