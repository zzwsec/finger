
-- pm.TbBiInternalEventActivityLogin



return
{
[1] = 
{
	id=1,
	field="activity_id",
	name="活动id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="type",
	name="天数累计类型",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="open_days",
	name="活动开启天数",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="login_days",
	name="活动累计登录天数",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="days",
	name="领取奖励对应天数",
	type=0,
	opt=1,
	default_value="0",
},
}
