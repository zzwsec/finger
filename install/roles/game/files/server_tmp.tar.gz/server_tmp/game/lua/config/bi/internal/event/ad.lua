
-- pm.TbBiInternalEventAd



return
{
[1] = 
{
	id=1,
	field="state",
	name="播放状态: 1)成功 2)失败",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="way",
	name="广告播放的途径",
	type=0,
	opt=1,
	default_value="",
},
}
