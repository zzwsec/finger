local Log = require("common/logging")

local Logic = import("activity/team/logic")

-- 创建队伍
local function OnHandle_CreateTeam(team, coro, message, done)
    local _, response = xpcall(function()
        local response = {
            ["result"] = "OK",
            ["team"] = {}
        }
        response.result, response.team = Logic.CreateTeam(team, message)
        return response 
    end, ErrorHandler)
    done(response or {
        ["result"] = "SYSTEM_BUSY",
    })
end
Handlers["app.activity.lib.team.CreateTeam"] = OnHandle_CreateTeam

-- 退出队伍
local function OnHandle_QuitTeam(team, coro, message, done)
    local _, response = xpcall(function()
        local response = {
            ["result"] = "OK",
        }
        response.result = Logic.QuitTeam(team, message)
        return response 
    end, ErrorHandler)
    done(response or {
        ["result"] = "SYSTEM_BUSY",
    })
end
Handlers["app.activity.lib.team.QuitTeam"] = OnHandle_QuitTeam

-- 加入队伍
local function OnHandle_JoinTeam(team, coro, message, done)
    local _, response = xpcall(function()
        local response = {
            ["result"] = "OK",
            ["team"] = {}
        }
        response.result, response.team = Logic.JoinTeam(team, message)
        return response 
    end, ErrorHandler)
    done(response or {
        ["result"] = "SYSTEM_BUSY",
    })
end
Handlers["app.activity.lib.team.JoinTeam"] = OnHandle_JoinTeam

-- 拉取队伍
local function OnHandle_FetchTeam(team, coro, message, done)
    local _, response = xpcall(function()
        local response = {
            ["result"] = "OK",
            ["team"] = {},
            ["ids"] = {}
        }
        response.result, response.team, response.ids = Logic.FetchTeam(team, message)
        return response 
    end, ErrorHandler)
    done(response or {
        ["result"] = "SYSTEM_BUSY",
    })
end
Handlers["app.activity.lib.team.FetchTeam"] = OnHandle_FetchTeam

-- 申请加入
local function OnHandle_ApplyTeam(team, coro, message, done)
    local _, response = xpcall(function()
        local response = {
            ["result"] = "OK"
        }
        response.result = Logic.ApplyTeam(team, message)
        return response 
    end, ErrorHandler)
    done(response or {
        ["result"] = "SYSTEM_BUSY",
    })
end
Handlers["app.activity.lib.team.ApplyTeam"] = OnHandle_ApplyTeam

-- 同意申请
local function OnHandle_ProcessApply(team, coro, message, done)
    local _, response = xpcall(function()
        local response = {
            ["result"] = "OK",
            ["team"] = {},
        }
        if message.agree then
            response.result, response.team = Logic.AgreeApply(team, message)
        else
            response.result = Logic.IgnoreApply(team, message)
        end
        return response 
    end, ErrorHandler)
    done(response or {
        ["result"] = "SYSTEM_BUSY",
    })
end
Handlers["app.activity.lib.team.ProcessApply"] = OnHandle_ProcessApply

-- 更新积分
local function OnHandle_UpdateScore(team, coro, message, done)
    local _, response = xpcall(function()
        local response = {
            ["result"] = "OK"
        }
        response.result, response.person_score, response.team_score = Logic.UpdateScore(team, message)
        return response 
    end, ErrorHandler)
    done(response or {
        ["result"] = "SYSTEM_BUSY",
    })
end
Handlers["app.activity.lib.team.UpdateScore"] = OnHandle_UpdateScore