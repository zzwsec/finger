local _M = {}

-- 编码Id
function _M.EncodeId(id, region_id)
    id = id or 0
    region_id = region_id or 0
    if id == 0 or region_id == 0 then
        return 0
    end
    return string.format("%d_%d", id, region_id)
end

-- 解码id
function _M.DecodeId(id)
    local parts = string.split(id, "_") 
    if #parts ~= 2 then
        return 0, 0
    end
    -- id: region_id
    return tonumber(parts[1]), tonumber(parts[2])
end

-- 转换到标准数据
function _M.To(from)
    if not from then return nil end
    
    local id, zone_id = _M.DecodeId(from.user_id)
    if id == 0 then return nil end
    
    local to = {
        id = id,
        zone_id = zone_id,
        score = tonumber(from.score) or 0,
        rank = tonumber(from.rank) or 0, 
        time = tonumber(from.time) or 0,
    }
    return to
end

return _M