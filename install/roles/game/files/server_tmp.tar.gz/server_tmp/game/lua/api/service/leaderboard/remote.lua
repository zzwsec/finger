local Log = require("common.logging")
local Result = require("common.result")

local Http = require("api.utility.http")
local Validator = require("api.utility.validator")
local DataCast = import("api.utility.cast").Leaderboard
local ServerOptions = import("api.utility.config").ServerOptions

local BaseUrl = ServerOptions.Url

local _M = {}

-- 创建排行榜
function _M.Create(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id"}) then
        Log.Warn("CreateLeaderboard", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards", BaseUrl, message.project_id)
    local ok, resp = Http.Post(coro, url, {
        body = {
            id = message.leaderboard_id,
            sort_type = message.sort_type or "desc",
            update_type = message.update_type or "best",
            limit = message.limit or 100
        }
    })

    local maybe_result = Http.HandleResponse(ok, resp, "CreateLeaderboard")
    if maybe_result:is_err() then
        Log.Warn("CreateLeaderboard", "Failed to create leaderboard: {}", maybe_result:unwrap_err())
        return maybe_result
    end

    local leaderboard = DataCast.toLeaderboard(maybe_result:unwrap())
    if not leaderboard then
        Log.Warn("CreateLeaderboard", "leaderboard is nil")
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("CreateLeaderboard", "Created leaderboard: {}", leaderboard)
    return Result.ok(leaderboard)
end

-- 获取排行榜
function _M.Get(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id"}) then
        Log.Warn("GetLeaderboard", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s", BaseUrl, message.project_id, message.leaderboard_id)
    local ok, reply = Http.Get(coro, url)

    local maybe_result = Http.HandleResponse(ok, reply, "GetLeaderboard")
    if maybe_result:is_err() then
        return maybe_result
    end

    local leaderboard = DataCast.toLeaderboard(maybe_result:unwrap())
    if not leaderboard then
        Log.Warn("GetLeaderboard", "leaderboard is nil")
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("GetLeaderboard", "Got leaderboard: {}", leaderboard)
    return Result.ok(leaderboard)
end

-- 更新排行榜
function _M.Update(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id"}) then
        Log.Warn("UpdateLeaderboard", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s", BaseUrl, message.project_id, message.leaderboard_id)
    local ok, reply = Http.Put(coro, url, {
        body = {
            id = message.leaderboard_id,
            sort_type = message.sort_type,
            update_type = message.update_type,
            limit = message.limit
        }
    })

    local maybe_result = Http.HandleResponse(ok, reply, "UpdateLeaderboard")
    if maybe_result:is_err() then
        Log.Warn("UpdateLeaderboard", "Failed to update leaderboard: {}", maybe_result:unwrap_err())
        return maybe_result
    end

    local leaderboard = DataCast.toLeaderboard(maybe_result:unwrap())
    if not leaderboard then
        Log.Warn("UpdateLeaderboard", "leaderboard is nil")
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("UpdateLeaderboard", "Updated leaderboard: {}", leaderboard)
    return Result.ok(leaderboard)
end

-- 删除排行榜
function _M.Delete(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id"}) then
        Log.Warn("DeleteLeaderboard", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s", BaseUrl, message.project_id, message.leaderboard_id)
    local ok, reply = Http.Delete(coro, url)

    if not ok then
        Log.Warn("DeleteLeaderboard", "Failed to delete leaderboard: {}", message)
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("DeleteLeaderboard", "Deleted leaderboard: {}", message.leaderboard_id)
    return Result.ok("OK")
end

-- 获取单条记录
function _M.GetRecord(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id", "user_id"}) then
        Log.Warn("GetLeaderboardRecord", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s/scores/players/%s",
        BaseUrl, message.project_id, message.leaderboard_id, message.user_id)
    local ok, reply = Http.Get(coro, url)

    local maybe_result = Http.HandleResponse(ok, reply, "GetLeaderboardRecord")
    if maybe_result:is_err() then
        Log.Warn("GetLeaderboardRecord", "Failed to get leaderboard record: {}", maybe_result:unwrap_err())
        return maybe_result
    end

    local record = DataCast.toRecord(maybe_result:unwrap())
    if not record then
        Log.Warn("GetLeaderboardRecord", "record is nil")
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("GetLeaderboardRecord", "Got record: {}", record)
    return Result.ok(record)
end

-- 获取多条记录
function _M.GetRecords(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id", "user_ids"}) then
        Log.Warn("GetLeaderboardRecords", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s/scores/players",
        BaseUrl, message.project_id, message.leaderboard_id)
    local ok, reply = Http.Post(coro, url, {
        body = {
            player_ids = message.user_ids
        }
    })

    local maybe_result = Http.HandleResponse(ok, reply, "GetLeaderboardRecords")
    if maybe_result:is_err() then
        Log.Warn("GetLeaderboardRecords", "Failed to get leaderboard records: {}", maybe_result:unwrap_err())
        return maybe_result
    end

    local records = {}
    local content = maybe_result:unwrap()
    for _, record in ipairs(content.records or {}) do
        local built_record = DataCast.toRecord(record)
        if built_record then
            table.insert(records, built_record)
        end
    end

    local result = {
        records = records,
        miss_user_ids = content.missing_player_ids or {}
    }
    Log.Info("GetLeaderboardRecords", "Got {} records, miss {} user ids", #records, #result.miss_user_ids)
    return Result.ok(result)
end

-- 写入记录
function _M.WriteRecord(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id", "user_id", "score"}) then
        Log.Warn("WriteLeaderboardRecord", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s/scores/players/%s",
        BaseUrl, message.project_id, message.leaderboard_id, message.user_id)
    local ok, reply = Http.Post(coro, url, {
        body = {
            score = message.score
        }
    })

    local maybe_result = Http.HandleResponse(ok, reply, "WriteLeaderboardRecord")
    if maybe_result:is_err() then
        Log.Warn("WriteLeaderboardRecord", "Failed to write leaderboard record: {}", maybe_result:unwrap_err())
        return maybe_result
    end

    local record = DataCast.toRecord(maybe_result:unwrap())
    if not record then
        Log.Warn("WriteLeaderboardRecord", "record is nil")
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("WriteLeaderboardRecord", "Wrote record: {}", record)
    return Result.ok(record)
end

-- 删除记录
function _M.DeleteRecord(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id", "user_id"}) then
        Log.Warn("DeleteLeaderboardRecord", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s/scores/players/%s",
        BaseUrl, message.project_id, message.leaderboard_id, message.user_id)
    local ok, reply = Http.Delete(coro, url)

    if not ok then
        Log.Warn("DeleteLeaderboardRecord", "Failed to delete record: {}", message)
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("DeleteLeaderboardRecord", "Deleted record for user {}", message.user_id)
    return Result.ok("OK")
end

-- 列出记录
function _M.ListRecords(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id"}) then
        Log.Warn("ListLeaderboardRecords", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s/scores",
        BaseUrl, message.project_id, message.leaderboard_id)
    local ok, reply = Http.Get(coro, url, {
        limit = message.limit or 100,
        offset = message.offset or 0
    })

    local maybe_result = Http.HandleResponse(ok, reply, "ListLeaderboardRecords")
    if maybe_result:is_err() then
        Log.Warn("ListLeaderboardRecords", "Failed to list leaderboard records: {}", maybe_result:unwrap_err())
        return maybe_result
    end

    local records = {}
    local content = maybe_result:unwrap()
    for _, record in ipairs(content.records or {}) do
        local built_record = DataCast.toRecord(record)
        if built_record then
            table.insert(records, built_record)
        end
    end

    Log.Info("ListLeaderboardRecords", "Listed {} records", #records)
    return Result.ok(records)
end

-- 重置记录
function _M.ResetRecords(coro, message)
    if not Validator.validateParams(message, {"leaderboard_id", "project_id"}) then
        Log.Warn("ResetLeaderboardRecords", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/leaderboards/%s/scores",
        BaseUrl, message.project_id, message.leaderboard_id)
    local ok, reply = Http.Delete(coro, url)

    if not ok then
        Log.Warn("ResetLeaderboardRecords", "Failed to reset records: {}", message)
        return Result.err("SYSTEM_BUSY")
    end

    Log.Info("ResetLeaderboardRecords", "Reset records for leaderboard {}", message.leaderboard_id)
    return Result.ok("OK")
end

return _M