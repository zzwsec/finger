local Result = require("common.result")
local Log = require("common.logging")
local Http = require("http")
local Rapidjson = require("rapidjson")

local M = {}

function M.Request(coro, method, endpoint, options, is_query_string)
    Log.Debug("HttpRequest", "input: {}", table.dump({
        method = method,
        endpoint = endpoint, 
        options = options
    }))

    local uri_builder = Http.UriBuilder.new(endpoint)
    if method == "GET" then
        for key, value in pairs(options or {}) do 
            uri_builder:append_query_key_value_pair(key, tostring(value))
        end
    end
    local uri = uri_builder:uri()
    
    local body
    if options and options.body then
        body = (is_query_string and is_query_string == true) 
            and options.body 
            or Rapidjson.pack(options.body)
    end

    Http.web(g_io_context_strand, uri, {
        method = method,
        headers = options and options.headers or {
            ["Content-Type"] = "application/json; charset=UTF-8",
        },
        body = body,
    }, function(reply, error_msg)
        coroutine.resume(coro, reply, error_msg)
    end)

    local reply, error_msg = coroutine.yield()
    
    if not reply then
        Log.Debug("HttpRequest", "uri: {}, error msg: {}", uri, error_msg)
        return false
    end
    
    if reply.status ~= 200 then
        Log.Debug("HttpRequest", "uri: {}, reply = {}", uri, reply or {})
        return false, reply
    end

    Log.Debug("HttpRequest", "body: {}", reply.body)
    return true, reply
end

function M.Get(coro, endpoint, options)
    return M.Request(coro, "GET", endpoint, options)
end

function M.Post(coro, endpoint, options, is_query_string) 
    return M.Request(coro, "POST", endpoint, options, is_query_string)
end

function M.Put(coro, endpoint, options, is_query_string)
    return M.Request(coro, "PUT", endpoint, options, is_query_string) 
end

function M.Delete(coro, endpoint)
    return M.Request(coro, "DELETE", endpoint)
end

-- 处理HTTP响应
function M.HandleResponse(ok, reply, operation)
    if not ok then
        Log.Debug(operation, "Failed to execute operation")
        return Result.err("SYSTEM_BUSY")
    end

    if reply and reply.status ~= 200 then
        Log.Debug(operation, "Failed with status: {}", reply.status)
        return Result.err("SYSTEM_BUSY")
    end

    local content = Rapidjson.unpack(reply.body or "{}")
    if not content then
        Log.Debug(operation, "Failed to decode response body")
        return Result.err("SYSTEM_BUSY")
    end

    return Result.ok(content)
end

return M