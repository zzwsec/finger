
-- pm.TbBiInternalEventPartnerLevelup



return
{
[1] = 
{
	id=1,
	field="partner_id",
	name="伙伴id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="old_level",
	name="伙伴老等级",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="level",
	name="伙伴新等级",
	type=0,
	opt=1,
	default_value="0",
},
}
