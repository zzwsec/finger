
-- pm.TbBiKingnetEventOrder



return
{
[1] = 
{
	id=1,
	field="order_id",
	name="订单id",
	type=1,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="item_id",
	name="商品ID",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="pay_amount",
	name="充值金额",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="order_channel",
	name="支付渠道",
	type=1,
	opt=0,
	default_value="",
},
[5] = 
{
	id=5,
	field="list",
	name="获得道具列表",
	type=1,
	opt=0,
	default_value="",
},
[6] = 
{
	id=6,
	field="type",
	name="订单类型",
	type=0,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="client_ip",
	name="用户的客户端ip",
	type=1,
	opt=0,
	default_value="",
},
[8] = 
{
	id=8,
	field="currency",
	name="原币币种",
	type=1,
	opt=0,
	default_value="USD",
},
[9] = 
{
	id=9,
	field="amount",
	name="原币金额",
	type=0,
	opt=0,
	default_value="",
},
}
