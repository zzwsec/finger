
-- pm.TbBiKingnetEventMiningSkill



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="技能id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="type",
	name="技能规则",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="num",
	name="技能效果",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="num1",
	name="技能cd",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="num2",
	name="技能消耗",
	type=0,
	opt=1,
	default_value="",
},
}
