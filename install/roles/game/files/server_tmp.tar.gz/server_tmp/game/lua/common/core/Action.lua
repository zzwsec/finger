local class = require "utils.class"
local Constants = require "core.Constants"

local BaseNode = require 'core.BaseNode'

local Action = class("Action", BaseNode)

function Action:ctor()
    BaseNode.ctor(self)

    self.category = Constants.ACTION
end

return Action