
-- pm.TbBiInternalEventMiningSkill



return
{
[1] = 
{
	id=1,
	field="skill_id",
	name="技能id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="skill_rule",
	name="技能规则",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="skill_effect",
	name="技能效果",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="skill_cd",
	name="技能cd",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="skill_cost",
	name="技能消耗",
	type=0,
	opt=1,
	default_value="",
},
}
