
-- pm.TbRechargeAccumulative



return
{
[101] = 
{
	id=101,
	index=1,
	desc={key='recharge_accumulative_desc/101',text="累计充值6元"},
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=3,
			num=60,
		},
	},
},
[102] = 
{
	id=102,
	index=1,
	desc={key='recharge_accumulative_desc/102',text="累计充值12元"},
	recharge=12,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=39,
			num=2,
		},
	},
},
[103] = 
{
	id=103,
	index=1,
	desc={key='recharge_accumulative_desc/103',text="累计充值30元"},
	recharge=30,
	rewards=
	{
	
		{
			id=1,
			num=200,
		},
	
		{
			id=39,
			num=3,
		},
	
		{
			id=6019,
			num=1,
		},
	},
},
[104] = 
{
	id=104,
	index=1,
	desc={key='recharge_accumulative_desc/104',text="累计充值68元"},
	recharge=68,
	rewards=
	{
	
		{
			id=1,
			num=300,
		},
	
		{
			id=39,
			num=5,
		},
	},
},
[105] = 
{
	id=105,
	index=1,
	desc={key='recharge_accumulative_desc/105',text="累计充值128元"},
	recharge=128,
	rewards=
	{
	
		{
			id=1,
			num=500,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=6011,
			num=1,
		},
	},
},
[106] = 
{
	id=106,
	index=1,
	desc={key='recharge_accumulative_desc/106',text="累计充值198元"},
	recharge=198,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=39,
			num=10,
		},
	},
},
[107] = 
{
	id=107,
	index=1,
	desc={key='recharge_accumulative_desc/107',text="累计充值328元"},
	recharge=328,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=6011,
			num=1,
		},
	},
},
[108] = 
{
	id=108,
	index=1,
	desc={key='recharge_accumulative_desc/108',text="累计充值648元"},
	recharge=648,
	rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=6011,
			num=1,
		},
	},
},
[109] = 
{
	id=109,
	index=1,
	desc={key='recharge_accumulative_desc/109',text="累计充值1000元"},
	recharge=1000,
	rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=6011,
			num=1,
		},
	},
},
[110] = 
{
	id=110,
	index=1,
	desc={key='recharge_accumulative_desc/110',text="累计充值2000元"},
	recharge=2000,
	rewards=
	{
	
		{
			id=1,
			num=3000,
		},
	
		{
			id=39,
			num=10,
		},
	
		{
			id=137,
			num=1,
		},
	},
},
[201] = 
{
	id=201,
	index=2,
	desc={key='recharge_accumulative_desc/201',text="累计充值6元"},
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=17,
			num=2,
		},
	},
},
[202] = 
{
	id=202,
	index=2,
	desc={key='recharge_accumulative_desc/202',text="累计充值12元"},
	recharge=12,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=17,
			num=3,
		},
	},
},
[203] = 
{
	id=203,
	index=2,
	desc={key='recharge_accumulative_desc/203',text="累计充值30元"},
	recharge=30,
	rewards=
	{
	
		{
			id=1,
			num=200,
		},
	
		{
			id=17,
			num=5,
		},
	
		{
			id=14,
			num=50,
		},
	},
},
[204] = 
{
	id=204,
	index=2,
	desc={key='recharge_accumulative_desc/204',text="累计充值68元"},
	recharge=68,
	rewards=
	{
	
		{
			id=1,
			num=300,
		},
	
		{
			id=17,
			num=5,
		},
	
		{
			id=14,
			num=50,
		},
	},
},
[205] = 
{
	id=205,
	index=2,
	desc={key='recharge_accumulative_desc/205',text="累计充值128元"},
	recharge=128,
	rewards=
	{
	
		{
			id=1,
			num=500,
		},
	
		{
			id=17,
			num=5,
		},
	
		{
			id=14,
			num=100,
		},
	},
},
[206] = 
{
	id=206,
	index=2,
	desc={key='recharge_accumulative_desc/206',text="累计充值198元"},
	recharge=198,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=17,
			num=10,
		},
	
		{
			id=14,
			num=100,
		},
	},
},
[207] = 
{
	id=207,
	index=2,
	desc={key='recharge_accumulative_desc/207',text="累计充值328元"},
	recharge=328,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=17,
			num=5,
		},
	
		{
			id=118,
			num=1,
		},
	},
},
[208] = 
{
	id=208,
	index=2,
	desc={key='recharge_accumulative_desc/208',text="累计充值648元"},
	recharge=648,
	rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	
		{
			id=17,
			num=5,
		},
	
		{
			id=108,
			num=1,
		},
	},
},
[209] = 
{
	id=209,
	index=2,
	desc={key='recharge_accumulative_desc/209',text="累计充值1000元"},
	recharge=1000,
	rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	
		{
			id=17,
			num=5,
		},
	
		{
			id=119,
			num=1,
		},
	},
},
[210] = 
{
	id=210,
	index=2,
	desc={key='recharge_accumulative_desc/210',text="累计充值2000元"},
	recharge=2000,
	rewards=
	{
	
		{
			id=1,
			num=3000,
		},
	
		{
			id=17,
			num=10,
		},
	
		{
			id=109,
			num=1,
		},
	},
},
[301] = 
{
	id=301,
	index=3,
	desc={key='recharge_accumulative_desc/301',text="累计充值6元"},
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=33,
			num=60,
		},
	},
},
[302] = 
{
	id=302,
	index=3,
	desc={key='recharge_accumulative_desc/302',text="累计充值12元"},
	recharge=12,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=39,
			num=2,
		},
	},
},
[303] = 
{
	id=303,
	index=3,
	desc={key='recharge_accumulative_desc/303',text="累计充值30元"},
	recharge=30,
	rewards=
	{
	
		{
			id=1,
			num=200,
		},
	
		{
			id=39,
			num=3,
		},
	
		{
			id=135,
			num=1,
		},
	},
},
[304] = 
{
	id=304,
	index=3,
	desc={key='recharge_accumulative_desc/304',text="累计充值68元"},
	recharge=68,
	rewards=
	{
	
		{
			id=1,
			num=300,
		},
	
		{
			id=39,
			num=5,
		},
	},
},
[305] = 
{
	id=305,
	index=3,
	desc={key='recharge_accumulative_desc/305',text="累计充值128元"},
	recharge=128,
	rewards=
	{
	
		{
			id=1,
			num=500,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=135,
			num=1,
		},
	},
},
[306] = 
{
	id=306,
	index=3,
	desc={key='recharge_accumulative_desc/306',text="累计充值198元"},
	recharge=198,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=39,
			num=10,
		},
	},
},
[307] = 
{
	id=307,
	index=3,
	desc={key='recharge_accumulative_desc/307',text="累计充值328元"},
	recharge=328,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=136,
			num=1,
		},
	},
},
[308] = 
{
	id=308,
	index=3,
	desc={key='recharge_accumulative_desc/308',text="累计充值648元"},
	recharge=648,
	rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=136,
			num=1,
		},
	},
},
[309] = 
{
	id=309,
	index=3,
	desc={key='recharge_accumulative_desc/309',text="累计充值1000元"},
	recharge=1000,
	rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	
		{
			id=39,
			num=5,
		},
	
		{
			id=136,
			num=1,
		},
	},
},
[310] = 
{
	id=310,
	index=3,
	desc={key='recharge_accumulative_desc/310',text="累计充值2000元"},
	recharge=2000,
	rewards=
	{
	
		{
			id=1,
			num=3000,
		},
	
		{
			id=39,
			num=10,
		},
	
		{
			id=138,
			num=1,
		},
	},
},
}
