local coroutine = require("coroutine")
local package = require("package")

local modules_ = {}
local configs_ = {}
local running_ = false

function import(modname, single)
    if not single then
        modules_[modname] = modname
    else
        configs_[modname] = modname
    end
    return require(modname)
end

function import_running()
    return running_
end

function import_reload_all(cb)
    cb = cb or function() end
    if not running_ then
        local configs = {}
        for modname in pairs(configs_) do
            configs[modname] = modname
            package.loaded[modname] = nil
        end
        local modules = {}
        for modname in pairs(modules_) do
            modules[modname] = modname
            package.loaded[modname] = nil
        end
        for modname in pairs(configs) do
            import(modname, true)
        end
        for modname in pairs(modules) do
            import(modname)
        end
        cb(true)
    end
    return not running_
end

function import_areload_all(strand, before_cb, after_cb)
    assert(strand and before_cb and after_cb)
    if not running_ then
        local coro = coroutine.create(function(coro, strand, before_cb, after_cb)
            running_ = true
            local ok, failure, message = true, false, nil
            xpcall(function()
                local configs = {}
                for modname in pairs(configs_) do
                    configs[modname] = false
                end
                local modules = {}
                for modname in pairs(modules_) do
                    modules[modname] = modname
                end
                for modname in pairs(configs) do
                    local oldmod = package.loaded[modname]
                    package.loaded[modname] = nil
                    ok, message = pcall(require, modname)
                    package.loaded[modname] = oldmod
                    if not ok then
                        break
                    end
                    configs[modname], message = message, nil
                    strand:post(coroutine.resume, coro)
                    coroutine.yield()
                end
                if not ok then
                    return
                end
                before_cb()
                for modname, module in pairs(configs) do
                    package.loaded[modname] = module
                end
                for modname in pairs(configs) do
                    import(modname, true)
                end
                for modname in pairs(modules) do
                    package.loaded[modname] = nil
                end
                for modname in pairs(modules) do
                    import(modname)
                end
            end, function(err_msg)
                failure = true
                after_cb(false, err_msg)
            end)
            running_ = false
            if not failure then
                after_cb(ok, message)
            end
        end)
        assert(coroutine.resume(coro, coro, strand, before_cb, after_cb))
        return true
    else
        return false
    end 
end