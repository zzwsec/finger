
-- pm.TbSmeltMaster



return
{
[1] = 
{
	id=1,
	cost=
	{
		id=319,
		num=1,
	},
	success_prob=10000,
	hero_assist=
	{
	},
	success_reward=221,
	fail_reward=
	{
		id=320,
		num=50,
	},
},
[2] = 
{
	id=2,
	cost=
	{
		id=319,
		num=1,
	},
	success_prob=8000,
	hero_assist=
	{
	
		{
			id=6012,
			num=500,
			show=0,
		},
	
		{
			id=6019,
			num=500,
			show=0,
		},
	},
	success_reward=222,
	fail_reward=
	{
		id=320,
		num=50,
	},
},
[3] = 
{
	id=3,
	cost=
	{
		id=319,
		num=1,
	},
	success_prob=6000,
	hero_assist=
	{
	
		{
			id=6012,
			num=500,
			show=0,
		},
	
		{
			id=6019,
			num=500,
			show=0,
		},
	},
	success_reward=223,
	fail_reward=
	{
		id=320,
		num=50,
	},
},
[4] = 
{
	id=4,
	cost=
	{
		id=319,
		num=1,
	},
	success_prob=5000,
	hero_assist=
	{
	
		{
			id=6012,
			num=500,
			show=0,
		},
	
		{
			id=6019,
			num=500,
			show=0,
		},
	},
	success_reward=224,
	fail_reward=
	{
		id=320,
		num=50,
	},
},
[5] = 
{
	id=5,
	cost=
	{
		id=319,
		num=1,
	},
	success_prob=4000,
	hero_assist=
	{
	
		{
			id=6012,
			num=500,
			show=0,
		},
	
		{
			id=6019,
			num=500,
			show=0,
		},
	},
	success_reward=225,
	fail_reward=
	{
		id=320,
		num=50,
	},
},
}
