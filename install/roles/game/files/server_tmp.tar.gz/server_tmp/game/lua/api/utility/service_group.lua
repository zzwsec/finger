local Log = require("common.logging")
local Groups = import("etc/groups", true)
local service_groups = Groups.gpvp

local group_idss = {}
for group_id, group in pairs(service_groups or {}) do 
    for _, area_id in ipairs(group or {}) do 
        group_idss[area_id] = group_id
    end
end 

local _M = {}

function _M.GetGroupId(area_id)
    return group_idss[area_id]
end

function _M.GetServiceGroup(area_id)
    local group_id = _M.GetGroupId(area_id) 
    if group_id == nil then     
        return {}, group_id
    end
    return service_groups[group_id], group_id
end

return _M