local class = require "utils.class"
local Constants = require "core.Constants"

local Action = require 'core.Action'

local Succeeder = class("Succeeder", Action)

function Succeeder:ctor()
    Action.ctor(self)

    self.name = "Succeeder"
end

function Succeeder:tick(tick)
    return Constants.SUCCESS
end

return Succeeder