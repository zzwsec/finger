
-- pm.TbBiInternalEventGplunderFight



return
{
[1] = 
{
	id=1,
	field="report_id",
	name="战报id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="monster_id",
	name="怪物id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="type",
	name="战斗方式",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="team",
	name="队伍信息",
	type=1,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="status",
	name="胜利失败",
	type=0,
	opt=1,
	default_value="0",
},
}
