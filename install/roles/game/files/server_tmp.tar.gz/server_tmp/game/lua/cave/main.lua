require("common/import")
require("common/functions")


-- 模块
Modules = {}

-- 重读
function Reload(strand, cb)
    import_areload_all(strand, function()
        
    end, function(...)
        cb(...)
    end)
end

-- 驱动时间
local last_gc_time = 0
function Tick()
    local now_time = os.now()
    if last_gc_time + g_options.collect_garbage_timeout <= now_time then
        collectgarbage("collect")
        last_gc_time = now_time
    else
        collectgarbage("step", 0)
    end
end
