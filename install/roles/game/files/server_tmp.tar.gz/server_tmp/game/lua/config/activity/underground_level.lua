
-- pm.TbUndergroundLevel



return
{
[1] = 
{
	id=1,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=7,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102041,
			num=10000,
		},
	},
},
[2] = 
{
	id=2,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102042,
			num=10000,
		},
	},
},
[3] = 
{
	id=3,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102043,
			num=10000,
		},
	},
},
[4] = 
{
	id=4,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102043,
			num=10000,
		},
	},
},
[5] = 
{
	id=5,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102044,
			num=10000,
		},
	},
},
[6] = 
{
	id=6,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102044,
			num=10000,
		},
	},
},
[7] = 
{
	id=7,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102044,
			num=10000,
		},
	},
},
[8] = 
{
	id=8,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102045,
			num=10000,
		},
	},
},
[9] = 
{
	id=9,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102045,
			num=10000,
		},
	},
},
[10] = 
{
	id=10,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102045,
			num=10000,
		},
	},
},
[11] = 
{
	id=11,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[12] = 
{
	id=12,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[13] = 
{
	id=13,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[14] = 
{
	id=14,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[15] = 
{
	id=15,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[16] = 
{
	id=16,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[17] = 
{
	id=17,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[18] = 
{
	id=18,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[19] = 
{
	id=19,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[20] = 
{
	id=20,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[21] = 
{
	id=21,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[22] = 
{
	id=22,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[23] = 
{
	id=23,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[24] = 
{
	id=24,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[25] = 
{
	id=25,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[26] = 
{
	id=26,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[27] = 
{
	id=27,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[28] = 
{
	id=28,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[29] = 
{
	id=29,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[30] = 
{
	id=30,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[31] = 
{
	id=31,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[32] = 
{
	id=32,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[33] = 
{
	id=33,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[34] = 
{
	id=34,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[35] = 
{
	id=35,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[36] = 
{
	id=36,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[37] = 
{
	id=37,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=1,
			pr=100,
		},
	
		{
			value=5,
			pr=100,
		},
	
		{
			value=6,
			pr=100,
		},
	
		{
			value=7,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[38] = 
{
	id=38,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=2,
			pr=100,
		},
	
		{
			value=14,
			pr=100,
		},
	
		{
			value=15,
			pr=100,
		},
	
		{
			value=16,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[39] = 
{
	id=39,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=3,
			pr=100,
		},
	
		{
			value=8,
			pr=100,
		},
	
		{
			value=9,
			pr=100,
		},
	
		{
			value=10,
			pr=100,
		},
	},
	max_times=38,
	guart_times=0,
	guart_pool=0,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
[40] = 
{
	id=40,
	cost=
	{
		id=316,
		num=1,
	},
	map=
	{
	
		{
			value=4,
			pr=100,
		},
	
		{
			value=11,
			pr=100,
		},
	
		{
			value=12,
			pr=100,
		},
	
		{
			value=13,
			pr=100,
		},
	},
	max_times=38,
	guart_times=38,
	guart_pool=102040,
	optional_num=0,
	optional_reward=
	{
	},
	pool_prob=
	{
	
		{
			id=102046,
			num=10000,
		},
	},
},
}
