local Utility = import("api.service.leaderboard.utility")

local _M = {}

-- 连接字符串
local function join(...)
    local args = {...}
    local total_len = 0
    for _, str in ipairs(args) do
        total_len = total_len + tostring(str):len()
    end
    total_len = total_len + #args - 1 -- 加上分隔符的长度
    
    return table.concat(args, "_", 1, #args)
end

-- 生成排行榜key
-- @param id 排行榜ID
-- @param area_id 区服ID
-- @param tag_id 标签类型
-- @param group_type 分组类型
-- @param extension 扩展字段
-- @return string 排行榜key
function _M.GenerateKey(id, area_id, tag_id, group_type, extension)
    local prefix = string.sub(g_options.domain or "", 2)
    local tag = Utility.GetTagType(tag_id)
    local group = Utility.GetGroupId(group_type, area_id)
    
    local parts = {prefix, group_type, group, tag, id}
    if extension and extension ~= "" then
        parts[#parts + 1] = extension
    end

    return join(table.unpack(parts))
end

return _M