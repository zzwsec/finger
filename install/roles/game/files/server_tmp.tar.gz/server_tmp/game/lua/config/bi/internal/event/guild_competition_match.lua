
-- pm.TbBiInternalEventGuildCompetitionMatch



return
{
[1] = 
{
	id=1,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="match_guild_id",
	name="匹配公会id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="guild_level",
	name="公会等级",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="match_guild_level",
	name="匹配公会等级",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="totle_lives",
	name="公会活跃度",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="match_totle_lives",
	name="匹配公会活跃度",
	type=0,
	opt=1,
	default_value="0",
},
[7] = 
{
	id=7,
	field="member_num",
	name="公会活跃成员数量",
	type=0,
	opt=1,
	default_value="0",
},
[8] = 
{
	id=8,
	field="match_member_num",
	name="匹配公会活跃成员数量",
	type=0,
	opt=1,
	default_value="0",
},
}
