
-- pm.TbCastleLevel



return
{
[1] = 
{
	id=1,
	cost=
	{
	
		{
			id=2,
			num=600,
		},
	},
	wait_time=300,
	productivity=1,
	storage_limit=100,
	reward=
	{
		id=99,
		num=0,
	},
	condition=
	{
	
		{
			type=100,
			value=100,
		},
	},
},
[2] = 
{
	id=2,
	cost=
	{
	
		{
			id=2,
			num=2000,
		},
	},
	wait_time=900,
	productivity=1.1,
	storage_limit=110,
	reward=
	{
		id=99,
		num=11000,
	},
	condition=
	{
	
		{
			type=100,
			value=200,
		},
	},
},
[3] = 
{
	id=3,
	cost=
	{
	
		{
			id=2,
			num=5000,
		},
	},
	wait_time=1800,
	productivity=1.2,
	storage_limit=120,
	reward=
	{
		id=99,
		num=16000,
	},
	condition=
	{
	
		{
			type=100,
			value=500,
		},
	},
},
[4] = 
{
	id=4,
	cost=
	{
	
		{
			id=2,
			num=15000,
		},
	},
	wait_time=2700,
	productivity=1.3,
	storage_limit=130,
	reward=
	{
		id=99,
		num=21000,
	},
	condition=
	{
	
		{
			type=3,
			value=2,
		},
	
		{
			type=4,
			value=1,
		},
	},
},
[5] = 
{
	id=5,
	cost=
	{
	
		{
			id=2,
			num=25000,
		},
	},
	wait_time=5400,
	productivity=1.4,
	storage_limit=140,
	reward=
	{
		id=99,
		num=27000,
	},
	condition=
	{
	
		{
			type=2,
			value=3,
		},
	
		{
			type=4,
			value=2,
		},
	},
},
[6] = 
{
	id=6,
	cost=
	{
	
		{
			id=2,
			num=40000,
		},
	},
	wait_time=9900,
	productivity=1.5,
	storage_limit=150,
	reward=
	{
		id=99,
		num=35000,
	},
	condition=
	{
	
		{
			type=3,
			value=4,
		},
	
		{
			type=2,
			value=4,
		},
	},
},
[7] = 
{
	id=7,
	cost=
	{
	
		{
			id=2,
			num=75000,
		},
	},
	wait_time=27900,
	productivity=1.6,
	storage_limit=160,
	reward=
	{
		id=99,
		num=47000,
	},
	condition=
	{
	
		{
			type=3,
			value=6,
		},
	
		{
			type=4,
			value=4,
		},
	},
},
[8] = 
{
	id=8,
	cost=
	{
	
		{
			id=2,
			num=105000,
		},
	},
	wait_time=54000,
	productivity=1.7,
	storage_limit=170,
	reward=
	{
		id=99,
		num=57000,
	},
	condition=
	{
	
		{
			type=2,
			value=7,
		},
	
		{
			type=5,
			value=1,
		},
	},
},
[9] = 
{
	id=9,
	cost=
	{
	
		{
			id=2,
			num=135000,
		},
	},
	wait_time=108000,
	productivity=1.8,
	storage_limit=180,
	reward=
	{
		id=99,
		num=75000,
	},
	condition=
	{
	
		{
			type=3,
			value=8,
		},
	
		{
			type=2,
			value=7,
		},
	},
},
[10] = 
{
	id=10,
	cost=
	{
	
		{
			id=2,
			num=225000,
		},
	},
	wait_time=187200,
	productivity=1.9,
	storage_limit=190,
	reward=
	{
		id=99,
		num=95000,
	},
	condition=
	{
	
		{
			type=3,
			value=9,
		},
	
		{
			type=4,
			value=6,
		},
	},
},
[11] = 
{
	id=11,
	cost=
	{
	
		{
			id=2,
			num=315000,
		},
	},
	wait_time=226800,
	productivity=2,
	storage_limit=200,
	reward=
	{
		id=99,
		num=109000,
	},
	condition=
	{
	
		{
			type=2,
			value=10,
		},
	
		{
			type=5,
			value=2,
		},
	},
},
[12] = 
{
	id=12,
	cost=
	{
	
		{
			id=2,
			num=400000,
		},
	},
	wait_time=266400,
	productivity=2.1,
	storage_limit=210,
	reward=
	{
		id=99,
		num=122000,
	},
	condition=
	{
	
		{
			type=3,
			value=11,
		},
	
		{
			type=2,
			value=11,
		},
	},
},
[13] = 
{
	id=13,
	cost=
	{
	
		{
			id=2,
			num=500000,
		},
	},
	wait_time=316800,
	productivity=2.2,
	storage_limit=220,
	reward=
	{
		id=99,
		num=142000,
	},
	condition=
	{
	
		{
			type=3,
			value=12,
		},
	
		{
			type=4,
			value=10,
		},
	},
},
[14] = 
{
	id=14,
	cost=
	{
	
		{
			id=2,
			num=600000,
		},
	},
	wait_time=360000,
	productivity=2.3,
	storage_limit=230,
	reward=
	{
		id=99,
		num=156000,
	},
	condition=
	{
	
		{
			type=2,
			value=13,
		},
	
		{
			type=5,
			value=3,
		},
	},
},
[15] = 
{
	id=15,
	cost=
	{
	
		{
			id=2,
			num=700000,
		},
	},
	wait_time=417600,
	productivity=2.4,
	storage_limit=240,
	reward=
	{
		id=99,
		num=175000,
	},
	condition=
	{
	
		{
			type=3,
			value=15,
		},
	
		{
			type=2,
			value=15,
		},
	},
},
[16] = 
{
	id=16,
	cost=
	{
	
		{
			id=2,
			num=800000,
		},
	},
	wait_time=478800,
	productivity=2.5,
	storage_limit=250,
	reward=
	{
		id=99,
		num=195000,
	},
	condition=
	{
	
		{
			type=3,
			value=16,
		},
	
		{
			type=4,
			value=16,
		},
	},
},
[17] = 
{
	id=17,
	cost=
	{
	
		{
			id=2,
			num=915000,
		},
	},
	wait_time=547200,
	productivity=2.6,
	storage_limit=260,
	reward=
	{
		id=99,
		num=217000,
	},
	condition=
	{
	
		{
			type=2,
			value=17,
		},
	
		{
			type=5,
			value=4,
		},
	},
},
[18] = 
{
	id=18,
	cost=
	{
	
		{
			id=2,
			num=1020000,
		},
	},
	wait_time=630000,
	productivity=2.7,
	storage_limit=270,
	reward=
	{
		id=99,
		num=244000,
	},
	condition=
	{
	
		{
			type=3,
			value=18,
		},
	
		{
			type=2,
			value=18,
		},
	},
},
[19] = 
{
	id=19,
	cost=
	{
	
		{
			id=2,
			num=1125000,
		},
	},
	wait_time=727200,
	productivity=2.8,
	storage_limit=280,
	reward=
	{
		id=99,
		num=273000,
	},
	condition=
	{
	
		{
			type=3,
			value=19,
		},
	
		{
			type=4,
			value=19,
		},
	},
},
[20] = 
{
	id=20,
	cost=
	{
	
		{
			id=2,
			num=1350000,
		},
	},
	wait_time=828000,
	productivity=2.9,
	storage_limit=290,
	reward=
	{
		id=99,
		num=303000,
	},
	condition=
	{
	
		{
			type=2,
			value=20,
		},
	
		{
			type=5,
			value=5,
		},
	},
},
[21] = 
{
	id=21,
	cost=
	{
	
		{
			id=2,
			num=1600000,
		},
	},
	wait_time=954000,
	productivity=3,
	storage_limit=300,
	reward=
	{
		id=99,
		num=337000,
	},
	condition=
	{
	
		{
			type=3,
			value=21,
		},
	
		{
			type=2,
			value=21,
		},
	},
},
[22] = 
{
	id=22,
	cost=
	{
	
		{
			id=2,
			num=1850000,
		},
	},
	wait_time=1098000,
	productivity=3.1,
	storage_limit=310,
	reward=
	{
		id=99,
		num=372000,
	},
	condition=
	{
	
		{
			type=3,
			value=22,
		},
	
		{
			type=4,
			value=22,
		},
	},
},
[23] = 
{
	id=23,
	cost=
	{
	
		{
			id=2,
			num=2100000,
		},
	},
	wait_time=1224000,
	productivity=3.2,
	storage_limit=320,
	reward=
	{
		id=99,
		num=400000,
	},
	condition=
	{
	
		{
			type=2,
			value=23,
		},
	
		{
			type=5,
			value=6,
		},
	},
},
[24] = 
{
	id=24,
	cost=
	{
	
		{
			id=2,
			num=2350000,
		},
	},
	wait_time=1350000,
	productivity=3.3,
	storage_limit=330,
	reward=
	{
		id=99,
		num=429000,
	},
	condition=
	{
	
		{
			type=3,
			value=24,
		},
	
		{
			type=2,
			value=24,
		},
	},
},
[25] = 
{
	id=25,
	cost=
	{
	
		{
			id=2,
			num=2600000,
		},
	},
	wait_time=1476000,
	productivity=3.4,
	storage_limit=340,
	reward=
	{
		id=99,
		num=459000,
	},
	condition=
	{
	
		{
			type=3,
			value=25,
		},
	
		{
			type=4,
			value=25,
		},
	},
},
[26] = 
{
	id=26,
	cost=
	{
	
		{
			id=2,
			num=2850000,
		},
	},
	wait_time=1602000,
	productivity=3.5,
	storage_limit=350,
	reward=
	{
		id=99,
		num=488000,
	},
	condition=
	{
	
		{
			type=2,
			value=26,
		},
	
		{
			type=5,
			value=7,
		},
	},
},
[27] = 
{
	id=27,
	cost=
	{
	
		{
			id=2,
			num=3100000,
		},
	},
	wait_time=1728000,
	productivity=3.6,
	storage_limit=360,
	reward=
	{
		id=99,
		num=517000,
	},
	condition=
	{
	
		{
			type=3,
			value=27,
		},
	
		{
			type=2,
			value=27,
		},
	},
},
[28] = 
{
	id=28,
	cost=
	{
	
		{
			id=2,
			num=3350000,
		},
	},
	wait_time=1854000,
	productivity=3.7,
	storage_limit=370,
	reward=
	{
		id=99,
		num=547000,
	},
	condition=
	{
	
		{
			type=3,
			value=28,
		},
	
		{
			type=4,
			value=28,
		},
	},
},
[29] = 
{
	id=29,
	cost=
	{
	
		{
			id=2,
			num=3600000,
		},
	},
	wait_time=1980000,
	productivity=3.8,
	storage_limit=380,
	reward=
	{
		id=99,
		num=576000,
	},
	condition=
	{
	
		{
			type=2,
			value=29,
		},
	
		{
			type=5,
			value=8,
		},
	},
},
[30] = 
{
	id=30,
	cost=
	{
	
		{
			id=2,
			num=3850000,
		},
	},
	wait_time=2106000,
	productivity=3.9,
	storage_limit=390,
	reward=
	{
		id=99,
		num=604000,
	},
	condition=
	{
	},
},
}
