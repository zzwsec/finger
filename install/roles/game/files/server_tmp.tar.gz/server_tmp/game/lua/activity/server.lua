local M = {}

-- 获取游戏服务列表
function M.GetGameServiceIds()
    local game_service_ids = {}
    for _, zone_id in pairs(g_options.zone_ids) do
        local zone_service_ids = g_router_manager:MatchGameService(zone_id)
        for _, game_service_id in pairs(zone_service_ids) do
            game_service_ids[#game_service_ids + 1] = game_service_id
        end
    end
    return game_service_ids
end

return M