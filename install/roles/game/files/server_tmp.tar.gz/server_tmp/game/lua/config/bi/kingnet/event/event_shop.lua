
-- pm.TbBiKingnetEventEventShop



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="事件类型",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="config_id1",
	name="商品id1",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="config_id2",
	name="商品id2",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="num",
	name="商品1购买次数",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="num1",
	name="商品2购买次数",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="status",
	name="状态",
	type=0,
	opt=1,
	default_value="0",
},
[7] = 
{
	id=7,
	field="num2",
	name="商店id",
	type=0,
	opt=1,
	default_value="0",
},
}
