
-- pm.TbBiInternalEventDispatchTaskStart



return
{
[1] = 
{
	id=1,
	field="task_id",
	name="任务id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="pos",
	name="任务位置",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="info",
	name="派遣佣兵信息",
	type=1,
	opt=1,
	default_value="",
},
}
