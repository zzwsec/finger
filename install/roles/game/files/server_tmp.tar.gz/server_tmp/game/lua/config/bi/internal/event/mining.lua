
-- pm.TbBiInternalEventMining



return
{
[1] = 
{
	id=1,
	field="mining_template",
	name="模板id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="mining_depth",
	name="矿场深度",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="mines_id",
	name="矿石id",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="mines_cost",
	name="矿石强度",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="attr_value",
	name="矿镐强度",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="status",
	name="矿石状态",
	type=0,
	opt=1,
	default_value="",
},
}
