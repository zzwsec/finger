
-- pm.TbBiInternalEventChat



return
{
[1] = 
{
	id=1,
	field="type",
	name="聊天类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="receiver_id",
	name="接收者id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="message",
	name="聊天消息",
	type=1,
	opt=1,
	default_value="",
},
}
