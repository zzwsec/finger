local class = require "utils.class"
local Constants = require "core.Constants"

local Composite = require 'core.Composite'

local Selector = class("Selector", Composite)

function Selector:ctor()
    Composite.ctor(self)
    
    self.name = "Selector"
end

function Selector:tick(tick)
    for i = 1, #self.children do
        local v = self.children[i]
        local status = v:_execute(tick)
    end
end

return Selector
