
-- pm.TbBiInternalEventGuildDisband



return
{
[1] = 
{
	id=1,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="guild_level",
	name="公会等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="guild_member",
	name="公会成员",
	type=1,
	opt=1,
	default_value="",
},
}
