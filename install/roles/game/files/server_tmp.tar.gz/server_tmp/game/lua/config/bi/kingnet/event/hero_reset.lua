
-- pm.TbBiKingnetEventHeroReset



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="佣兵id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="佣兵老等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="num1",
	name="佣兵新等级",
	type=0,
	opt=1,
	default_value="",
},
}
