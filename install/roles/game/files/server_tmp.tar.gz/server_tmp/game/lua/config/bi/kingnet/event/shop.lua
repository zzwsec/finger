
-- pm.TbBiKingnetEventShop



return
{
[1] = 
{
	id=1,
	field="type",
	name="商店类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="id",
	name="商店索引",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="config_id1",
	name="商品id",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="num1",
	name="购买商品数量",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="type1",
	name="商品刷新类型",
	type=0,
	opt=1,
	default_value="",
},
}
