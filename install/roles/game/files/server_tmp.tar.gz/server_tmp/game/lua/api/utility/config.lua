local RootConfig = import("config.root", true)
local LeaderboardConfig = import("config.leaderboard.leaderboard", true)

local M = {}

M.ServerOptions = RootConfig.ApiServer

function M.LeaderboardConfig(id)
    return LeaderboardConfig[id]    
end

return M