
-- pm.TbBiInternalEventDispatchTaskRefresh



return
{
[1] = 
{
	id=1,
	field="times",
	name="刷新次数",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="task_num",
	name="刷新任务数量",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="info",
	name="任务信息",
	type=1,
	opt=1,
	default_value="",
},
}
