local _M = {}

-- 分组类型
_M.GroupType = {
    -- 全服
    All = 0,
    -- 单服
    Local = 1,
    -- 跨服
    Group = 2,
}

-- 标签类型
_M.TagType = {
    -- 角色
    Player = 1,
    -- 公会
    Guild = 2,
}

-- 排序规则
_M.SortType = {
    Desc = 1,
    Asc = 2,
}

-- 更新类型
_M.UpdateType = {
    Replace = 1,
    Aggregate = 2,
    Best = 3,
}

return _M