
-- pm.TbBiKingnetEventPvp



return
{
[1] = 
{
	id=1,
	field="id",
	name="战报id",
	type=1,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="status",
	name="输赢",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="id1",
	name="攻方id",
	type=1,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="num",
	name="攻方老分数",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="num1",
	name="攻方变更分数",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="num4",
	name="攻方战力",
	type=0,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="id2",
	name="守方id",
	type=1,
	opt=1,
	default_value="",
},
[8] = 
{
	id=8,
	field="num2",
	name="守方老分数",
	type=0,
	opt=1,
	default_value="",
},
[9] = 
{
	id=9,
	field="num3",
	name="守方变更分数",
	type=0,
	opt=1,
	default_value="",
},
[10] = 
{
	id=10,
	field="num5",
	name="守方战力",
	type=0,
	opt=1,
	default_value="",
},
}
