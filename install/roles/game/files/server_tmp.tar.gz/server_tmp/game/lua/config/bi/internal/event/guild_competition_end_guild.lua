
-- pm.TbBiInternalEventGuildCompetitionEndGuild



return
{
[1] = 
{
	id=1,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="today_contribute",
	name="公会今日贡献",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="totle_contribute",
	name="公会总贡献",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="totle_score",
	name="公会总积分",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="today_score",
	name="今日获胜积分",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="day_win",
	name="每日胜利状态",
	type=0,
	opt=1,
	default_value="0",
},
[7] = 
{
	id=7,
	field="week_win",
	name="每周胜利状态",
	type=0,
	opt=1,
	default_value="0",
},
}
