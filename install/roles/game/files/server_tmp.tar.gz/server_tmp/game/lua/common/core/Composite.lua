local class = require "utils.class"

local BaseNode = require 'core.BaseNode'

local Composite = class("Composite", BaseNode)

function Composite:ctor(params)
    self.children = (params and params.children) or {}
end

return Composite