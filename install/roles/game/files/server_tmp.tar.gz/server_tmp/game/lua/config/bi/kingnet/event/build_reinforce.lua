
-- pm.TbBiKingnetEventBuildReinforce



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="建筑id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="建筑等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="num1",
	name="当前等级加固次数",
	type=0,
	opt=1,
	default_value="",
},
}
