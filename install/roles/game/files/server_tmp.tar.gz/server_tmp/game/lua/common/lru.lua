

local _M = class("lru")

function _M:ctor(max_size)
    -- 数据存储表 {key = { value = value, expire = timestamp}}
    self.store = {}
    self.keys = {}
    self.key_to_idx = {}
    self.max_size = max_size
    self.size = 0
end

-- 提升key到最前面
local function _promote(self, key)
    local idx = self.key_to_idx[key]
    if idx then 
        table.remove(self.keys, idx) 
        for i = idx, #self.keys do
            self.key_to_idx[self.keys[i]] = i
        end
        table.insert(self.keys, 1, key)
        self.key_to_idx[key] = 1
    end
end

-- 淘汰最老的key
local function _evict(self)
    if self.size > 0 then
        local oldest_key = table.remove(self.keys)
        self.store[oldest_key] = nil
        self.key_to_idx[oldest_key] = nil
        self.size = self.size - 1
    end
end

local function _is_expired(item, now)
    return item.expire and item.expire < (now or os.now())
end

function _M:get(key)
    local item = self.store[key]
    if item then 
        if _is_expired(item) then
            self:delete(key)
            return nil
        end
        _promote(self, key)
        return item.value
    end
end

function _M:set(key, value, ttl)
    if value == nil then 
        return self:delete(key)
    end
    local item = { 
        value = value, 
        expire = ttl and (os.now() + math.max(ttl, 0)) or nil
    }
    if not self.store[key] then
        if self.size >= self.max_size then
            _evict(self)
        end
        self.size = self.size + 1
        table.insert(self.keys, 1, key)
        self.key_to_idx[key] = 1
    else 
        _promote(self, key)
    end
    self.store[key] = item
    return true
end

function _M:delete(key)
    local idx = self.key_to_idx[key]
    if idx then 
        table.remove(self.keys, idx)
        self.key_to_idx[key] = nil
        self.store[key] = nil
        self.size = self.size - 1
        -- 更新key_to_idx
        for i = idx, #self.keys do
            self.key_to_idx[self.keys[i]] = i
        end
        return true
    end
    return false
end

function _M:flush()
    self.store = {}
    self.keys = {}
    self.key_to_idx = {}
    self.size = 0
end

function _M:count()
    return self.size
end

function _M:capacity()
    return self.max_size
end

function _M:keys()
    local result = {}
    local now = os.now() 
    for _, key in ipairs(self.keys) do
        local item = self.store[key]
        if item and not _is_expired(item, now) then
            table.insert(result, key)
        end
    end
    return result
end

function _M:purge()
    local now = os.now()
    local i = 1
    while i <= #self.keys do
        local key = self.keys[i]
        local item = self.store[key]
        if item and _is_expired(item, now) then
            self:delete(key)
        else
            i = i + 1
        end
    end
end

function _M:ttl(key)
    local item = self.store[key]
    if item and item.expire then
        local remaining = item.expire - os.now()
        return remaining > 0 and remaining or nil
    end
    return nil
end

return _M
