
-- pm.TbBiInternalEventCompetitionStart



return
{
[1] = 
{
	id=1,
	field="type",
	name="排名类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="value",
	name="活动数据",
	type=0,
	opt=1,
	default_value="",
},
}
