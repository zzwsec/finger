
-- pm.TbXdaysTaskRewards



return
{
[1] = 
{
	id=1,
	num=60,
	rewards=
	{
		id=3,
		num=100,
	},
},
[2] = 
{
	id=2,
	num=120,
	rewards=
	{
		id=33,
		num=100,
	},
},
[3] = 
{
	id=3,
	num=180,
	rewards=
	{
		id=1,
		num=1000,
	},
},
[4] = 
{
	id=4,
	num=250,
	rewards=
	{
		id=39,
		num=10,
	},
},
[5] = 
{
	id=5,
	num=330,
	rewards=
	{
		id=15,
		num=3000,
	},
},
[6] = 
{
	id=6,
	num=400,
	rewards=
	{
		id=1,
		num=1000,
	},
},
[7] = 
{
	id=7,
	num=480,
	rewards=
	{
		id=14,
		num=100,
	},
},
[8] = 
{
	id=8,
	num=560,
	rewards=
	{
		id=12,
		num=20,
	},
},
[9] = 
{
	id=9,
	num=650,
	rewards=
	{
		id=1,
		num=1000,
	},
},
[10] = 
{
	id=10,
	num=750,
	rewards=
	{
		id=6013,
		num=1,
	},
},
}
