
-- pm.TbRuinMonster



return
{
[101] = 
{
	id=101,
	type=1,
	level=1,
	name={key='minig_monster/101',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=32064,
	npc_attrs=
	{
	
		{
			id=100,
			value=58,
		},
	
		{
			id=101,
			value=20152,
		},
	
		{
			id=102,
			value=2168,
		},
	
		{
			id=103,
			value=694,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[102] = 
{
	id=102,
	type=1,
	level=2,
	name={key='minig_monster/102',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=35491,
	npc_attrs=
	{
	
		{
			id=100,
			value=69,
		},
	
		{
			id=101,
			value=22275,
		},
	
		{
			id=102,
			value=2410,
		},
	
		{
			id=103,
			value=756,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[103] = 
{
	id=103,
	type=1,
	level=3,
	name={key='minig_monster/103',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=45752,
	npc_attrs=
	{
	
		{
			id=100,
			value=83,
		},
	
		{
			id=101,
			value=28204,
		},
	
		{
			id=102,
			value=3247,
		},
	
		{
			id=103,
			value=974,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[104] = 
{
	id=104,
	type=1,
	level=4,
	name={key='minig_monster/104',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=56580,
	npc_attrs=
	{
	
		{
			id=100,
			value=122,
		},
	
		{
			id=101,
			value=31625,
		},
	
		{
			id=102,
			value=3626,
		},
	
		{
			id=103,
			value=1083,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[105] = 
{
	id=105,
	type=1,
	level=5,
	name={key='minig_monster/101',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=136551,
	npc_attrs=
	{
	
		{
			id=100,
			value=370,
		},
	
		{
			id=101,
			value=53042,
		},
	
		{
			id=102,
			value=5779,
		},
	
		{
			id=103,
			value=2388,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0.09,
		},
	
		{
			id=142,
			value=0.09,
		},
	
		{
			id=143,
			value=0.09,
		},
	
		{
			id=144,
			value=0.09,
		},
	
		{
			id=145,
			value=0.09,
		},
	
		{
			id=146,
			value=0.09,
		},
	},
},
[106] = 
{
	id=106,
	type=1,
	level=6,
	name={key='minig_monster/102',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=201462,
	npc_attrs=
	{
	
		{
			id=100,
			value=458,
		},
	
		{
			id=101,
			value=65989,
		},
	
		{
			id=102,
			value=7165,
		},
	
		{
			id=103,
			value=2974,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.09,
		},
	
		{
			id=142,
			value=0.09,
		},
	
		{
			id=143,
			value=0.09,
		},
	
		{
			id=144,
			value=0.09,
		},
	
		{
			id=145,
			value=0.09,
		},
	
		{
			id=146,
			value=0.09,
		},
	},
},
[107] = 
{
	id=107,
	type=1,
	level=7,
	name={key='minig_monster/103',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=261901,
	npc_attrs=
	{
	
		{
			id=100,
			value=593,
		},
	
		{
			id=101,
			value=77429,
		},
	
		{
			id=102,
			value=8545,
		},
	
		{
			id=103,
			value=3519,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[108] = 
{
	id=108,
	type=1,
	level=8,
	name={key='minig_monster/104',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=288672,
	npc_attrs=
	{
	
		{
			id=100,
			value=684,
		},
	
		{
			id=101,
			value=84909,
		},
	
		{
			id=102,
			value=9417,
		},
	
		{
			id=103,
			value=3928,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[109] = 
{
	id=109,
	type=1,
	level=9,
	name={key='minig_monster/101',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=315691,
	npc_attrs=
	{
	
		{
			id=100,
			value=757,
		},
	
		{
			id=101,
			value=92521,
		},
	
		{
			id=102,
			value=10343,
		},
	
		{
			id=103,
			value=4317,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[110] = 
{
	id=110,
	type=1,
	level=10,
	name={key='minig_monster/102',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=350966,
	npc_attrs=
	{
	
		{
			id=100,
			value=1184,
		},
	
		{
			id=101,
			value=93104,
		},
	
		{
			id=102,
			value=12095,
		},
	
		{
			id=103,
			value=5957,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[111] = 
{
	id=111,
	type=1,
	level=11,
	name={key='minig_monster/103',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=428687,
	npc_attrs=
	{
	
		{
			id=100,
			value=1290,
		},
	
		{
			id=101,
			value=114026,
		},
	
		{
			id=102,
			value=14955,
		},
	
		{
			id=103,
			value=7331,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[112] = 
{
	id=112,
	type=1,
	level=12,
	name={key='minig_monster/104',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=465580,
	npc_attrs=
	{
	
		{
			id=100,
			value=1422,
		},
	
		{
			id=101,
			value=123299,
		},
	
		{
			id=102,
			value=16312,
		},
	
		{
			id=103,
			value=7985,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[113] = 
{
	id=113,
	type=1,
	level=13,
	name={key='minig_monster/101',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=488399,
	npc_attrs=
	{
	
		{
			id=100,
			value=1509,
		},
	
		{
			id=101,
			value=128975,
		},
	
		{
			id=102,
			value=17162,
		},
	
		{
			id=103,
			value=8383,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[114] = 
{
	id=114,
	type=1,
	level=14,
	name={key='minig_monster/102',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=518140,
	npc_attrs=
	{
	
		{
			id=100,
			value=1628,
		},
	
		{
			id=101,
			value=136202,
		},
	
		{
			id=102,
			value=18289,
		},
	
		{
			id=103,
			value=8914,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[115] = 
{
	id=115,
	type=1,
	level=15,
	name={key='minig_monster/103',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=541280,
	npc_attrs=
	{
	
		{
			id=100,
			value=1395,
		},
	
		{
			id=101,
			value=143286,
		},
	
		{
			id=102,
			value=19376,
		},
	
		{
			id=103,
			value=9403,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[116] = 
{
	id=116,
	type=1,
	level=16,
	name={key='minig_monster/104',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=699120,
	npc_attrs=
	{
	
		{
			id=100,
			value=1540,
		},
	
		{
			id=101,
			value=146355,
		},
	
		{
			id=102,
			value=23559,
		},
	
		{
			id=103,
			value=13863,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.0912,
		},
	
		{
			id=122,
			value=0.0912,
		},
	
		{
			id=123,
			value=0.0912,
		},
	
		{
			id=124,
			value=0.0912,
		},
	
		{
			id=125,
			value=0.0912,
		},
	
		{
			id=126,
			value=0.0912,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[117] = 
{
	id=117,
	type=1,
	level=17,
	name={key='minig_monster/101',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=801386,
	npc_attrs=
	{
	
		{
			id=100,
			value=1619,
		},
	
		{
			id=101,
			value=164791,
		},
	
		{
			id=102,
			value=27574,
		},
	
		{
			id=103,
			value=15800,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.0916,
		},
	
		{
			id=122,
			value=0.0916,
		},
	
		{
			id=123,
			value=0.0916,
		},
	
		{
			id=124,
			value=0.0916,
		},
	
		{
			id=125,
			value=0.0916,
		},
	
		{
			id=126,
			value=0.0916,
		},
	
		{
			id=141,
			value=0.122,
		},
	
		{
			id=142,
			value=0.122,
		},
	
		{
			id=143,
			value=0.122,
		},
	
		{
			id=144,
			value=0.122,
		},
	
		{
			id=145,
			value=0.122,
		},
	
		{
			id=146,
			value=0.122,
		},
	},
},
[118] = 
{
	id=118,
	type=1,
	level=18,
	name={key='minig_monster/102',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=958528,
	npc_attrs=
	{
	
		{
			id=100,
			value=1838,
		},
	
		{
			id=101,
			value=179916,
		},
	
		{
			id=102,
			value=30658,
		},
	
		{
			id=103,
			value=17469,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.092,
		},
	
		{
			id=122,
			value=0.092,
		},
	
		{
			id=123,
			value=0.092,
		},
	
		{
			id=124,
			value=0.092,
		},
	
		{
			id=125,
			value=0.092,
		},
	
		{
			id=126,
			value=0.092,
		},
	
		{
			id=141,
			value=0.154,
		},
	
		{
			id=142,
			value=0.154,
		},
	
		{
			id=143,
			value=0.154,
		},
	
		{
			id=144,
			value=0.154,
		},
	
		{
			id=145,
			value=0.154,
		},
	
		{
			id=146,
			value=0.154,
		},
	},
},
[119] = 
{
	id=119,
	type=1,
	level=19,
	name={key='minig_monster/103',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=1141001,
	npc_attrs=
	{
	
		{
			id=100,
			value=1920,
		},
	
		{
			id=101,
			value=186956,
		},
	
		{
			id=102,
			value=35006,
		},
	
		{
			id=103,
			value=19325,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.116,
		},
	
		{
			id=122,
			value=0.116,
		},
	
		{
			id=123,
			value=0.116,
		},
	
		{
			id=124,
			value=0.116,
		},
	
		{
			id=125,
			value=0.116,
		},
	
		{
			id=126,
			value=0.116,
		},
	
		{
			id=141,
			value=0.1705,
		},
	
		{
			id=142,
			value=0.1705,
		},
	
		{
			id=143,
			value=0.1705,
		},
	
		{
			id=144,
			value=0.1705,
		},
	
		{
			id=145,
			value=0.1705,
		},
	
		{
			id=146,
			value=0.1705,
		},
	},
},
[120] = 
{
	id=120,
	type=1,
	level=20,
	name={key='minig_monster/104',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=2000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=1212385,
	npc_attrs=
	{
	
		{
			id=100,
			value=2026,
		},
	
		{
			id=101,
			value=196977,
		},
	
		{
			id=102,
			value=37194,
		},
	
		{
			id=103,
			value=20396,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1164,
		},
	
		{
			id=122,
			value=0.1164,
		},
	
		{
			id=123,
			value=0.1164,
		},
	
		{
			id=124,
			value=0.1164,
		},
	
		{
			id=125,
			value=0.1164,
		},
	
		{
			id=126,
			value=0.1164,
		},
	
		{
			id=141,
			value=0.1725,
		},
	
		{
			id=142,
			value=0.1725,
		},
	
		{
			id=143,
			value=0.1725,
		},
	
		{
			id=144,
			value=0.1725,
		},
	
		{
			id=145,
			value=0.1725,
		},
	
		{
			id=146,
			value=0.1725,
		},
	},
},
[201] = 
{
	id=201,
	type=2,
	level=1,
	name={key='minig_monster/201',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=438490,
	npc_attrs=
	{
	
		{
			id=100,
			value=806,
		},
	
		{
			id=101,
			value=152400,
		},
	
		{
			id=102,
			value=11034,
		},
	
		{
			id=103,
			value=3847,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[202] = 
{
	id=202,
	type=2,
	level=2,
	name={key='minig_monster/202',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=564635,
	npc_attrs=
	{
	
		{
			id=100,
			value=1041,
		},
	
		{
			id=101,
			value=195585,
		},
	
		{
			id=102,
			value=14332,
		},
	
		{
			id=103,
			value=4988,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[203] = 
{
	id=203,
	type=2,
	level=3,
	name={key='minig_monster/203',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=626644,
	npc_attrs=
	{
	
		{
			id=100,
			value=1169,
		},
	
		{
			id=101,
			value=216450,
		},
	
		{
			id=102,
			value=16011,
		},
	
		{
			id=103,
			value=5557,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[204] = 
{
	id=204,
	type=2,
	level=4,
	name={key='minig_monster/204',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=681551,
	npc_attrs=
	{
	
		{
			id=100,
			value=1307,
		},
	
		{
			id=101,
			value=234510,
		},
	
		{
			id=102,
			value=17554,
		},
	
		{
			id=103,
			value=6059,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[205] = 
{
	id=205,
	type=2,
	level=5,
	name={key='minig_monster/201',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=907401,
	npc_attrs=
	{
	
		{
			id=100,
			value=733,
		},
	
		{
			id=101,
			value=268890,
		},
	
		{
			id=102,
			value=22127,
		},
	
		{
			id=103,
			value=9242,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.0912,
		},
	
		{
			id=122,
			value=0.0912,
		},
	
		{
			id=123,
			value=0.0912,
		},
	
		{
			id=124,
			value=0.0912,
		},
	
		{
			id=125,
			value=0.0912,
		},
	
		{
			id=126,
			value=0.0912,
		},
	
		{
			id=141,
			value=0.12,
		},
	
		{
			id=142,
			value=0.12,
		},
	
		{
			id=143,
			value=0.12,
		},
	
		{
			id=144,
			value=0.12,
		},
	
		{
			id=145,
			value=0.12,
		},
	
		{
			id=146,
			value=0.12,
		},
	},
},
[206] = 
{
	id=206,
	type=2,
	level=6,
	name={key='minig_monster/202',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=1213733,
	npc_attrs=
	{
	
		{
			id=100,
			value=1134,
		},
	
		{
			id=101,
			value=325260,
		},
	
		{
			id=102,
			value=28005,
		},
	
		{
			id=103,
			value=11379,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.0916,
		},
	
		{
			id=122,
			value=0.0916,
		},
	
		{
			id=123,
			value=0.0916,
		},
	
		{
			id=124,
			value=0.0916,
		},
	
		{
			id=125,
			value=0.0916,
		},
	
		{
			id=126,
			value=0.0916,
		},
	
		{
			id=141,
			value=0.153,
		},
	
		{
			id=142,
			value=0.153,
		},
	
		{
			id=143,
			value=0.153,
		},
	
		{
			id=144,
			value=0.153,
		},
	
		{
			id=145,
			value=0.153,
		},
	
		{
			id=146,
			value=0.153,
		},
	},
},
[207] = 
{
	id=207,
	type=2,
	level=7,
	name={key='minig_monster/203',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=1508325,
	npc_attrs=
	{
	
		{
			id=100,
			value=1544,
		},
	
		{
			id=101,
			value=356280,
		},
	
		{
			id=102,
			value=33305,
		},
	
		{
			id=103,
			value=13068,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.116,
		},
	
		{
			id=122,
			value=0.116,
		},
	
		{
			id=123,
			value=0.116,
		},
	
		{
			id=124,
			value=0.116,
		},
	
		{
			id=125,
			value=0.116,
		},
	
		{
			id=126,
			value=0.116,
		},
	
		{
			id=141,
			value=0.171,
		},
	
		{
			id=142,
			value=0.171,
		},
	
		{
			id=143,
			value=0.171,
		},
	
		{
			id=144,
			value=0.171,
		},
	
		{
			id=145,
			value=0.171,
		},
	
		{
			id=146,
			value=0.171,
		},
	},
},
[208] = 
{
	id=208,
	type=2,
	level=8,
	name={key='minig_monster/204',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=1652523,
	npc_attrs=
	{
	
		{
			id=100,
			value=2079,
		},
	
		{
			id=101,
			value=384060,
		},
	
		{
			id=102,
			value=36248,
		},
	
		{
			id=103,
			value=14093,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1168,
		},
	
		{
			id=122,
			value=0.1168,
		},
	
		{
			id=123,
			value=0.1168,
		},
	
		{
			id=124,
			value=0.1168,
		},
	
		{
			id=125,
			value=0.1168,
		},
	
		{
			id=126,
			value=0.1168,
		},
	
		{
			id=141,
			value=0.174,
		},
	
		{
			id=142,
			value=0.174,
		},
	
		{
			id=143,
			value=0.174,
		},
	
		{
			id=144,
			value=0.174,
		},
	
		{
			id=145,
			value=0.174,
		},
	
		{
			id=146,
			value=0.174,
		},
	},
},
[209] = 
{
	id=209,
	type=2,
	level=9,
	name={key='minig_monster/201',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=1819850,
	npc_attrs=
	{
	
		{
			id=100,
			value=2272,
		},
	
		{
			id=101,
			value=417690,
		},
	
		{
			id=102,
			value=40192,
		},
	
		{
			id=103,
			value=15373,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1172,
		},
	
		{
			id=122,
			value=0.1172,
		},
	
		{
			id=123,
			value=0.1172,
		},
	
		{
			id=124,
			value=0.1172,
		},
	
		{
			id=125,
			value=0.1172,
		},
	
		{
			id=126,
			value=0.1172,
		},
	
		{
			id=141,
			value=0.177,
		},
	
		{
			id=142,
			value=0.177,
		},
	
		{
			id=143,
			value=0.177,
		},
	
		{
			id=144,
			value=0.177,
		},
	
		{
			id=145,
			value=0.177,
		},
	
		{
			id=146,
			value=0.177,
		},
	},
},
[210] = 
{
	id=210,
	type=2,
	level=10,
	name={key='minig_monster/202',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=2346664,
	npc_attrs=
	{
	
		{
			id=100,
			value=2498,
		},
	
		{
			id=101,
			value=467040,
		},
	
		{
			id=102,
			value=51046,
		},
	
		{
			id=103,
			value=21484,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1416,
		},
	
		{
			id=122,
			value=0.1416,
		},
	
		{
			id=123,
			value=0.1416,
		},
	
		{
			id=124,
			value=0.1416,
		},
	
		{
			id=125,
			value=0.1416,
		},
	
		{
			id=126,
			value=0.1416,
		},
	
		{
			id=141,
			value=0.195,
		},
	
		{
			id=142,
			value=0.195,
		},
	
		{
			id=143,
			value=0.195,
		},
	
		{
			id=144,
			value=0.195,
		},
	
		{
			id=145,
			value=0.195,
		},
	
		{
			id=146,
			value=0.195,
		},
	},
},
[211] = 
{
	id=211,
	type=2,
	level=11,
	name={key='minig_monster/203',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=2912419,
	npc_attrs=
	{
	
		{
			id=100,
			value=2824,
		},
	
		{
			id=101,
			value=511110,
		},
	
		{
			id=102,
			value=57022,
		},
	
		{
			id=103,
			value=23701,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.142,
		},
	
		{
			id=122,
			value=0.142,
		},
	
		{
			id=123,
			value=0.142,
		},
	
		{
			id=124,
			value=0.142,
		},
	
		{
			id=125,
			value=0.142,
		},
	
		{
			id=126,
			value=0.142,
		},
	
		{
			id=141,
			value=0.258,
		},
	
		{
			id=142,
			value=0.258,
		},
	
		{
			id=143,
			value=0.258,
		},
	
		{
			id=144,
			value=0.258,
		},
	
		{
			id=145,
			value=0.258,
		},
	
		{
			id=146,
			value=0.258,
		},
	},
},
[212] = 
{
	id=212,
	type=2,
	level=12,
	name={key='minig_monster/204',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=3611600,
	npc_attrs=
	{
	
		{
			id=100,
			value=3210,
		},
	
		{
			id=101,
			value=583080,
		},
	
		{
			id=102,
			value=66039,
		},
	
		{
			id=103,
			value=27151,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1856,
		},
	
		{
			id=122,
			value=0.1856,
		},
	
		{
			id=123,
			value=0.1856,
		},
	
		{
			id=124,
			value=0.1856,
		},
	
		{
			id=125,
			value=0.1856,
		},
	
		{
			id=126,
			value=0.1856,
		},
	
		{
			id=141,
			value=0.261,
		},
	
		{
			id=142,
			value=0.261,
		},
	
		{
			id=143,
			value=0.261,
		},
	
		{
			id=144,
			value=0.261,
		},
	
		{
			id=145,
			value=0.261,
		},
	
		{
			id=146,
			value=0.261,
		},
	},
},
[213] = 
{
	id=213,
	type=2,
	level=13,
	name={key='minig_monster/201',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=3874820,
	npc_attrs=
	{
	
		{
			id=100,
			value=3437,
		},
	
		{
			id=101,
			value=618870,
		},
	
		{
			id=102,
			value=71157,
		},
	
		{
			id=103,
			value=28894,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1864,
		},
	
		{
			id=122,
			value=0.1864,
		},
	
		{
			id=123,
			value=0.1864,
		},
	
		{
			id=124,
			value=0.1864,
		},
	
		{
			id=125,
			value=0.1864,
		},
	
		{
			id=126,
			value=0.1864,
		},
	
		{
			id=141,
			value=0.264,
		},
	
		{
			id=142,
			value=0.264,
		},
	
		{
			id=143,
			value=0.264,
		},
	
		{
			id=144,
			value=0.264,
		},
	
		{
			id=145,
			value=0.264,
		},
	
		{
			id=146,
			value=0.264,
		},
	},
},
[214] = 
{
	id=214,
	type=2,
	level=14,
	name={key='minig_monster/202',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=6377461,
	npc_attrs=
	{
	
		{
			id=100,
			value=3934,
		},
	
		{
			id=101,
			value=762765,
		},
	
		{
			id=102,
			value=86855,
		},
	
		{
			id=103,
			value=35332,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3148,
		},
	
		{
			id=122,
			value=0.3148,
		},
	
		{
			id=123,
			value=0.3148,
		},
	
		{
			id=124,
			value=0.3148,
		},
	
		{
			id=125,
			value=0.3148,
		},
	
		{
			id=126,
			value=0.3148,
		},
	
		{
			id=141,
			value=0.347,
		},
	
		{
			id=142,
			value=0.347,
		},
	
		{
			id=143,
			value=0.347,
		},
	
		{
			id=144,
			value=0.347,
		},
	
		{
			id=145,
			value=0.347,
		},
	
		{
			id=146,
			value=0.347,
		},
	},
},
[215] = 
{
	id=215,
	type=2,
	level=15,
	name={key='minig_monster/203',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=6960457,
	npc_attrs=
	{
	
		{
			id=100,
			value=4254,
		},
	
		{
			id=101,
			value=824490,
		},
	
		{
			id=102,
			value=95662,
		},
	
		{
			id=103,
			value=38344,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3152,
		},
	
		{
			id=122,
			value=0.3152,
		},
	
		{
			id=123,
			value=0.3152,
		},
	
		{
			id=124,
			value=0.3152,
		},
	
		{
			id=125,
			value=0.3152,
		},
	
		{
			id=126,
			value=0.3152,
		},
	
		{
			id=141,
			value=0.35,
		},
	
		{
			id=142,
			value=0.35,
		},
	
		{
			id=143,
			value=0.35,
		},
	
		{
			id=144,
			value=0.35,
		},
	
		{
			id=145,
			value=0.35,
		},
	
		{
			id=146,
			value=0.35,
		},
	},
},
[216] = 
{
	id=216,
	type=2,
	level=16,
	name={key='minig_monster/204',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=6825072,
	npc_attrs=
	{
	
		{
			id=100,
			value=4508,
		},
	
		{
			id=101,
			value=715215,
		},
	
		{
			id=102,
			value=102218,
		},
	
		{
			id=103,
			value=50426,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3156,
		},
	
		{
			id=122,
			value=0.3156,
		},
	
		{
			id=123,
			value=0.3156,
		},
	
		{
			id=124,
			value=0.3156,
		},
	
		{
			id=125,
			value=0.3156,
		},
	
		{
			id=126,
			value=0.3156,
		},
	
		{
			id=141,
			value=0.353,
		},
	
		{
			id=142,
			value=0.353,
		},
	
		{
			id=143,
			value=0.353,
		},
	
		{
			id=144,
			value=0.353,
		},
	
		{
			id=145,
			value=0.353,
		},
	
		{
			id=146,
			value=0.353,
		},
	},
},
[217] = 
{
	id=217,
	type=2,
	level=17,
	name={key='minig_monster/201',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=8340824,
	npc_attrs=
	{
	
		{
			id=100,
			value=4715,
		},
	
		{
			id=101,
			value=760995,
		},
	
		{
			id=102,
			value=130253,
		},
	
		{
			id=103,
			value=60264,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.348,
		},
	
		{
			id=122,
			value=0.348,
		},
	
		{
			id=123,
			value=0.348,
		},
	
		{
			id=124,
			value=0.348,
		},
	
		{
			id=125,
			value=0.348,
		},
	
		{
			id=126,
			value=0.348,
		},
	
		{
			id=141,
			value=0.376,
		},
	
		{
			id=142,
			value=0.376,
		},
	
		{
			id=143,
			value=0.376,
		},
	
		{
			id=144,
			value=0.376,
		},
	
		{
			id=145,
			value=0.376,
		},
	
		{
			id=146,
			value=0.376,
		},
	},
},
[218] = 
{
	id=218,
	type=2,
	level=18,
	name={key='minig_monster/202',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=8819342,
	npc_attrs=
	{
	
		{
			id=100,
			value=4977,
		},
	
		{
			id=101,
			value=796395,
		},
	
		{
			id=102,
			value=138714,
		},
	
		{
			id=103,
			value=63062,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3488,
		},
	
		{
			id=122,
			value=0.3488,
		},
	
		{
			id=123,
			value=0.3488,
		},
	
		{
			id=124,
			value=0.3488,
		},
	
		{
			id=125,
			value=0.3488,
		},
	
		{
			id=126,
			value=0.3488,
		},
	
		{
			id=141,
			value=0.379,
		},
	
		{
			id=142,
			value=0.379,
		},
	
		{
			id=143,
			value=0.379,
		},
	
		{
			id=144,
			value=0.379,
		},
	
		{
			id=145,
			value=0.379,
		},
	
		{
			id=146,
			value=0.379,
		},
	},
},
[219] = 
{
	id=219,
	type=2,
	level=19,
	name={key='minig_monster/203',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=9980025,
	npc_attrs=
	{
	
		{
			id=100,
			value=5453,
		},
	
		{
			id=101,
			value=887760,
		},
	
		{
			id=102,
			value=160078,
		},
	
		{
			id=103,
			value=70212,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3492,
		},
	
		{
			id=122,
			value=0.3492,
		},
	
		{
			id=123,
			value=0.3492,
		},
	
		{
			id=124,
			value=0.3492,
		},
	
		{
			id=125,
			value=0.3492,
		},
	
		{
			id=126,
			value=0.3492,
		},
	
		{
			id=141,
			value=0.382,
		},
	
		{
			id=142,
			value=0.382,
		},
	
		{
			id=143,
			value=0.382,
		},
	
		{
			id=144,
			value=0.382,
		},
	
		{
			id=145,
			value=0.382,
		},
	
		{
			id=146,
			value=0.382,
		},
	},
},
[220] = 
{
	id=220,
	type=2,
	level=20,
	name={key='minig_monster/204',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=2000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=13958901,
	npc_attrs=
	{
	
		{
			id=100,
			value=5820,
		},
	
		{
			id=101,
			value=1110675,
		},
	
		{
			id=102,
			value=189076,
		},
	
		{
			id=103,
			value=76283,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3816,
		},
	
		{
			id=122,
			value=0.3816,
		},
	
		{
			id=123,
			value=0.3816,
		},
	
		{
			id=124,
			value=0.3816,
		},
	
		{
			id=125,
			value=0.3816,
		},
	
		{
			id=126,
			value=0.3816,
		},
	
		{
			id=141,
			value=0.405,
		},
	
		{
			id=142,
			value=0.405,
		},
	
		{
			id=143,
			value=0.405,
		},
	
		{
			id=144,
			value=0.405,
		},
	
		{
			id=145,
			value=0.405,
		},
	
		{
			id=146,
			value=0.405,
		},
	},
},
[301] = 
{
	id=301,
	type=3,
	level=1,
	name={key='minig_monster/301',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=2935521,
	npc_attrs=
	{
	
		{
			id=100,
			value=2966,
		},
	
		{
			id=101,
			value=702324,
		},
	
		{
			id=102,
			value=46457,
		},
	
		{
			id=103,
			value=14587,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1416,
		},
	
		{
			id=122,
			value=0.1416,
		},
	
		{
			id=123,
			value=0.1416,
		},
	
		{
			id=124,
			value=0.1416,
		},
	
		{
			id=125,
			value=0.1416,
		},
	
		{
			id=126,
			value=0.1416,
		},
	
		{
			id=141,
			value=0.196,
		},
	
		{
			id=142,
			value=0.196,
		},
	
		{
			id=143,
			value=0.196,
		},
	
		{
			id=144,
			value=0.196,
		},
	
		{
			id=145,
			value=0.196,
		},
	
		{
			id=146,
			value=0.196,
		},
	},
},
[302] = 
{
	id=302,
	type=3,
	level=2,
	name={key='minig_monster/302',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=3968709,
	npc_attrs=
	{
	
		{
			id=100,
			value=3416,
		},
	
		{
			id=101,
			value=778536,
		},
	
		{
			id=102,
			value=52749,
		},
	
		{
			id=103,
			value=16310,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.1856,
		},
	
		{
			id=122,
			value=0.1856,
		},
	
		{
			id=123,
			value=0.1856,
		},
	
		{
			id=124,
			value=0.1856,
		},
	
		{
			id=125,
			value=0.1856,
		},
	
		{
			id=126,
			value=0.1856,
		},
	
		{
			id=141,
			value=0.259,
		},
	
		{
			id=142,
			value=0.259,
		},
	
		{
			id=143,
			value=0.259,
		},
	
		{
			id=144,
			value=0.259,
		},
	
		{
			id=145,
			value=0.259,
		},
	
		{
			id=146,
			value=0.259,
		},
	},
},
[303] = 
{
	id=303,
	type=3,
	level=3,
	name={key='minig_monster/303',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=4497729,
	npc_attrs=
	{
	
		{
			id=100,
			value=3786,
		},
	
		{
			id=101,
			value=876330,
		},
	
		{
			id=102,
			value=59852,
		},
	
		{
			id=103,
			value=18383,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.186,
		},
	
		{
			id=122,
			value=0.186,
		},
	
		{
			id=123,
			value=0.186,
		},
	
		{
			id=124,
			value=0.186,
		},
	
		{
			id=125,
			value=0.186,
		},
	
		{
			id=126,
			value=0.186,
		},
	
		{
			id=141,
			value=0.262,
		},
	
		{
			id=142,
			value=0.262,
		},
	
		{
			id=143,
			value=0.262,
		},
	
		{
			id=144,
			value=0.262,
		},
	
		{
			id=145,
			value=0.262,
		},
	
		{
			id=146,
			value=0.262,
		},
	},
},
[304] = 
{
	id=304,
	type=3,
	level=4,
	name={key='minig_monster/304',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=7278066,
	npc_attrs=
	{
	
		{
			id=100,
			value=4342,
		},
	
		{
			id=101,
			value=1061766,
		},
	
		{
			id=102,
			value=70883,
		},
	
		{
			id=103,
			value=22096,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3144,
		},
	
		{
			id=122,
			value=0.3144,
		},
	
		{
			id=123,
			value=0.3144,
		},
	
		{
			id=124,
			value=0.3144,
		},
	
		{
			id=125,
			value=0.3144,
		},
	
		{
			id=126,
			value=0.3144,
		},
	
		{
			id=141,
			value=0.345,
		},
	
		{
			id=142,
			value=0.345,
		},
	
		{
			id=143,
			value=0.345,
		},
	
		{
			id=144,
			value=0.345,
		},
	
		{
			id=145,
			value=0.345,
		},
	
		{
			id=146,
			value=0.345,
		},
	},
},
[305] = 
{
	id=305,
	type=3,
	level=5,
	name={key='minig_monster/301',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=7700383,
	npc_attrs=
	{
	
		{
			id=100,
			value=4697,
		},
	
		{
			id=101,
			value=1063044,
		},
	
		{
			id=102,
			value=80944,
		},
	
		{
			id=103,
			value=30715,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3148,
		},
	
		{
			id=122,
			value=0.3148,
		},
	
		{
			id=123,
			value=0.3148,
		},
	
		{
			id=124,
			value=0.3148,
		},
	
		{
			id=125,
			value=0.3148,
		},
	
		{
			id=126,
			value=0.3148,
		},
	
		{
			id=141,
			value=0.348,
		},
	
		{
			id=142,
			value=0.348,
		},
	
		{
			id=143,
			value=0.348,
		},
	
		{
			id=144,
			value=0.348,
		},
	
		{
			id=145,
			value=0.348,
		},
	
		{
			id=146,
			value=0.348,
		},
	},
},
[306] = 
{
	id=306,
	type=3,
	level=6,
	name={key='minig_monster/302',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=8163965,
	npc_attrs=
	{
	
		{
			id=100,
			value=4976,
		},
	
		{
			id=101,
			value=1118952,
		},
	
		{
			id=102,
			value=86380,
		},
	
		{
			id=103,
			value=32357,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3152,
		},
	
		{
			id=122,
			value=0.3152,
		},
	
		{
			id=123,
			value=0.3152,
		},
	
		{
			id=124,
			value=0.3152,
		},
	
		{
			id=125,
			value=0.3152,
		},
	
		{
			id=126,
			value=0.3152,
		},
	
		{
			id=141,
			value=0.351,
		},
	
		{
			id=142,
			value=0.351,
		},
	
		{
			id=143,
			value=0.351,
		},
	
		{
			id=144,
			value=0.351,
		},
	
		{
			id=145,
			value=0.351,
		},
	
		{
			id=146,
			value=0.351,
		},
	},
},
[307] = 
{
	id=307,
	type=3,
	level=7,
	name={key='minig_monster/303',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=9466027,
	npc_attrs=
	{
	
		{
			id=100,
			value=5350,
		},
	
		{
			id=101,
			value=1166256,
		},
	
		{
			id=102,
			value=104509,
		},
	
		{
			id=103,
			value=37058,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.348,
		},
	
		{
			id=122,
			value=0.348,
		},
	
		{
			id=123,
			value=0.348,
		},
	
		{
			id=124,
			value=0.348,
		},
	
		{
			id=125,
			value=0.348,
		},
	
		{
			id=126,
			value=0.348,
		},
	
		{
			id=141,
			value=0.374,
		},
	
		{
			id=142,
			value=0.374,
		},
	
		{
			id=143,
			value=0.374,
		},
	
		{
			id=144,
			value=0.374,
		},
	
		{
			id=145,
			value=0.374,
		},
	
		{
			id=146,
			value=0.374,
		},
	},
},
[308] = 
{
	id=308,
	type=3,
	level=8,
	name={key='minig_monster/304',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=10515196,
	npc_attrs=
	{
	
		{
			id=100,
			value=5492,
		},
	
		{
			id=101,
			value=1290240,
		},
	
		{
			id=102,
			value=116968,
		},
	
		{
			id=103,
			value=40632,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3484,
		},
	
		{
			id=122,
			value=0.3484,
		},
	
		{
			id=123,
			value=0.3484,
		},
	
		{
			id=124,
			value=0.3484,
		},
	
		{
			id=125,
			value=0.3484,
		},
	
		{
			id=126,
			value=0.3484,
		},
	
		{
			id=141,
			value=0.377,
		},
	
		{
			id=142,
			value=0.377,
		},
	
		{
			id=143,
			value=0.377,
		},
	
		{
			id=144,
			value=0.377,
		},
	
		{
			id=145,
			value=0.377,
		},
	
		{
			id=146,
			value=0.377,
		},
	},
},
[309] = 
{
	id=309,
	type=3,
	level=9,
	name={key='minig_monster/301',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=11441560,
	npc_attrs=
	{
	
		{
			id=100,
			value=5872,
		},
	
		{
			id=101,
			value=1386594,
		},
	
		{
			id=102,
			value=130155,
		},
	
		{
			id=103,
			value=43836,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3488,
		},
	
		{
			id=122,
			value=0.3488,
		},
	
		{
			id=123,
			value=0.3488,
		},
	
		{
			id=124,
			value=0.3488,
		},
	
		{
			id=125,
			value=0.3488,
		},
	
		{
			id=126,
			value=0.3488,
		},
	
		{
			id=141,
			value=0.38,
		},
	
		{
			id=142,
			value=0.38,
		},
	
		{
			id=143,
			value=0.38,
		},
	
		{
			id=144,
			value=0.38,
		},
	
		{
			id=145,
			value=0.38,
		},
	
		{
			id=146,
			value=0.38,
		},
	},
},
[310] = 
{
	id=310,
	type=3,
	level=10,
	name={key='minig_monster/302',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=14183971,
	npc_attrs=
	{
	
		{
			id=100,
			value=6417,
		},
	
		{
			id=101,
			value=1562076,
		},
	
		{
			id=102,
			value=158978,
		},
	
		{
			id=103,
			value=59206,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3812,
		},
	
		{
			id=122,
			value=0.3812,
		},
	
		{
			id=123,
			value=0.3812,
		},
	
		{
			id=124,
			value=0.3812,
		},
	
		{
			id=125,
			value=0.3812,
		},
	
		{
			id=126,
			value=0.3812,
		},
	
		{
			id=141,
			value=0.403,
		},
	
		{
			id=142,
			value=0.403,
		},
	
		{
			id=143,
			value=0.403,
		},
	
		{
			id=144,
			value=0.403,
		},
	
		{
			id=145,
			value=0.403,
		},
	
		{
			id=146,
			value=0.403,
		},
	},
},
[311] = 
{
	id=311,
	type=3,
	level=11,
	name={key='minig_monster/303',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=16360856,
	npc_attrs=
	{
	
		{
			id=100,
			value=6733,
		},
	
		{
			id=101,
			value=1623888,
		},
	
		{
			id=102,
			value=168361,
		},
	
		{
			id=103,
			value=61631,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.3816,
		},
	
		{
			id=122,
			value=0.3816,
		},
	
		{
			id=123,
			value=0.3816,
		},
	
		{
			id=124,
			value=0.3816,
		},
	
		{
			id=125,
			value=0.3816,
		},
	
		{
			id=126,
			value=0.3816,
		},
	
		{
			id=141,
			value=0.406,
		},
	
		{
			id=142,
			value=0.406,
		},
	
		{
			id=143,
			value=0.406,
		},
	
		{
			id=144,
			value=0.406,
		},
	
		{
			id=145,
			value=0.406,
		},
	
		{
			id=146,
			value=0.406,
		},
	},
},
[312] = 
{
	id=312,
	type=3,
	level=12,
	name={key='minig_monster/304',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=21409956,
	npc_attrs=
	{
	
		{
			id=100,
			value=7483,
		},
	
		{
			id=101,
			value=1776402,
		},
	
		{
			id=102,
			value=189031,
		},
	
		{
			id=103,
			value=67518,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.4976,
		},
	
		{
			id=122,
			value=0.4976,
		},
	
		{
			id=123,
			value=0.4976,
		},
	
		{
			id=124,
			value=0.4976,
		},
	
		{
			id=125,
			value=0.4976,
		},
	
		{
			id=126,
			value=0.4976,
		},
	
		{
			id=141,
			value=0.469,
		},
	
		{
			id=142,
			value=0.469,
		},
	
		{
			id=143,
			value=0.469,
		},
	
		{
			id=144,
			value=0.469,
		},
	
		{
			id=145,
			value=0.469,
		},
	
		{
			id=146,
			value=0.469,
		},
	},
},
[313] = 
{
	id=313,
	type=3,
	level=13,
	name={key='minig_monster/301',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=23053180,
	npc_attrs=
	{
	
		{
			id=100,
			value=7962,
		},
	
		{
			id=101,
			value=1900422,
		},
	
		{
			id=102,
			value=204869,
		},
	
		{
			id=103,
			value=72336,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.498,
		},
	
		{
			id=122,
			value=0.498,
		},
	
		{
			id=123,
			value=0.498,
		},
	
		{
			id=124,
			value=0.498,
		},
	
		{
			id=125,
			value=0.498,
		},
	
		{
			id=126,
			value=0.498,
		},
	
		{
			id=141,
			value=0.472,
		},
	
		{
			id=142,
			value=0.472,
		},
	
		{
			id=143,
			value=0.472,
		},
	
		{
			id=144,
			value=0.472,
		},
	
		{
			id=145,
			value=0.472,
		},
	
		{
			id=146,
			value=0.472,
		},
	},
},
[314] = 
{
	id=314,
	type=3,
	level=14,
	name={key='minig_monster/302',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=27589689,
	npc_attrs=
	{
	
		{
			id=100,
			value=8424,
		},
	
		{
			id=101,
			value=2161386,
		},
	
		{
			id=102,
			value=235304,
		},
	
		{
			id=103,
			value=84184,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.5304,
		},
	
		{
			id=122,
			value=0.5304,
		},
	
		{
			id=123,
			value=0.5304,
		},
	
		{
			id=124,
			value=0.5304,
		},
	
		{
			id=125,
			value=0.5304,
		},
	
		{
			id=126,
			value=0.5304,
		},
	
		{
			id=141,
			value=0.495,
		},
	
		{
			id=142,
			value=0.495,
		},
	
		{
			id=143,
			value=0.495,
		},
	
		{
			id=144,
			value=0.495,
		},
	
		{
			id=145,
			value=0.495,
		},
	
		{
			id=146,
			value=0.495,
		},
	},
},
[315] = 
{
	id=315,
	type=3,
	level=15,
	name={key='minig_monster/303',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=32220822,
	npc_attrs=
	{
	
		{
			id=100,
			value=9270,
		},
	
		{
			id=101,
			value=2372202,
		},
	
		{
			id=102,
			value=263666,
		},
	
		{
			id=103,
			value=92359,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6028,
		},
	
		{
			id=122,
			value=0.6028,
		},
	
		{
			id=123,
			value=0.6028,
		},
	
		{
			id=124,
			value=0.6028,
		},
	
		{
			id=125,
			value=0.6028,
		},
	
		{
			id=126,
			value=0.6028,
		},
	
		{
			id=141,
			value=0.618,
		},
	
		{
			id=142,
			value=0.618,
		},
	
		{
			id=143,
			value=0.618,
		},
	
		{
			id=144,
			value=0.618,
		},
	
		{
			id=145,
			value=0.618,
		},
	
		{
			id=146,
			value=0.618,
		},
	},
},
[316] = 
{
	id=316,
	type=3,
	level=16,
	name={key='minig_monster/304',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=33807770,
	npc_attrs=
	{
	
		{
			id=100,
			value=9649,
		},
	
		{
			id=101,
			value=2019924,
		},
	
		{
			id=102,
			value=277236,
		},
	
		{
			id=103,
			value=119204,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6032,
		},
	
		{
			id=122,
			value=0.6032,
		},
	
		{
			id=123,
			value=0.6032,
		},
	
		{
			id=124,
			value=0.6032,
		},
	
		{
			id=125,
			value=0.6032,
		},
	
		{
			id=126,
			value=0.6032,
		},
	
		{
			id=141,
			value=0.621,
		},
	
		{
			id=142,
			value=0.621,
		},
	
		{
			id=143,
			value=0.621,
		},
	
		{
			id=144,
			value=0.621,
		},
	
		{
			id=145,
			value=0.621,
		},
	
		{
			id=146,
			value=0.621,
		},
	},
},
[317] = 
{
	id=317,
	type=3,
	level=17,
	name={key='minig_monster/301',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=37689449,
	npc_attrs=
	{
	
		{
			id=100,
			value=10162,
		},
	
		{
			id=101,
			value=2177676,
		},
	
		{
			id=102,
			value=320542,
		},
	
		{
			id=103,
			value=123879,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.604,
		},
	
		{
			id=122,
			value=0.604,
		},
	
		{
			id=123,
			value=0.604,
		},
	
		{
			id=124,
			value=0.604,
		},
	
		{
			id=125,
			value=0.604,
		},
	
		{
			id=126,
			value=0.604,
		},
	
		{
			id=141,
			value=0.644,
		},
	
		{
			id=142,
			value=0.644,
		},
	
		{
			id=143,
			value=0.644,
		},
	
		{
			id=144,
			value=0.644,
		},
	
		{
			id=145,
			value=0.644,
		},
	
		{
			id=146,
			value=0.644,
		},
	},
},
[318] = 
{
	id=318,
	type=3,
	level=18,
	name={key='minig_monster/302',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=40420835,
	npc_attrs=
	{
	
		{
			id=100,
			value=10443,
		},
	
		{
			id=101,
			value=2305620,
		},
	
		{
			id=102,
			value=350428,
		},
	
		{
			id=103,
			value=131985,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6044,
		},
	
		{
			id=122,
			value=0.6044,
		},
	
		{
			id=123,
			value=0.6044,
		},
	
		{
			id=124,
			value=0.6044,
		},
	
		{
			id=125,
			value=0.6044,
		},
	
		{
			id=126,
			value=0.6044,
		},
	
		{
			id=141,
			value=0.647,
		},
	
		{
			id=142,
			value=0.647,
		},
	
		{
			id=143,
			value=0.647,
		},
	
		{
			id=144,
			value=0.647,
		},
	
		{
			id=145,
			value=0.647,
		},
	
		{
			id=146,
			value=0.647,
		},
	},
},
[319] = 
{
	id=319,
	type=3,
	level=19,
	name={key='minig_monster/303',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=48635854,
	npc_attrs=
	{
	
		{
			id=100,
			value=11055,
		},
	
		{
			id=101,
			value=2407446,
		},
	
		{
			id=102,
			value=375143,
		},
	
		{
			id=103,
			value=138462,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6528,
		},
	
		{
			id=122,
			value=0.6528,
		},
	
		{
			id=123,
			value=0.6528,
		},
	
		{
			id=124,
			value=0.6528,
		},
	
		{
			id=125,
			value=0.6528,
		},
	
		{
			id=126,
			value=0.6528,
		},
	
		{
			id=141,
			value=0.8,
		},
	
		{
			id=142,
			value=0.8,
		},
	
		{
			id=143,
			value=0.8,
		},
	
		{
			id=144,
			value=0.8,
		},
	
		{
			id=145,
			value=0.8,
		},
	
		{
			id=146,
			value=0.8,
		},
	},
},
[320] = 
{
	id=320,
	type=3,
	level=20,
	name={key='minig_monster/304',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=2000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=46683543,
	npc_attrs=
	{
	
		{
			id=100,
			value=11472,
		},
	
		{
			id=101,
			value=2318850,
		},
	
		{
			id=102,
			value=416341,
		},
	
		{
			id=103,
			value=156413,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6852,
		},
	
		{
			id=122,
			value=0.6852,
		},
	
		{
			id=123,
			value=0.6852,
		},
	
		{
			id=124,
			value=0.6852,
		},
	
		{
			id=125,
			value=0.6852,
		},
	
		{
			id=126,
			value=0.6852,
		},
	
		{
			id=141,
			value=0.803,
		},
	
		{
			id=142,
			value=0.803,
		},
	
		{
			id=143,
			value=0.803,
		},
	
		{
			id=144,
			value=0.803,
		},
	
		{
			id=145,
			value=0.803,
		},
	
		{
			id=146,
			value=0.803,
		},
	},
},
[401] = 
{
	id=401,
	type=4,
	level=1,
	name={key='minig_monster/401',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=29067561,
	npc_attrs=
	{
	
		{
			id=100,
			value=7961,
		},
	
		{
			id=101,
			value=3052300,
		},
	
		{
			id=102,
			value=146369,
		},
	
		{
			id=103,
			value=45344,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.4976,
		},
	
		{
			id=122,
			value=0.4976,
		},
	
		{
			id=123,
			value=0.4976,
		},
	
		{
			id=124,
			value=0.4976,
		},
	
		{
			id=125,
			value=0.4976,
		},
	
		{
			id=126,
			value=0.4976,
		},
	
		{
			id=141,
			value=0.47,
		},
	
		{
			id=142,
			value=0.47,
		},
	
		{
			id=143,
			value=0.47,
		},
	
		{
			id=144,
			value=0.47,
		},
	
		{
			id=145,
			value=0.47,
		},
	
		{
			id=146,
			value=0.47,
		},
	},
},
[402] = 
{
	id=402,
	type=4,
	level=2,
	name={key='minig_monster/402',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=34354725,
	npc_attrs=
	{
	
		{
			id=100,
			value=8484,
		},
	
		{
			id=101,
			value=3604175,
		},
	
		{
			id=102,
			value=173319,
		},
	
		{
			id=103,
			value=54606,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.53,
		},
	
		{
			id=122,
			value=0.53,
		},
	
		{
			id=123,
			value=0.53,
		},
	
		{
			id=124,
			value=0.53,
		},
	
		{
			id=125,
			value=0.53,
		},
	
		{
			id=126,
			value=0.53,
		},
	
		{
			id=141,
			value=0.493,
		},
	
		{
			id=142,
			value=0.493,
		},
	
		{
			id=143,
			value=0.493,
		},
	
		{
			id=144,
			value=0.493,
		},
	
		{
			id=145,
			value=0.493,
		},
	
		{
			id=146,
			value=0.493,
		},
	},
},
[403] = 
{
	id=403,
	type=4,
	level=3,
	name={key='minig_monster/403',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=35720980,
	npc_attrs=
	{
	
		{
			id=100,
			value=8752,
		},
	
		{
			id=101,
			value=3728100,
		},
	
		{
			id=102,
			value=182098,
		},
	
		{
			id=103,
			value=56487,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.5304,
		},
	
		{
			id=122,
			value=0.5304,
		},
	
		{
			id=123,
			value=0.5304,
		},
	
		{
			id=124,
			value=0.5304,
		},
	
		{
			id=125,
			value=0.5304,
		},
	
		{
			id=126,
			value=0.5304,
		},
	
		{
			id=141,
			value=0.496,
		},
	
		{
			id=142,
			value=0.496,
		},
	
		{
			id=143,
			value=0.496,
		},
	
		{
			id=144,
			value=0.496,
		},
	
		{
			id=145,
			value=0.496,
		},
	
		{
			id=146,
			value=0.496,
		},
	},
},
[404] = 
{
	id=404,
	type=4,
	level=4,
	name={key='minig_monster/404',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=45745466,
	npc_attrs=
	{
	
		{
			id=100,
			value=9518,
		},
	
		{
			id=101,
			value=4090425,
		},
	
		{
			id=102,
			value=203436,
		},
	
		{
			id=103,
			value=61956,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6032,
		},
	
		{
			id=122,
			value=0.6032,
		},
	
		{
			id=123,
			value=0.6032,
		},
	
		{
			id=124,
			value=0.6032,
		},
	
		{
			id=125,
			value=0.6032,
		},
	
		{
			id=126,
			value=0.6032,
		},
	
		{
			id=141,
			value=0.619,
		},
	
		{
			id=142,
			value=0.619,
		},
	
		{
			id=143,
			value=0.619,
		},
	
		{
			id=144,
			value=0.619,
		},
	
		{
			id=145,
			value=0.619,
		},
	
		{
			id=146,
			value=0.619,
		},
	},
},
[405] = 
{
	id=405,
	type=4,
	level=5,
	name={key='minig_monster/401',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=44834571,
	npc_attrs=
	{
	
		{
			id=100,
			value=9923,
		},
	
		{
			id=101,
			value=3959925,
		},
	
		{
			id=102,
			value=232413,
		},
	
		{
			id=103,
			value=80532,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6036,
		},
	
		{
			id=122,
			value=0.6036,
		},
	
		{
			id=123,
			value=0.6036,
		},
	
		{
			id=124,
			value=0.6036,
		},
	
		{
			id=125,
			value=0.6036,
		},
	
		{
			id=126,
			value=0.6036,
		},
	
		{
			id=141,
			value=0.642,
		},
	
		{
			id=142,
			value=0.642,
		},
	
		{
			id=143,
			value=0.642,
		},
	
		{
			id=144,
			value=0.642,
		},
	
		{
			id=145,
			value=0.642,
		},
	
		{
			id=146,
			value=0.642,
		},
	},
},
[406] = 
{
	id=406,
	type=4,
	level=6,
	name={key='minig_monster/402',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=51104128,
	npc_attrs=
	{
	
		{
			id=100,
			value=10200,
		},
	
		{
			id=101,
			value=4081275,
		},
	
		{
			id=102,
			value=243588,
		},
	
		{
			id=103,
			value=83079,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.604,
		},
	
		{
			id=122,
			value=0.604,
		},
	
		{
			id=123,
			value=0.604,
		},
	
		{
			id=124,
			value=0.604,
		},
	
		{
			id=125,
			value=0.604,
		},
	
		{
			id=126,
			value=0.604,
		},
	
		{
			id=141,
			value=0.645,
		},
	
		{
			id=142,
			value=0.645,
		},
	
		{
			id=143,
			value=0.645,
		},
	
		{
			id=144,
			value=0.645,
		},
	
		{
			id=145,
			value=0.645,
		},
	
		{
			id=146,
			value=0.645,
		},
	},
},
[407] = 
{
	id=407,
	type=4,
	level=7,
	name={key='minig_monster/403',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=54918756,
	npc_attrs=
	{
	
		{
			id=100,
			value=10611,
		},
	
		{
			id=101,
			value=4352650,
		},
	
		{
			id=102,
			value=267450,
		},
	
		{
			id=103,
			value=89098,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6044,
		},
	
		{
			id=122,
			value=0.6044,
		},
	
		{
			id=123,
			value=0.6044,
		},
	
		{
			id=124,
			value=0.6044,
		},
	
		{
			id=125,
			value=0.6044,
		},
	
		{
			id=126,
			value=0.6044,
		},
	
		{
			id=141,
			value=0.648,
		},
	
		{
			id=142,
			value=0.648,
		},
	
		{
			id=143,
			value=0.648,
		},
	
		{
			id=144,
			value=0.648,
		},
	
		{
			id=145,
			value=0.648,
		},
	
		{
			id=146,
			value=0.648,
		},
	},
},
[408] = 
{
	id=408,
	type=4,
	level=8,
	name={key='minig_monster/404',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=65419996,
	npc_attrs=
	{
	
		{
			id=100,
			value=11093,
		},
	
		{
			id=101,
			value=4522675,
		},
	
		{
			id=102,
			value=283525,
		},
	
		{
			id=103,
			value=92828,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6528,
		},
	
		{
			id=122,
			value=0.6528,
		},
	
		{
			id=123,
			value=0.6528,
		},
	
		{
			id=124,
			value=0.6528,
		},
	
		{
			id=125,
			value=0.6528,
		},
	
		{
			id=126,
			value=0.6528,
		},
	
		{
			id=141,
			value=0.801,
		},
	
		{
			id=142,
			value=0.801,
		},
	
		{
			id=143,
			value=0.801,
		},
	
		{
			id=144,
			value=0.801,
		},
	
		{
			id=145,
			value=0.801,
		},
	
		{
			id=146,
			value=0.801,
		},
	},
},
[409] = 
{
	id=409,
	type=4,
	level=9,
	name={key='minig_monster/401',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=69100985,
	npc_attrs=
	{
	
		{
			id=100,
			value=11509,
		},
	
		{
			id=101,
			value=4549325,
		},
	
		{
			id=102,
			value=315164,
		},
	
		{
			id=103,
			value=104825,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6856,
		},
	
		{
			id=122,
			value=0.6856,
		},
	
		{
			id=123,
			value=0.6856,
		},
	
		{
			id=124,
			value=0.6856,
		},
	
		{
			id=125,
			value=0.6856,
		},
	
		{
			id=126,
			value=0.6856,
		},
	
		{
			id=141,
			value=0.804,
		},
	
		{
			id=142,
			value=0.804,
		},
	
		{
			id=143,
			value=0.804,
		},
	
		{
			id=144,
			value=0.804,
		},
	
		{
			id=145,
			value=0.804,
		},
	
		{
			id=146,
			value=0.804,
		},
	},
},
[410] = 
{
	id=410,
	type=4,
	level=10,
	name={key='minig_monster/402',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=66842749,
	npc_attrs=
	{
	
		{
			id=100,
			value=11930,
		},
	
		{
			id=101,
			value=4161175,
		},
	
		{
			id=102,
			value=331331,
		},
	
		{
			id=103,
			value=130076,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.686,
		},
	
		{
			id=122,
			value=0.686,
		},
	
		{
			id=123,
			value=0.686,
		},
	
		{
			id=124,
			value=0.686,
		},
	
		{
			id=125,
			value=0.686,
		},
	
		{
			id=126,
			value=0.686,
		},
	
		{
			id=141,
			value=0.807,
		},
	
		{
			id=142,
			value=0.807,
		},
	
		{
			id=143,
			value=0.807,
		},
	
		{
			id=144,
			value=0.807,
		},
	
		{
			id=145,
			value=0.807,
		},
	
		{
			id=146,
			value=0.807,
		},
	},
},
[411] = 
{
	id=411,
	type=4,
	level=11,
	name={key='minig_monster/403',text="岩石怪物"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1100,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1002,
	fight=70252677,
	npc_attrs=
	{
	
		{
			id=100,
			value=12217,
		},
	
		{
			id=101,
			value=4340400,
		},
	
		{
			id=102,
			value=354619,
		},
	
		{
			id=103,
			value=135955,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6864,
		},
	
		{
			id=122,
			value=0.6864,
		},
	
		{
			id=123,
			value=0.6864,
		},
	
		{
			id=124,
			value=0.6864,
		},
	
		{
			id=125,
			value=0.6864,
		},
	
		{
			id=126,
			value=0.6864,
		},
	
		{
			id=141,
			value=0.81,
		},
	
		{
			id=142,
			value=0.81,
		},
	
		{
			id=143,
			value=0.81,
		},
	
		{
			id=144,
			value=0.81,
		},
	
		{
			id=145,
			value=0.81,
		},
	
		{
			id=146,
			value=0.81,
		},
	},
},
[412] = 
{
	id=412,
	type=4,
	level=12,
	name={key='minig_monster/404',text="盗猎者"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1200,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1020,
	fight=81341684,
	npc_attrs=
	{
	
		{
			id=100,
			value=12789,
		},
	
		{
			id=101,
			value=5097025,
		},
	
		{
			id=102,
			value=380816,
		},
	
		{
			id=103,
			value=146320,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.6868,
		},
	
		{
			id=122,
			value=0.6868,
		},
	
		{
			id=123,
			value=0.6868,
		},
	
		{
			id=124,
			value=0.6868,
		},
	
		{
			id=125,
			value=0.6868,
		},
	
		{
			id=126,
			value=0.6868,
		},
	
		{
			id=141,
			value=0.833,
		},
	
		{
			id=142,
			value=0.833,
		},
	
		{
			id=143,
			value=0.833,
		},
	
		{
			id=144,
			value=0.833,
		},
	
		{
			id=145,
			value=0.833,
		},
	
		{
			id=146,
			value=0.833,
		},
	},
},
[413] = 
{
	id=413,
	type=4,
	level=13,
	name={key='minig_monster/401',text="路霸"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1300,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1009,
	fight=85981192,
	npc_attrs=
	{
	
		{
			id=100,
			value=13080,
		},
	
		{
			id=101,
			value=5225175,
		},
	
		{
			id=102,
			value=396807,
		},
	
		{
			id=103,
			value=149988,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.7304,
		},
	
		{
			id=122,
			value=0.7304,
		},
	
		{
			id=123,
			value=0.7304,
		},
	
		{
			id=124,
			value=0.7304,
		},
	
		{
			id=125,
			value=0.7304,
		},
	
		{
			id=126,
			value=0.7304,
		},
	
		{
			id=141,
			value=0.836,
		},
	
		{
			id=142,
			value=0.836,
		},
	
		{
			id=143,
			value=0.836,
		},
	
		{
			id=144,
			value=0.836,
		},
	
		{
			id=145,
			value=0.836,
		},
	
		{
			id=146,
			value=0.836,
		},
	},
},
[414] = 
{
	id=414,
	type=4,
	level=14,
	name={key='minig_monster/402',text="响尾蛇"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1400,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1019,
	fight=90049674,
	npc_attrs=
	{
	
		{
			id=100,
			value=13514,
		},
	
		{
			id=101,
			value=5440450,
		},
	
		{
			id=102,
			value=420294,
		},
	
		{
			id=103,
			value=156431,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.7312,
		},
	
		{
			id=122,
			value=0.7312,
		},
	
		{
			id=123,
			value=0.7312,
		},
	
		{
			id=124,
			value=0.7312,
		},
	
		{
			id=125,
			value=0.7312,
		},
	
		{
			id=126,
			value=0.7312,
		},
	
		{
			id=141,
			value=0.839,
		},
	
		{
			id=142,
			value=0.839,
		},
	
		{
			id=143,
			value=0.839,
		},
	
		{
			id=144,
			value=0.839,
		},
	
		{
			id=145,
			value=0.839,
		},
	
		{
			id=146,
			value=0.839,
		},
	},
},
[415] = 
{
	id=415,
	type=4,
	level=15,
	name={key='minig_monster/403',text="岩兽"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1500,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1011,
	fight=98663693,
	npc_attrs=
	{
	
		{
			id=100,
			value=13952,
		},
	
		{
			id=101,
			value=5784650,
		},
	
		{
			id=102,
			value=473554,
		},
	
		{
			id=103,
			value=161126,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.7636,
		},
	
		{
			id=122,
			value=0.7636,
		},
	
		{
			id=123,
			value=0.7636,
		},
	
		{
			id=124,
			value=0.7636,
		},
	
		{
			id=125,
			value=0.7636,
		},
	
		{
			id=126,
			value=0.7636,
		},
	
		{
			id=141,
			value=0.842,
		},
	
		{
			id=142,
			value=0.842,
		},
	
		{
			id=143,
			value=0.842,
		},
	
		{
			id=144,
			value=0.842,
		},
	
		{
			id=145,
			value=0.842,
		},
	
		{
			id=146,
			value=0.842,
		},
	},
},
[416] = 
{
	id=416,
	type=4,
	level=16,
	name={key='minig_monster/404',text="鬼蟹"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1600,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1017,
	fight=92797701,
	npc_attrs=
	{
	
		{
			id=100,
			value=14250,
		},
	
		{
			id=101,
			value=4950650,
		},
	
		{
			id=102,
			value=503893,
		},
	
		{
			id=103,
			value=209519,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.764,
		},
	
		{
			id=122,
			value=0.764,
		},
	
		{
			id=123,
			value=0.764,
		},
	
		{
			id=124,
			value=0.764,
		},
	
		{
			id=125,
			value=0.764,
		},
	
		{
			id=126,
			value=0.764,
		},
	
		{
			id=141,
			value=0.845,
		},
	
		{
			id=142,
			value=0.845,
		},
	
		{
			id=143,
			value=0.845,
		},
	
		{
			id=144,
			value=0.845,
		},
	
		{
			id=145,
			value=0.845,
		},
	
		{
			id=146,
			value=0.845,
		},
	},
},
[417] = 
{
	id=417,
	type=4,
	level=17,
	name={key='minig_monster/401',text="冷血劫匪"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1700,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1018,
	fight=96946537,
	npc_attrs=
	{
	
		{
			id=100,
			value=14698,
		},
	
		{
			id=101,
			value=5138875,
		},
	
		{
			id=102,
			value=531944,
		},
	
		{
			id=103,
			value=218067,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.7644,
		},
	
		{
			id=122,
			value=0.7644,
		},
	
		{
			id=123,
			value=0.7644,
		},
	
		{
			id=124,
			value=0.7644,
		},
	
		{
			id=125,
			value=0.7644,
		},
	
		{
			id=126,
			value=0.7644,
		},
	
		{
			id=141,
			value=0.848,
		},
	
		{
			id=142,
			value=0.848,
		},
	
		{
			id=143,
			value=0.848,
		},
	
		{
			id=144,
			value=0.848,
		},
	
		{
			id=145,
			value=0.848,
		},
	
		{
			id=146,
			value=0.848,
		},
	},
},
[418] = 
{
	id=418,
	type=4,
	level=18,
	name={key='minig_monster/402',text="狒狒王"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1800,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1012,
	fight=98290109,
	npc_attrs=
	{
	
		{
			id=100,
			value=14998,
		},
	
		{
			id=101,
			value=4868600,
		},
	
		{
			id=102,
			value=574288,
		},
	
		{
			id=103,
			value=238416,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.7648,
		},
	
		{
			id=122,
			value=0.7648,
		},
	
		{
			id=123,
			value=0.7648,
		},
	
		{
			id=124,
			value=0.7648,
		},
	
		{
			id=125,
			value=0.7648,
		},
	
		{
			id=126,
			value=0.7648,
		},
	
		{
			id=141,
			value=0.876,
		},
	
		{
			id=142,
			value=0.876,
		},
	
		{
			id=143,
			value=0.876,
		},
	
		{
			id=144,
			value=0.876,
		},
	
		{
			id=145,
			value=0.876,
		},
	
		{
			id=146,
			value=0.876,
		},
	},
},
[419] = 
{
	id=419,
	type=4,
	level=19,
	name={key='minig_monster/403',text="钢索"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=1900,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1014,
	fight=102668347,
	npc_attrs=
	{
	
		{
			id=100,
			value=15451,
		},
	
		{
			id=101,
			value=5054400,
		},
	
		{
			id=102,
			value=604995,
		},
	
		{
			id=103,
			value=247593,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.7656,
		},
	
		{
			id=122,
			value=0.7656,
		},
	
		{
			id=123,
			value=0.7656,
		},
	
		{
			id=124,
			value=0.7656,
		},
	
		{
			id=125,
			value=0.7656,
		},
	
		{
			id=126,
			value=0.7656,
		},
	
		{
			id=141,
			value=0.879,
		},
	
		{
			id=142,
			value=0.879,
		},
	
		{
			id=143,
			value=0.879,
		},
	
		{
			id=144,
			value=0.879,
		},
	
		{
			id=145,
			value=0.879,
		},
	
		{
			id=146,
			value=0.879,
		},
	},
},
[420] = 
{
	id=420,
	type=4,
	level=20,
	name={key='minig_monster/404',text="钢锯肥波"},
	first_rewards=
	{
	
		{
			id=76,
			num=1,
		},
	
		{
			id=81,
			num=2000,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
	npc=1007,
	fight=107708715,
	npc_attrs=
	{
	
		{
			id=100,
			value=15908,
		},
	
		{
			id=101,
			value=5254725,
		},
	
		{
			id=102,
			value=644667,
		},
	
		{
			id=103,
			value=258114,
		},
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.766,
		},
	
		{
			id=122,
			value=0.766,
		},
	
		{
			id=123,
			value=0.766,
		},
	
		{
			id=124,
			value=0.766,
		},
	
		{
			id=125,
			value=0.766,
		},
	
		{
			id=126,
			value=0.766,
		},
	
		{
			id=141,
			value=0.882,
		},
	
		{
			id=142,
			value=0.882,
		},
	
		{
			id=143,
			value=0.882,
		},
	
		{
			id=144,
			value=0.882,
		},
	
		{
			id=145,
			value=0.882,
		},
	
		{
			id=146,
			value=0.882,
		},
	},
},
}
