
-- pm.TbBiInternalEventHeroChange



return
{
[1] = 
{
	id=1,
	field="hero_id",
	name="佣兵id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="hero_level",
	name="佣兵等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="hero_stage",
	name="佣兵阶级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="hero_star",
	name="佣兵星级",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="position",
	name="上阵位置",
	type=0,
	opt=1,
	default_value="",
},
}
