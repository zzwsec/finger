
-- pm.TbBiInternalEventOnlineNum



return
{
[1] = 
{
	id=1,
	field="num1",
	name="玩家数量",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num2",
	name="在线玩家",
	type=0,
	opt=0,
	default_value="",
},
}
