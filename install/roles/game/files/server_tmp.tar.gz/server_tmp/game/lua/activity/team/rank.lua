local Log = require("common/logging")

local TeamRanksConfig = import("config/activity/team_ranks", true)

Modules.TeamRank_MODULE = Modules.TeamRank_MODULE or {}
local M = Modules.TeamRank_MODULE

-- 获取当前最大排名
M.TeamRanksMap = {}
for _, item in pairs(TeamRanksConfig) do
	M.TeamRanksMap[item.type] = M.TeamRanksMap[item.type] or {}
	table.insert(M.TeamRanksMap[item.type], item)
end

for type, _ in pairs(M.TeamRanksMap) do
	table.sort(M.TeamRanksMap[type], function(a, b) 
		return a.rank_range[1] < b.rank_range[1] 
	end)
end

function M.GetMaxRank(type, score)
	local max_score = 0
	local max_rank = 1
	for _, item in pairs(M.TeamRanksMap[type] or {}) do
		if score >= item.conditions and max_score <= item.conditions then
			max_score = item.conditions
			max_rank = item.rank_range[1]
			break
		end
	end
	return max_rank
end

return M