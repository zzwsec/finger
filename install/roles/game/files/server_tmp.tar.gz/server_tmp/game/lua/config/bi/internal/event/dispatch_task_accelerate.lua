
-- pm.TbBiInternalEventDispatchTaskAccelerate



return
{
[1] = 
{
	id=1,
	field="task_id",
	name="任务id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="pos",
	name="任务位置",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="accelerate_time",
	name="加速时间(秒)",
	type=0,
	opt=1,
	default_value="",
},
}
