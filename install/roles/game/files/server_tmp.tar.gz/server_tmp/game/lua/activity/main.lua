 require("common/import")
 require("common/functions")

local Log = require("common/logging")
local Msgpack = require("msgpack")

-- 全局变量
Handlers = {}
Globals = {}
Modules = {}

-- 序列化器
g_msgpack_packer = Msgpack.Packer.new()

-- 重读
function Reload(strand, cb)
    import_areload_all(strand, function()
        Handlers = {}
    end, function(...)
        cb(...)
    end)
end

-- 驱动时间
local last_tick_time = 0
local last_gc_time = 0
local function TickEventCall(...)
    for _, handler in ipairs(Handlers["TickEvent"] or {}) do
        handler(...)
    end
end
function Tick()
    local now_time = os.now()
    xpcall(TickEventCall, function(err_msg)
        Log.Error("Lua", err_msg)
    end, now_time, last_tick_time)
    last_tick_time = now_time
    if last_gc_time + g_options.collect_garbage_timeout <= now_time then
        collectgarbage("collect")
        last_gc_time = now_time
    else
        collectgarbage("step", 0)
    end
end

-- 错误处理函数
function ErrorHandler(err_msg)
    Log.Error("Lua", err_msg)
end

-- 处理器
import("activity/event_handler")
import("activity/invoke_handler")

import("activity/team/message_handler")

import("activity/team/event_handler")