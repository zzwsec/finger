
-- pm.TbBiKingnetEventChangeCoin



return
{
[1] = 
{
	id=1,
	field="type",
	name="变动类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="coin_id",
	name="货币id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="coin_num",
	name="货币数量",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="coin_value",
	name="现有道具数量",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="log_event_parm1",
	name="来源1",
	type=1,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="log_event_parm2",
	name="来源2",
	type=1,
	opt=0,
	default_value="",
},
[7] = 
{
	id=7,
	field="item_id",
	name="道具id",
	type=0,
	opt=0,
	default_value="",
},
[8] = 
{
	id=8,
	field="item_num",
	name="道具数量",
	type=0,
	opt=0,
	default_value="",
},
}
