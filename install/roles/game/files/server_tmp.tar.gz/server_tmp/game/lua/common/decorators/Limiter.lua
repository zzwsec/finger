local class = require "utils.class"
local Constants = require "core.Constants"

local Decorator = require 'core.Decorator'

local Limiter = class("Limiter", Decorator)

function Limiter:ctor()
    Decorator.ctor(self)

    self.name = "Limiter"
    self.title = "Limit <maxLoop> Activations"
    self.parameters = {maxLoop = 1,}
end

function Limiter:open(tick)
    tick.blackboard.set("i", 0, tick.tree.id, self.id)
end

function Limiter:tick(tick)
    assert(self.child, "no chilld")

    local i = tick.blackboard:get("i", tick.tree.id, self.id)

    if i < self.maxLoop then
        local status = self.child:_execute(tick)

        if status == Constants.SUCCESS or status == Constants.FAILURE then
            tick.blackboard:set("i", i+1, tick.tree.id, self.id)
        end

        return status
    end

    return Constants.FAILURE
end

return Limiter
