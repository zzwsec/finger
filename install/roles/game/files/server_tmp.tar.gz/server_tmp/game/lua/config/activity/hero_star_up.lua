
-- pm.TbHeroStarUp



return
{
[1001] = 
{
	id=1001,
	index=1,
	condition=
	{
		type=6011,
		value=3,
	},
	rewards=
	{
	
		{
			id=3,
			num=100,
		},
	},
	gift=83501,
},
[1002] = 
{
	id=1002,
	index=1,
	condition=
	{
		type=6011,
		value=4,
	},
	rewards=
	{
	
		{
			id=37,
			num=50,
		},
	},
	gift=83502,
},
[1003] = 
{
	id=1003,
	index=1,
	condition=
	{
		type=6011,
		value=5,
	},
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
	gift=83503,
},
[1004] = 
{
	id=1004,
	index=1,
	condition=
	{
		type=6011,
		value=6,
	},
	rewards=
	{
	
		{
			id=132,
			num=8,
		},
	},
	gift=83504,
},
[1005] = 
{
	id=1005,
	index=1,
	condition=
	{
		type=6011,
		value=7,
	},
	rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
	gift=83505,
},
[1006] = 
{
	id=1006,
	index=1,
	condition=
	{
		type=6011,
		value=8,
	},
	rewards=
	{
	
		{
			id=132,
			num=8,
		},
	},
	gift=83506,
},
[1007] = 
{
	id=1007,
	index=1,
	condition=
	{
		type=6011,
		value=9,
	},
	rewards=
	{
	
		{
			id=44,
			num=10,
		},
	
		{
			id=39,
			num=10,
		},
	},
	gift=83507,
},
[1101] = 
{
	id=1101,
	index=2,
	condition=
	{
		type=6019,
		value=3,
	},
	rewards=
	{
	
		{
			id=3,
			num=100,
		},
	},
	gift=83501,
},
[1102] = 
{
	id=1102,
	index=2,
	condition=
	{
		type=6019,
		value=4,
	},
	rewards=
	{
	
		{
			id=37,
			num=10,
		},
	},
	gift=83502,
},
[1103] = 
{
	id=1103,
	index=2,
	condition=
	{
		type=6019,
		value=5,
	},
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
	gift=83503,
},
[1104] = 
{
	id=1104,
	index=2,
	condition=
	{
		type=6019,
		value=6,
	},
	rewards=
	{
	
		{
			id=132,
			num=8,
		},
	},
	gift=83504,
},
[1105] = 
{
	id=1105,
	index=2,
	condition=
	{
		type=6019,
		value=7,
	},
	rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
	gift=83505,
},
[1106] = 
{
	id=1106,
	index=2,
	condition=
	{
		type=6019,
		value=8,
	},
	rewards=
	{
	
		{
			id=132,
			num=8,
		},
	},
	gift=83506,
},
[1107] = 
{
	id=1107,
	index=2,
	condition=
	{
		type=6019,
		value=9,
	},
	rewards=
	{
	
		{
			id=44,
			num=10,
		},
	
		{
			id=39,
			num=10,
		},
	},
	gift=83507,
},
}
