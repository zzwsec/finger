
-- pm.TbBiInternalEventHeroDispatch



return
{
[1] = 
{
	id=1,
	field="hero_id",
	name="佣兵id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="hero_pj",
	name="佣兵品阶",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="hero_star",
	name="佣兵星级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="build_id",
	name="建筑id",
	type=0,
	opt=1,
	default_value="",
},
}
