local class = require "utils.class"
local Constants = require "core.Constants"

local Decorator = require 'core.Decorator'

local Inverter = class("Inverter", Decorator)

function Inverter:ctor()
    Decorator.ctor(self)

    self.name = "Inverter"
end

function Inverter:tick(tick)
    assert(self.child, "no chilld")

    local status = self.child:_execute(tick)

    if status == Constants.SUCCESS then
        status = Constants.FAILURE
    elseif status == Constants.FAILURE then
        status = Constants.SUCCESS
    end

    return status
end

return Inverter
