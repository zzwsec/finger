local heap = {}

local function default_compare(a, b) 
    return a < b
end

function heap.new(compare)
    local o = {
        length = 0,
        compare = compare or default_compare,
    }
    setmetatable(o, heap)
    heap.__index = heap
    return o
end

function heap:empty()
    return self.length == 0
end

function heap:next_key()
    if self.length == 0 then
        return
    end
    return self[1].key
end

function heap:peek()
    if self.length == 0 then
        return
    end
    return self[1].key, self[1].value
end


function heap:insert(key, value)
    local cmp = self.compare
    self.length = self.length + 1
    local new_record = self[self.length]
    local child_index = self.length
    while child_index > 1 do
        local parent_index = math.floor(child_index / 2)
        local parent_record = self[parent_index]
        if cmp(value, parent_record.value) then
            self[child_index] = parent_record
        else
            break
        end
        child_index = parent_index
    end
    if new_record then
        new_record.key = key
        new_record.value = value
    else
        new_record = {
            key = key, 
            value = value
        }
    end
    self[child_index] = new_record
end

function heap:pop()
    if self.length == 0 then
        return 
    end
    local cmp = self.compare
    local result = self[1]
    local last = self[self.length]
    local last_key = (last and last.key) or nil
    -- keep the old record around to save on garbage
    self[self.length] = self[1]
    self.length = self.length - 1
    
    local parent_index = 1
    while parent_index * 2 <= self.length do
        local child_index = parent_index * 2
        if child_index+1 <= self.length and cmp(self[child_index+1].value, self[child_index].value) then
            child_index = child_index + 1
        end
        local child_record = self[child_index]
        local child_key = child_record.key
        if cmp(last.value, child_record.value) then
            break
        else
            self[parent_index] = child_record
            parent_index = child_index
        end
    end
    self[parent_index] = last
    return result.key, result.value
end

return heap