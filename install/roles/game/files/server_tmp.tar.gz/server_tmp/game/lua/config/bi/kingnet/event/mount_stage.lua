
-- pm.TbBiKingnetEventMountStage



return
{
[1] = 
{
	id=1,
	field="num",
	name="老阶级",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num1",
	name="新阶级",
	type=0,
	opt=1,
	default_value="",
},
}
