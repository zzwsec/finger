
-- pm.TbSmeltMetal



return
{
[221] = 
{
	id=221,
	price=
	{
		id=320,
		num=50,
	},
},
[222] = 
{
	id=222,
	price=
	{
		id=320,
		num=100,
	},
},
[223] = 
{
	id=223,
	price=
	{
		id=320,
		num=300,
	},
},
[224] = 
{
	id=224,
	price=
	{
		id=320,
		num=800,
	},
},
[225] = 
{
	id=225,
	price=
	{
		id=320,
		num=2000,
	},
},
}
