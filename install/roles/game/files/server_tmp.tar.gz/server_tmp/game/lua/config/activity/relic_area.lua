
-- pm.TbXdaysRelicArea



return
{
[1] = 
{
	id=1,
	pre_tid=0,
	name={key='relic_name/1',text="金之谷"},
	desc={key='relic_desc/1',text="金系宠物探险收益翻倍"},
	area_unlock=
	{
		id=0,
		num=0,
	},
	slot_unlock=
	{
		id=56,
		num=200,
	},
	slot_num=4,
	type=1,
	ratio=2,
	recover_cd=300,
},
[2] = 
{
	id=2,
	pre_tid=1,
	name={key='relic_name/2',text="火之渊"},
	desc={key='relic_desc/2',text="火系宠物探险收益翻倍"},
	area_unlock=
	{
		id=56,
		num=2000,
	},
	slot_unlock=
	{
		id=56,
		num=200,
	},
	slot_num=4,
	type=2,
	ratio=2,
	recover_cd=300,
},
[3] = 
{
	id=3,
	pre_tid=2,
	name={key='relic_name/3',text="水之境"},
	desc={key='relic_desc/3',text="水系宠物探险收益翻倍"},
	area_unlock=
	{
		id=56,
		num=2000,
	},
	slot_unlock=
	{
		id=56,
		num=200,
	},
	slot_num=4,
	type=3,
	ratio=2,
	recover_cd=300,
},
[4] = 
{
	id=4,
	pre_tid=3,
	name={key='relic_name/4',text="土之陵"},
	desc={key='relic_desc/4',text="土系宠物探险收益翻倍"},
	area_unlock=
	{
		id=56,
		num=2000,
	},
	slot_unlock=
	{
		id=56,
		num=200,
	},
	slot_num=4,
	type=4,
	ratio=2,
	recover_cd=300,
},
}
