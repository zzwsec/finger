
-- pm.TbActivityWeekOpen



return
{
[1] = 
{
	id=1,
	open_week=2,
	open_day=1,
	activity=10201,
	start_offset=0,
	duration=604799,
	delay=0,
},
[2] = 
{
	id=2,
	open_week=2,
	open_day=1,
	activity=12401,
	start_offset=0,
	duration=259199,
	delay=0,
},
[3] = 
{
	id=3,
	open_week=2,
	open_day=1,
	activity=20801,
	start_offset=0,
	duration=604799,
	delay=0,
},
[4] = 
{
	id=4,
	open_week=2,
	open_day=3,
	activity=11501,
	start_offset=36000,
	duration=388800,
	delay=0,
},
[5] = 
{
	id=5,
	open_week=2,
	open_day=3,
	activity=12001,
	start_offset=0,
	duration=424800,
	delay=0,
},
[6] = 
{
	id=6,
	open_week=2,
	open_day=3,
	activity=20203,
	start_offset=0,
	duration=431999,
	delay=0,
},
[8] = 
{
	id=8,
	open_week=3,
	open_day=1,
	activity=20901,
	start_offset=0,
	duration=604799,
	delay=0,
},
[9] = 
{
	id=9,
	open_week=3,
	open_day=1,
	activity=12301,
	start_offset=0,
	duration=252000,
	delay=0,
},
[10] = 
{
	id=10,
	open_week=3,
	open_day=1,
	activity=10701,
	start_offset=0,
	duration=252000,
	delay=86400,
},
[11] = 
{
	id=11,
	open_week=3,
	open_day=1,
	activity=12101,
	start_offset=0,
	duration=424800,
	delay=0,
},
[12] = 
{
	id=12,
	open_week=3,
	open_day=1,
	activity=20202,
	start_offset=0,
	duration=604799,
	delay=0,
},
[13] = 
{
	id=13,
	open_week=3,
	open_day=3,
	activity=10901,
	start_offset=36000,
	duration=388800,
	delay=0,
},
[14] = 
{
	id=14,
	open_week=3,
	open_day=4,
	activity=11701,
	start_offset=0,
	duration=345599,
	delay=0,
},
[15] = 
{
	id=15,
	open_week=4,
	open_day=1,
	activity=11101,
	start_offset=0,
	duration=252000,
	delay=0,
},
[16] = 
{
	id=16,
	open_week=4,
	open_day=1,
	activity=12401,
	start_offset=0,
	duration=259199,
	delay=0,
},
[17] = 
{
	id=17,
	open_week=4,
	open_day=1,
	activity=12201,
	start_offset=0,
	duration=424800,
	delay=0,
},
[18] = 
{
	id=18,
	open_week=4,
	open_day=1,
	activity=20204,
	start_offset=0,
	duration=604799,
	delay=0,
},
[19] = 
{
	id=19,
	open_week=4,
	open_day=3,
	activity=11801,
	start_offset=0,
	duration=424800,
	delay=0,
},
[20] = 
{
	id=20,
	open_week=4,
	open_day=4,
	activity=20701,
	start_offset=0,
	duration=252000,
	delay=86400,
},
[21] = 
{
	id=21,
	open_week=5,
	open_day=1,
	activity=10801,
	start_offset=0,
	duration=597600,
	delay=0,
},
[22] = 
{
	id=22,
	open_week=5,
	open_day=1,
	activity=11901,
	start_offset=0,
	duration=431999,
	delay=0,
},
[23] = 
{
	id=23,
	open_week=5,
	open_day=1,
	activity=11001,
	start_offset=0,
	duration=252000,
	delay=0,
},
[24] = 
{
	id=24,
	open_week=5,
	open_day=4,
	activity=11701,
	start_offset=0,
	duration=345599,
	delay=0,
},
[25] = 
{
	id=25,
	open_week=5,
	open_day=1,
	activity=11401,
	start_offset=0,
	duration=604799,
	delay=0,
},
[26] = 
{
	id=26,
	open_week=6,
	open_day=1,
	activity=20801,
	start_offset=0,
	duration=604799,
	delay=0,
},
[27] = 
{
	id=27,
	open_week=6,
	open_day=1,
	activity=11001,
	start_offset=0,
	duration=252000,
	delay=0,
},
[28] = 
{
	id=28,
	open_week=6,
	open_day=1,
	activity=10701,
	start_offset=0,
	duration=252000,
	delay=86400,
},
[29] = 
{
	id=29,
	open_week=6,
	open_day=1,
	activity=12001,
	start_offset=0,
	duration=424800,
	delay=0,
},
[30] = 
{
	id=30,
	open_week=6,
	open_day=1,
	activity=20203,
	start_offset=0,
	duration=604799,
	delay=0,
},
[31] = 
{
	id=31,
	open_week=6,
	open_day=3,
	activity=11501,
	start_offset=36000,
	duration=388800,
	delay=0,
},
[32] = 
{
	id=32,
	open_week=7,
	open_day=3,
	activity=10901,
	start_offset=36000,
	duration=388800,
	delay=0,
},
[33] = 
{
	id=33,
	open_week=7,
	open_day=1,
	activity=12101,
	start_offset=0,
	duration=424800,
	delay=0,
},
[34] = 
{
	id=34,
	open_week=7,
	open_day=1,
	activity=20202,
	start_offset=0,
	duration=604799,
	delay=0,
},
[35] = 
{
	id=35,
	open_week=7,
	open_day=1,
	activity=11701,
	start_offset=0,
	duration=345599,
	delay=0,
},
[36] = 
{
	id=36,
	open_week=8,
	open_day=1,
	activity=11101,
	start_offset=0,
	duration=252000,
	delay=0,
},
[37] = 
{
	id=37,
	open_week=8,
	open_day=1,
	activity=20204,
	start_offset=0,
	duration=604799,
	delay=0,
},
[38] = 
{
	id=38,
	open_week=8,
	open_day=1,
	activity=12201,
	start_offset=0,
	duration=424800,
	delay=0,
},
[39] = 
{
	id=39,
	open_week=8,
	open_day=3,
	activity=11801,
	start_offset=0,
	duration=424800,
	delay=0,
},
[40] = 
{
	id=40,
	open_week=8,
	open_day=1,
	activity=12401,
	start_offset=0,
	duration=259199,
	delay=0,
},
[41] = 
{
	id=41,
	open_week=9,
	open_day=1,
	activity=10801,
	start_offset=0,
	duration=597600,
	delay=0,
},
[42] = 
{
	id=42,
	open_week=9,
	open_day=1,
	activity=11901,
	start_offset=0,
	duration=431999,
	delay=0,
},
[43] = 
{
	id=43,
	open_week=9,
	open_day=1,
	activity=11101,
	start_offset=0,
	duration=252000,
	delay=0,
},
[44] = 
{
	id=44,
	open_week=9,
	open_day=1,
	activity=12401,
	start_offset=0,
	duration=259199,
	delay=0,
},
[45] = 
{
	id=45,
	open_week=9,
	open_day=4,
	activity=11701,
	start_offset=0,
	duration=345599,
	delay=0,
},
[46] = 
{
	id=46,
	open_week=10,
	open_day=1,
	activity=20801,
	start_offset=0,
	duration=604799,
	delay=0,
},
[47] = 
{
	id=47,
	open_week=10,
	open_day=1,
	activity=11001,
	start_offset=0,
	duration=252000,
	delay=0,
},
[48] = 
{
	id=48,
	open_week=10,
	open_day=1,
	activity=10701,
	start_offset=0,
	duration=252000,
	delay=86400,
},
[49] = 
{
	id=49,
	open_week=10,
	open_day=1,
	activity=12001,
	start_offset=0,
	duration=424800,
	delay=0,
},
[50] = 
{
	id=50,
	open_week=10,
	open_day=1,
	activity=20203,
	start_offset=0,
	duration=604799,
	delay=0,
},
[51] = 
{
	id=51,
	open_week=10,
	open_day=3,
	activity=11501,
	start_offset=36000,
	duration=388800,
	delay=0,
},
[52] = 
{
	id=52,
	open_week=11,
	open_day=1,
	activity=12101,
	start_offset=0,
	duration=424800,
	delay=0,
},
[53] = 
{
	id=53,
	open_week=11,
	open_day=1,
	activity=20202,
	start_offset=0,
	duration=604799,
	delay=0,
},
[54] = 
{
	id=54,
	open_week=11,
	open_day=1,
	activity=11701,
	start_offset=0,
	duration=345599,
	delay=0,
},
[55] = 
{
	id=55,
	open_week=11,
	open_day=3,
	activity=10901,
	start_offset=36000,
	duration=388800,
	delay=0,
},
[61] = 
{
	id=61,
	open_week=12,
	open_day=1,
	activity=10801,
	start_offset=0,
	duration=597600,
	delay=0,
},
[62] = 
{
	id=62,
	open_week=12,
	open_day=1,
	activity=20701,
	start_offset=0,
	duration=252000,
	delay=86400,
},
[63] = 
{
	id=63,
	open_week=12,
	open_day=4,
	activity=12701,
	start_offset=0,
	duration=259199,
	delay=0,
},
[64] = 
{
	id=64,
	open_week=12,
	open_day=1,
	activity=11401,
	start_offset=0,
	duration=604799,
	delay=0,
},
[65] = 
{
	id=65,
	open_week=12,
	open_day=1,
	activity=21001,
	start_offset=0,
	duration=604799,
	delay=0,
},
[66] = 
{
	id=66,
	open_week=13,
	open_day=1,
	activity=10801,
	start_offset=0,
	duration=597600,
	delay=0,
},
[67] = 
{
	id=67,
	open_week=13,
	open_day=1,
	activity=20701,
	start_offset=0,
	duration=252000,
	delay=86400,
},
[68] = 
{
	id=68,
	open_week=13,
	open_day=4,
	activity=12701,
	start_offset=0,
	duration=259199,
	delay=0,
},
[69] = 
{
	id=69,
	open_week=13,
	open_day=1,
	activity=11401,
	start_offset=0,
	duration=604799,
	delay=0,
},
[70] = 
{
	id=70,
	open_week=13,
	open_day=1,
	activity=21001,
	start_offset=0,
	duration=604799,
	delay=0,
},
}
