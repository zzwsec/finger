
-- pm.TbActivityServerOpen



return
{
[1] = 
{
	id=1,
	open_day=1,
	activity=10401,
	start_offset=0,
	duration=25912800,
	delay=0,
},
[2] = 
{
	id=2,
	open_day=1,
	activity=10501,
	start_offset=0,
	duration=60472800,
	delay=0,
},
[3] = 
{
	id=3,
	open_day=1,
	activity=11201,
	start_offset=0,
	duration=60479999,
	delay=0,
},
[4] = 
{
	id=4,
	open_day=1,
	activity=11401,
	start_offset=0,
	duration=60479999,
	delay=0,
},
[5] = 
{
	id=5,
	open_day=1,
	activity=11601,
	start_offset=0,
	duration=60479999,
	delay=0,
},
[6] = 
{
	id=6,
	open_day=2,
	activity=10301,
	start_offset=0,
	duration=25912800,
	delay=0,
},
[7] = 
{
	id=7,
	open_day=5,
	activity=10701,
	start_offset=0,
	duration=25912800,
	delay=86400,
},
[8] = 
{
	id=8,
	open_day=6,
	activity=11901,
	start_offset=0,
	duration=43199999,
	delay=0,
},
[9] = 
{
	id=9,
	open_day=8,
	activity=10201,
	start_offset=0,
	duration=60479999,
	delay=0,
},
[10] = 
{
	id=10,
	open_day=11,
	activity=11701,
	start_offset=0,
	duration=43199999,
	delay=0,
},
}
