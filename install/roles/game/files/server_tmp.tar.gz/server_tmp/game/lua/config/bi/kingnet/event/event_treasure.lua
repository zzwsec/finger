
-- pm.TbBiKingnetEventEventTreasure



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="事件类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="config_id1",
	name="宝物id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="type",
	name="是否消耗道具",
	type=0,
	opt=1,
	default_value="",
},
}
