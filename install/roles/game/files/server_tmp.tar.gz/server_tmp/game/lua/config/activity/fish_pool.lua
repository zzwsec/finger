
-- pm.TbFishPool



return
{
[310] = 
{
	id=310,
	cost=
	{
		id=310,
		num=1,
	},
	pool=
	{
	
		{
			value=211,
			pr=8800,
		},
	
		{
			value=212,
			pr=1000,
		},
	
		{
			value=213,
			pr=200,
		},
	},
},
[311] = 
{
	id=311,
	cost=
	{
		id=311,
		num=1,
	},
	pool=
	{
	
		{
			value=211,
			pr=4000,
		},
	
		{
			value=212,
			pr=4000,
		},
	
		{
			value=213,
			pr=2000,
		},
	},
},
[312] = 
{
	id=312,
	cost=
	{
		id=312,
		num=1,
	},
	pool=
	{
	
		{
			value=211,
			pr=1500,
		},
	
		{
			value=212,
			pr=5000,
		},
	
		{
			value=213,
			pr=3000,
		},
	
		{
			value=214,
			pr=500,
		},
	},
},
[313] = 
{
	id=313,
	cost=
	{
		id=313,
		num=1,
	},
	pool=
	{
	
		{
			value=211,
			pr=1000,
		},
	
		{
			value=212,
			pr=4000,
		},
	
		{
			value=213,
			pr=3500,
		},
	
		{
			value=214,
			pr=1000,
		},
	
		{
			value=215,
			pr=500,
		},
	},
},
}
