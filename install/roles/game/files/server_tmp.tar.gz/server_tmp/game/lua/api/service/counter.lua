local Log = require("common.logging")
local Result = require("common.result")

local Http = require("api.utility.http")
local Validator = require("api.utility.validator")
local DataCast = import("api.utility.cast").Counter
local ServerOptions = import("api.utility.config").ServerOptions

local BaseUrl = ServerOptions.Url

local _M = {}

-- 创建计数器
function _M.Create(coro, message)
    if not Validator.validateParams(message, {"counter_id", "project_id"}) then
        Log.Warn("CreateCounter", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/counters", BaseUrl, message.project_id)
    local ok, resp = Http.Post(coro, url, {
        body = {
            id = message.counter_id,
            value = message.value or 0,
            ttl = message.ttl or 0
        }
    })

    local result = Http.HandleResponse(ok, resp, "CreateCounter")
    if result:is_err() then
        Log.Warn("CreateCounter", "Failed to create counter: {}", result:unwrap_err())
        return result
    end

    local counter = DataCast.toCounter(result:unwrap())
    if not counter then
        Log.Warn("CreateCounter", "counter is nil")
        return Result.err("SYSTEM_BUSY")
    end
    Log.Debug("CreateCounter", "Created counter: {}", counter)
    return Result.ok(counter)
end

-- 获取计数器
function _M.Get(coro, message)
    if not Validator.validateParams(message, {"counter_id", "project_id"}) then
        Log.Warn("GetCounter", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/counters/%s", BaseUrl, message.project_id, message.counter_id)
    local ok, resp = Http.Get(coro, url)
    local result = Http.HandleResponse(ok, resp, "GetCounter")
    if result:is_err() then
        Log.Warn("GetCounter", "Failed to get counter: {}", result:unwrap_err())
        return result
    end

    local counter = DataCast.toCounter(result:unwrap())
    if not counter then
        Log.Warn("GetCounter", "counter is nil")
        return Result.err("SYSTEM_BUSY")
    end
    Log.Debug("GetCounter", "Got counter: {}", counter)
    return Result.ok(counter)
end

-- 删除计数器
function _M.Delete(coro, message)
    if not Validator.validateParams(message, {"counter_id", "project_id"}) then
        Log.Warn("DeleteCounter", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/counters/%s", BaseUrl, message.project_id, message.counter_id)
    local ok, resp = Http.Delete(coro, url)
    local result = Http.HandleResponse(ok, resp, "DeleteCounter")
    if result:is_err() then
        Log.Warn("DeleteCounter", "Failed to delete counter: {}", result:unwrap_err())
        return result
    end

    Log.Debug("DeleteCounter", "Deleted counter: {}", message)
    return Result.ok("OK")
end

-- 增加计数器
function _M.Increment(coro, message)
    if not Validator.validateParams(message, {"counter_id", "project_id"}) then
        Log.Warn("IncrementCounter", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/counters/%s/increment", BaseUrl, message.project_id, message.counter_id)
    local ok, resp = Http.Put(coro, url, {
        body = {
            step = message.step or 1
        }
    })
    local result = Http.HandleResponse(ok, resp, "IncrementCounter")
    if result:is_err() then
        Log.Warn("IncrementCounter", "Failed to increment counter: {}", result:unwrap_err())
        return result
    end

    local counter = DataCast.toCounter(result:unwrap())
    if not counter then
        Log.Warn("IncrementCounter", "counter is nil")
        return Result.err("SYSTEM_BUSY")
    end
    Log.Debug("IncrementCounter", "Incremented counter: {}", counter)
    return Result.ok(counter)
end

-- 减少计数器
function _M.Decrement(coro, message)
    if not Validator.validateParams(message, {"counter_id", "project_id"}) then
        Log.Warn("DecrementCounter", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/counters/%s/decrement", BaseUrl, message.project_id, message.counter_id)
    local ok, resp = Http.Put(coro, url, {
        body = {
            step = message.step or 1
        }
    })
    local result = Http.HandleResponse(ok, resp, "DecrementCounter")
    if result:is_err() then
        Log.Warn("DecrementCounter", "Failed to decrement counter: {}", result:unwrap_err())
        return result
    end

    local counter = DataCast.toCounter(result:unwrap())
    if not counter then
        Log.Warn("DecrementCounter", "counter is nil")
        return Result.err("SYSTEM_BUSY")
    end
    Log.Debug("DecrementCounter", "Decremented counter: {}", counter)
    return Result.ok(counter)
end

return _M