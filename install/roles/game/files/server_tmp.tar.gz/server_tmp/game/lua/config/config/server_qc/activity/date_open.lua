
-- pm.TbActivityDateOpen



return
{
[1] = 
{
	id=1,
	activity=10702,
	begin_time=1727661600,
	end_time=1728396000,
	delay=86400,
},
[2] = 
{
	id=2,
	activity=11302,
	begin_time=1735524000,
	end_time=1735826400,
	delay=86400,
},
}
