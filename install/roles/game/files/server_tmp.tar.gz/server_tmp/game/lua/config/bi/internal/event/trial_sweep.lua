
-- pm.TbBiInternalEventTrialSweep



return
{
[1] = 
{
	id=1,
	field="level_id",
	name="关卡id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="sweep_times",
	name="扫荡次数",
	type=0,
	opt=1,
	default_value="",
},
}
