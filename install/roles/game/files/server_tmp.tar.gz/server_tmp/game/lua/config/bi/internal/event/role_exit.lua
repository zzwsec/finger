
-- pm.TbBiInternalEventRoleExit



return
{
[1] = 
{
	id=1,
	field="page_staytime",
	name="时长",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="client_ip",
	name="用户的客户端ip",
	type=1,
	opt=0,
	default_value="",
},
}
