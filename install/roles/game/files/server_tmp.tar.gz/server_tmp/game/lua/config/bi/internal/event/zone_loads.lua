
-- pm.TbBiInternalEventZoneLoads



return
{
[1] = 
{
	id=1,
	field="zone_id",
	name="区服id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="player_num",
	name="玩家数量",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="online_player_num",
	name="在线玩家",
	type=0,
	opt=1,
	default_value="",
},
}
