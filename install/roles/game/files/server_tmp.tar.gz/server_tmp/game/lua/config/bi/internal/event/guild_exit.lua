
-- pm.TbBiInternalEventGuildExit



return
{
[1] = 
{
	id=1,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="guild_level",
	name="公会等级",
	type=0,
	opt=1,
	default_value="1",
},
[3] = 
{
	id=3,
	field="guild_job",
	name="公会职务",
	type=0,
	opt=1,
	default_value="0",
},
}
