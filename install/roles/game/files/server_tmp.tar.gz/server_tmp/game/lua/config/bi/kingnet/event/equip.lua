
-- pm.TbBiKingnetEventEquip



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="装备id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="装备品阶",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="num1",
	name="装备等级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="status",
	name="装备状态",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="info",
	name="装备属性",
	type=1,
	opt=1,
	default_value="",
},
}
