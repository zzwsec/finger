
-- pm.TbBusinessGoods



return
{
[201] = 
{
	id=201,
	icon=201,
	pj=3,
	name={key='business_goods_name/201',text="赤铁矿"},
	desc={key='business_goods_desc/201',text=""},
	base_price=15,
	price_ratio=
	{
	30,
	300,
	},
	condition=0,
},
[202] = 
{
	id=202,
	icon=202,
	pj=3,
	name={key='business_goods_name/202',text="棉布"},
	desc={key='business_goods_desc/202',text=""},
	base_price=20,
	price_ratio=
	{
	30,
	250,
	},
	condition=0,
},
[203] = 
{
	id=203,
	icon=203,
	pj=3,
	name={key='business_goods_name/203',text="便携干粮"},
	desc={key='business_goods_desc/203',text=""},
	base_price=25,
	price_ratio=
	{
	30,
	200,
	},
	condition=0,
},
[204] = 
{
	id=204,
	icon=204,
	pj=3,
	name={key='business_goods_name/204',text="能量电池"},
	desc={key='business_goods_desc/204',text=""},
	base_price=25,
	price_ratio=
	{
	30,
	200,
	},
	condition=0,
},
[205] = 
{
	id=205,
	icon=205,
	pj=4,
	name={key='business_goods_name/205',text="葡萄酒"},
	desc={key='business_goods_desc/205',text=""},
	base_price=50,
	price_ratio=
	{
	60,
	160,
	},
	condition=500,
},
[206] = 
{
	id=206,
	icon=206,
	pj=4,
	name={key='business_goods_name/206',text="急救喷雾"},
	desc={key='business_goods_desc/206',text=""},
	base_price=80,
	price_ratio=
	{
	60,
	150,
	},
	condition=3000,
},
[207] = 
{
	id=207,
	icon=207,
	pj=4,
	name={key='business_goods_name/207',text="火腿肉"},
	desc={key='business_goods_desc/207',text=""},
	base_price=100,
	price_ratio=
	{
	60,
	140,
	},
	condition=3000,
},
[208] = 
{
	id=208,
	icon=208,
	pj=4,
	name={key='business_goods_name/208',text="微型芯片"},
	desc={key='business_goods_desc/208',text=""},
	base_price=120,
	price_ratio=
	{
	60,
	130,
	},
	condition=3000,
},
[209] = 
{
	id=209,
	icon=209,
	pj=5,
	name={key='business_goods_name/209',text="无人机"},
	desc={key='business_goods_desc/209',text=""},
	base_price=250,
	price_ratio=
	{
	80,
	120,
	},
	condition=10000,
},
[210] = 
{
	id=210,
	icon=210,
	pj=5,
	name={key='business_goods_name/210',text="珠宝"},
	desc={key='business_goods_desc/210',text=""},
	base_price=440,
	price_ratio=
	{
	80,
	120,
	},
	condition=10000,
},
}
