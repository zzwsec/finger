
-- pm.TbBiInternalEventMailDel



return
{
[1] = 
{
	id=1,
	field="mail_id",
	name="邮件id",
	type=0,
	opt=1,
	default_value="",
},
}
