
-- pm.TbBiInternalEventOnlineCount



return
{
[1] = 
{
	id=1,
	field="platid",
	name="平台",
	type=1,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="channel",
	name="渠道",
	type=1,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="sid",
	name="区服",
	type=1,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="source_sid",
	name="原始服的区服id",
	type=1,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="server_onlyid",
	name="服务器id",
	type=1,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="timestamp",
	name="时间戳",
	type=1,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="num",
	name="在线人数",
	type=0,
	opt=0,
	default_value="",
},
}
