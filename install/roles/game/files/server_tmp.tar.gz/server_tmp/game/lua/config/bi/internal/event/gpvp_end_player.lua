
-- pm.TbBiInternalEventGpvpEndPlayer



return
{
[1] = 
{
	id=1,
	field="player_id",
	name="角色id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="level",
	name="段位",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="rank",
	name="排行",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="score",
	name="积分",
	type=0,
	opt=1,
	default_value="0",
},
}
