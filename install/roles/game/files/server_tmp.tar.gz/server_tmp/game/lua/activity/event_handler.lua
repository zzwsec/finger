local Log = require("common/logging")
local AppGameLib = require("app.game.lib")
local AppRankLib = require("app.rank.lib")

local Activity = import("activity/activity")
local Const = import("activity/const")
local Server = import("activity/server")

local g_game_activity_service = AppGameLib.ActivityService_Stub.new(g_channel)
local g_rank_service = AppRankLib.RankService_Stub.new(g_channel)
local g_rank_guild_service = AppRankLib.GuildService_Stub.new(g_channel)

-- 活动开放或者结束通知
local function OnHandleEvent_ActivityOpenTime(player, coro, type, message)
    local player_data = player:GetData()
    if message.state == Const.ActiveState.CLOSED and player_data:activitys(message.id) then
        player_data:remove_activitys( message.id)
        g_player_manager:PlayerRemoveActivity(player_data:id(), message.id)
    end 
end
Handlers["ActivityOpenTimeEvent"] = Handlers["ActivityOpenTimeEvent"] or {}
table.insert(Handlers["ActivityOpenTimeEvent"], OnHandleEvent_ActivityOpenTime)

local function NotifyRank(coro, rank_list)
    if rank_list == nil or next(rank_list) == nil then
        return 
    end
    local rank_service_id = g_router_manager:MatchRankService()
    if rank_service_id == nil then
        Log.Debug("NotifyRank", "rank service is not online")
        return
    end
    local sync_activity_req = {
        ["activitys"] = rank_list,
    }
    assert(g_rank_service:SyncActivity(rank_service_id, sync_activity_req, function(sync_activity_error, sync_activity_resp)
        coroutine.resume(coro, sync_activity_error, sync_activity_resp)
    end))
    local sync_activity_error, sync_activity_resp = coroutine.yield()
    if (sync_activity_error ~= "OK") or (sync_activity_resp.result ~= "OK") then
        Log.Debug("NotifyRank", "sync activity faield: error = {}, result = {}", sync_activity_error, sync_activity_resp.result)
        return
    end
    Log.Debug("NotifyRank", "sync activity ok, rank_list = {}", rank_list)
    Activity.UpdateLastRankList(rank_list)
end

-- 公会排行活动
local function NotifyGuildRank(coro, rank_list)
    if rank_list == nil or next(rank_list) == nil then
        return 
    end
    local rank_service_id = g_router_manager:MatchRankService()
    if rank_service_id == nil then
        Log.Debug("NotifyGuildRank", "rank service is not online")
        return
    end
    local sync_activity_req = {
        ["activitys"] = rank_list,
    }
    assert(g_rank_guild_service:SyncActivity(rank_service_id, sync_activity_req , function(sync_activity_error, sync_activity_resp)
        coroutine.resume(coro, sync_activity_error, sync_activity_resp)
    end))
    local sync_activity_error, sync_activity_resp = coroutine.yield()
    if (sync_activity_error ~= "OK") or (sync_activity_resp.result ~= "OK") then
        Log.Debug("NotifyGuildRank", "sync activity faield: error = {}, result = {}, retry after", sync_activity_error, sync_activity_resp.result)
        return
    end
    
    Log.Debug("NotifyGuildRank", "sync activity ok, rank_list = {}", rank_list)
    Activity.UpdateLastRankList(rank_list)
end

-- 驱动时间
local last_tick_time = 0
local function OnHandleEvent_Tick(now_time, last_time)
    if last_tick_time + 10 <= now_time then
        local coro = coroutine.create(function(coro, now_time)
            xpcall(function( ... )
                local activitys, rank_list, guild_rank_list = Activity.CheckOpen(now_time, last_tick_time)
                -- Log.Debug("OnHandleEvent_Tick", "open activity = {}, rank_list = {}", activitys, rank_list)
                NotifyRank(coro, rank_list)
                NotifyGuildRank(coro, guild_rank_list)
                if activitys == nil or next(activitys) == nil then
                    last_tick_time = now_time
                    return
                end
                local game_service_ids = Server.GetGameServiceIds()
                local open_time_notify_req = {
                    ["activitys"] = activitys,
                }
                for _, game_service_id in pairs(game_service_ids) do
                    assert(g_game_activity_service:OpenTimeNotify(game_service_id, open_time_notify_req, function() end))
                end
                last_tick_time = now_time
            end, function(err_msg)
                Log.Debug("Lua", err_msg)
            end)
        end)
        assert(coroutine.resume(coro, coro, now_time))
    end
end
Handlers["TickEvent"] = Handlers["TickEvent"] or {}
table.insert(Handlers["TickEvent"], OnHandleEvent_Tick)
