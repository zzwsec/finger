local coroutine = require("coroutine")
local string = require("string")

local Log = require("common/logging")
local Queue = require("common/queue")

local Models = require("activity/table")

Modules.Player_MODULE = Modules.Player_MODULE or {}
local M = Modules.Player_MODULE

-- 玩家
M.Player = M.Player or {}
M.Player.__index = M.Player

-- 创建
function M.Player.new( ... )
    local o = {}
    setmetatable(o, M.Player)
    o:ctor(...)
    return o
end

-- 构造函数
function M.Player:ctor(data, save_callback)
    self.data_ = Models.Player.new(data)
    self.save_callback_ = function(data, data_size)
        if data_size > 0 then
            save_callback(data, data_size)
        end
    end
    self.running_ = false
    self.events_ = Queue.new()
    self.coro_ = coroutine.create(M.EventLoop)
    self.coro_running_ = false
end

-- 获取角色id 
function M.Player:GetId() 
    return self.data_:id()
end

-- 获取数据
function M.Player:GetData() 
    return self.data_
end

-- 启动
function M.Player:Start()
    assert(not self.running_ and not self.coro_running_)
    self.running_ = true
    self.coro_running_ = true
    coroutine.resume(self.coro_, self, self.coro_)
end

-- 停止
function M.Player:Stop()
    assert(self.running_)
    self.running_ = false
    if not self.coro_running_ then
        self.coro_running_ = true
        coroutine.resume(self.coro_, self, self.coro_)
    end
end 

-- 唤醒
function M.Player:Wakeup()
    if self.running_ and not self.coro_running_ then
        self.coro_running_ = true
        coroutine.resume(self.coro_, self, self.coro_)
    end
end

-- 在协程队列中运行
function M.Player:Invoke(method_name, message, done)
    self.events_:Push(function(player, coro)
        local handler = Handlers[method_name]
        if handler ~= nil then
            handler(player, coro, message, done)
        else 
            Log.Warn("Player", "Unhandle message: method_name = %s", method_name)
        end
    end)
    self:Wakeup()
end

-- 投递事件
function M.Player:PostEvent(event_name, ...)
    local args = { ... }
    self.events_:Push(function(player, coro)
        for _, handler in ipairs(Handlers[event_name] or {}) do
            handler(player, coro, event_name, table.unpack(args))
        end
    end)
    self:Wakeup()
end

-- 同步数据
function M.Player:Sync()
    assert(self.running_)
    M.DirtyData(self)
end

-- 胀字段
function M.DirtyData(player)
    g_msgpack_packer:reset()
    player.data_:Dirty(g_msgpack_packer, 1)
    g_msgpack_packer:reset(player.save_callback_)
    player.data_:ClearDirty()
end

-- 主循环
function M.EventLoop(player, coro)
    local error_handler = function(err_msg)
        Log.Error("Lua", err_msg)
    end
    while player.running_ do 
        if player.events_:IsEmpty() then 
            player.coro_running_ = false
            coroutine.yield()
        end
        local i, count = 1, player.events_:Size()
        while player.running_ and i <= count do
            local event = player.events_:Top()
            xpcall(event, error_handler, player, coro)
            if player.running_ then
                M.DirtyData(player)
            end
            i = i + 1
            player.events_:Pop()
        end
    end 
    player.events_:Clear()
end

return M.Player