local Lamda = require("common/lamda")
local Log = require("common/logging")
local Time = require("common/time")

local Config = import("cave/config")
local Utils = import("cave/utils/utils")

local Root = import("config/root", true)

Modules.Cave_MODULE = Modules.Cave_MODULE or {}

local M = Modules.Cave_MODULE

function M.NearMaxNum()
    return Root.Cave.NEAR_NUM
end

function M.RecordMaxNum()
    return Root.Cave.NEAR_NUM
end

function M.RootConfig(node, sub_node)
    if Root[node] then
        return Root[node][sub_node]
    end
    return nil
end


function M.RandomResouce(title_id)
    Log.Debug("Cave.RandomResouce", "title_id:{}", title_id or 0)
    local configs = Config.ResourcePoolConfig(title_id)
    if next(configs) == nil then
        return 0
    end
    local results = Utils.RandomGoods(configs, 'weight', 1)
    for _, item in pairs(results) do
        return item.id
    end
    return 0
end

return M 