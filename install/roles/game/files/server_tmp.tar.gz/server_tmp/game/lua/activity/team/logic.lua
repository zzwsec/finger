local Log = require("common/logging")
local Time = require("common/time")

local Convert = import("activity/team/convert")

local Root = import("config/root", true)

local M = {}

-- 添加成员
function M.AddMember(team, team_data, member_id, zone_id, is_leader)
    is_leader = is_leader ~= nil and is_leader or false
    local member = team_data:add_members(member_id)
    member:set_zone_id(zone_id)
    member:set_leader(is_leader)
    g_team_manager:BuildMembership(team_data:rank_id(), team_data:id(), member_id)
    if team_data:members_size() >= Root.Team.MAX_MEMBER_SIZE then
        team_data:clear_applys()
    else
        -- 移除申请列表数据
        team_data:remove_applys(member_id)
    end
end

-- 创建队伍
function M.CreateTeam(team, message)
    local team_data = team:GetData()
    local now_time = os.now()
    team_data:set_create_time(now_time)
    team_data:set_season_id(message.season_id)
    M.AddMember(team, team_data, message.player_id, message.zone_id, true)
    local to_team = {}
    Convert.Team2Table(team_data, to_team)
    return "OK", to_team
end

-- 退出队伍
function M.QuitTeam(team, message)
    local team_data = team:GetData()
    local player_id = message.player_id or 0
    local member = team_data:members(player_id)
    if member == nil then
        return "OK"
    end
    if member:leader() then
        return "FAILED"
    end
    team_data:remove_members(player_id)
    g_team_manager:RemoveMembership(team_data:rank_id(), player_id)
    return "OK"
end

-- 加入队伍
function M.JoinTeam(team, message)
    local team_data = team:GetData()
    if team_data:members_size() >= Root.Team.MAX_MEMBER_SIZE then
        return "TEAM_FULL"
    end
    M.AddMember(team, team_data, message.player_id, message.zone_id)
    local to_team = {}
    Convert.Team2Table(team_data, to_team)
    return "OK", to_team
end

-- 拉取队伍
function M.FetchTeam(team, message)
    local rank_id = message.rank_id or 0
    local player_id = message.player_id or 0
    local team_data = team:GetData()
    local to_team = {}
    Convert.Team2Table(team_data, to_team)
    return "OK", to_team
end

-- 申请加入
function M.ApplyTeam(team, message)
    local rank_id = message.rank_id or 0
    local member_id = message.player_id or 0
    local zone_id = message.zone_id or 0
    local cancel = message.cancel
    local team_data = team:GetData()
    local team_id = team_data:id()
    if not cancel then
        if g_team_manager:GetTeamByPlayerId(rank_id, member_id) ~= nil then
            return "TEAM_EXIST"
        end
        if g_team_manager:GetMemberApplySize(rank_id, member_id) >= Root.Team.MAX_APPLY then
            return "APLLY_LIMIT"
        end
        if team_data:members_size() >= Root.Team.MAX_MEMBER_SIZE then
            return "TEAM_FULL"
        end
        if team_data:applys_size() >= Root.Team.MAX_TEAM_APPLY then
            return "APLLY_LIMIT"
        end
        local apply = team_data:applys(member_id)
        if apply == nil then
            apply = team_data:add_applys(member_id)
        end
        apply:set_zone_id(zone_id)
        apply:set_time(os.now())
        g_team_manager:BuildMemberApply(rank_id, team_id, member_id)
    else
        team_data:remove_applys(member_id)
        g_team_manager:RemoveMemberApply(rank_id, member_id, team_id)
    end
    local leader_id, leader_zone_id = 0, 0
    for id, member in team_data:members() do
        if member:leader() then
            leader_id = id
            leader_zone_id = member:zone_id()
            break
        end
    end
    team:PostEvent("ApplyTeamEvent",  {
        leader_id = leader_id,
        leader_zone_id = leader_zone_id,
        apply_id = member_id,
        apply_zone_id = zone_id,
        join = cancel == false and true or false
    })
    return "OK"
end

-- 同意申请
function M.AgreeApply(team, message)
    local rank_id = message.rank_id or 0
    local apply_id = message.apply_id or 0
    if g_team_manager:GetTeamByPlayerId(rank_id, apply_id) ~= nil then
        team_data:remove_applys(apply_id)
        return "TEAM_EXIST"
    end
    local team_data = team:GetData()
    if team_data:members_size() >= Root.Team.MAX_MEMBER_SIZE then
        return "TEAM_FULL"
    end
    local apply = team_data:applys(apply_id)
    if apply == nil then
        return "NO_APPLY"
    end
    M.AddMember(team, team_data, apply_id, apply:zone_id())
    local to_team = {}
    Convert.Team2Table(team_data, to_team)
    g_team_manager:RemoveMemberApply(rank_id, apply_id, 0)
    return "OK", to_team
end

-- 拒绝申请
function M.IgnoreApply(team, message)
    local apply_id = message.apply_id or 0
    local team_data = team:GetData()
    team_data:remove_applys(apply_id)
    return "OK"
end

-- 更新积分
function M.UpdateScore(team, message)
    local player_id = message.player_id or 0
    local score = message.score or 0
    local team_data = team:GetData()
    local member = team_data:members(player_id)
    if member == nil then
        return "NO_MEMBER"
    end
    local old_score = member:score()
    local new_score = math.max(0, old_score + score)
    member:set_score(new_score)
    member:set_time(os.now())
    local team_score = 0
    for _, item in team_data:members() do
        team_score = team_score + item:score()
    end
    return "OK", new_score, team_score
end

return M