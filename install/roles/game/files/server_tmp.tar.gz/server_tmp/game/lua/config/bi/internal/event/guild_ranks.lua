
-- pm.TbBiInternalEventGuildRanks



return
{
[1] = 
{
	id=1,
	field="activity_id",
	name="活动id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="type",
	name="活动类型",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="rank",
	name="排行",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="value",
	name="数据",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="job_info",
	name="公会职务",
	type=1,
	opt=0,
	default_value="0",
},
}
