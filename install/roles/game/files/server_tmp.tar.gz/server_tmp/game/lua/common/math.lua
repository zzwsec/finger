local function gcd(a, b)
    while b ~= 0 do
        c = a % b
        a = b
        b = c
    end
    return a
end

local function lcm(a, b)
    return a * b / gcd(a, b)
end

return {
    ["gcd"] = gcd,
    ["lcm"] = lcm,
}