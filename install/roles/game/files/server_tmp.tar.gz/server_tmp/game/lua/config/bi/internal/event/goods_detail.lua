
-- pm.TbBiInternalEventGoodsDetail



return
{
[1] = 
{
	id=1,
	field="detail_id",
	name="明细id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="produce",
	name="产出",
	type=1,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="consume",
	name="消费",
	type=1,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="way",
	name="途径",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="context",
	name="上下文信息",
	type=1,
	opt=1,
	default_value="",
},
}
