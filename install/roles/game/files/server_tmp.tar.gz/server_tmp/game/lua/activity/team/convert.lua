local M = {}

function M.Team2Table(from, to)
    to = to or {}

    to.id = from:id()
    to.zone_id = from:zone_id()
    to.name = from:name()
    to.members = {}
    for id, member in from:members() do
        local to_member = {
            id = id,
            zone_id = member:zone_id(),
            score = member:score(),
            leader = member:leader(),
        }
        to.members[id] = to_member
    end
    to.applys = {}
    for id, apply in from:applys() do
        local to_apply = {
            id = id,
            zone_id = apply:zone_id(),
            time = apply:time(),
        }
        to.applys[id] = to_apply
    end
end

return M