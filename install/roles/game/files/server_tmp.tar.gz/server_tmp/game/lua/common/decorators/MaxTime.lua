local class = require "utils.class"
local Constants = require "core.Constants"

local Decorator = require 'core.Decorator'

local MaxTime = class("MaxTime", Decorator)

function MaxTime:ctor(params)
    Decorator.ctor(self)

    self.name = "MaxTime"
    self.title = "Max <maxTime>ms"
    self.parameters = {maxTime = 0}

    assert(params and params.maxTime, "maxTime parameter in MaxTime decorator is an obligatory parameter")

    self.maxTime = params.maxTime
end

function MaxTime:initialize(params)

end

function MaxTime:open(tick)
    assert(self.child, "no chilld")

    local currTime = tick.nowTime
    local startTime = tick.blackboard.get("startTime", tick.tree.id, self.id)

    local status = self.child:_execute(tick)
    if currTime - startTime > self.maxTime then
        return Constants.FAILURE
    end

    return status
end

return MaxTime
