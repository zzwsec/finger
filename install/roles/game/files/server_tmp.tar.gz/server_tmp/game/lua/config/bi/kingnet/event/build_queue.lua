
-- pm.TbBiKingnetEventBuildQueue



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="队列id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="status",
	name="状态",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="page_staytime",
	name="持续时间",
	type=0,
	opt=1,
	default_value="",
},
}
