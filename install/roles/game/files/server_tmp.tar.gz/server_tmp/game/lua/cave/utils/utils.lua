local Lamda = require("common/lamda")
local Log = require("common/logging")

local Algo = import("cave/utils/algo")

local M = {}

-- 类型编码
function M.Encode(low, high)
    return (low & 0xffff) | ((high & 0xffff) << 16)
end

-- 类型解码
function M.Decode(id)
    local low = id & 0xffff
    local high = (id >> 16) & 0xffff
    return low, high
end

-- 通用道具随机接口
function M.RandomGoods(pool, property, times, callback)
    callback = callback or function( ... )
        return true
    end
    local result = {}
    local weights = Lamda.pluck(property, pool or {})
    if next(weights) == nil then 
        return result
    end
    local am = Algo.AliasMultionmial.new(weights)
    for index = 1, times do
        local item = pool[am:next()]
        if item ~= nil and callback(item) then 
            result[#result+1] = item
        end
    end
    return result
end

function M.RandomPool(pool, times, callback)
    callback = callback or function( ... )
        return true
    end
    local result = {}
    local weights = pool or {}
    if next(weights) == nil then 
        return result
    end
    local am = Algo.AliasMultionmial.new(weights)
    for index = 1, times do
        local item = pool[am:next()]
        if item ~= nil and callback(item) then 
            result[#result+1] = item
        end
    end
    return result
end


return M