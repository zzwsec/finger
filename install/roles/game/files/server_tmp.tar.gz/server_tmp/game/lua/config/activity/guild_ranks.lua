
-- pm.TbActivityGuildRanks



return
{
[1] = 
{
	id=1,
	type=20,
	rank_range=
	{
	1,
	1,
	},
	chairman_mail=2521,
	vice_chairman_mail=2541,
	member_mail=2551,
	conditions=1000,
},
[2] = 
{
	id=2,
	type=20,
	rank_range=
	{
	2,
	2,
	},
	chairman_mail=2522,
	vice_chairman_mail=2542,
	member_mail=2552,
	conditions=800,
},
[3] = 
{
	id=3,
	type=20,
	rank_range=
	{
	3,
	3,
	},
	chairman_mail=2523,
	vice_chairman_mail=2543,
	member_mail=2553,
	conditions=700,
},
[4] = 
{
	id=4,
	type=20,
	rank_range=
	{
	4,
	5,
	},
	chairman_mail=2524,
	vice_chairman_mail=2544,
	member_mail=2554,
	conditions=500,
},
[5] = 
{
	id=5,
	type=20,
	rank_range=
	{
	6,
	7,
	},
	chairman_mail=2525,
	vice_chairman_mail=2545,
	member_mail=2555,
	conditions=400,
},
[6] = 
{
	id=6,
	type=20,
	rank_range=
	{
	8,
	10,
	},
	chairman_mail=2526,
	vice_chairman_mail=2546,
	member_mail=2556,
	conditions=300,
},
[7] = 
{
	id=7,
	type=20,
	rank_range=
	{
	11,
	20,
	},
	chairman_mail=2527,
	vice_chairman_mail=2547,
	member_mail=2557,
	conditions=200,
},
[8] = 
{
	id=8,
	type=20,
	rank_range=
	{
	20,
	99,
	},
	chairman_mail=2528,
	vice_chairman_mail=2548,
	member_mail=2558,
	conditions=0,
},
}
