local class = require "utils.class"
local Constants = require "core.Constants"

local Action = require 'core.Action'

local Runner = class("Runner", Action)

function Runner:ctor()
    Action.ctor(self)

    self.name = "Runner"
end

function Runner:tick(tick)
    return Constants.RUNNING
end

return Runner