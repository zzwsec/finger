
-- pm.TbBiKingnetKingnet



return
{
["https://kdclog.kingnetdc.com/dana"] = 
{
	Url="https://kdclog.kingnetdc.com/dana",
	Project="dana_kxdkg",
	Topic="dana_kxdkg",
	Token="6107fc26cd3d49768c457d667f36d452",
	Key="",
	IsGzip=false,
	BatchBufferCapactity=2,
	Gid=300167,
},
}
