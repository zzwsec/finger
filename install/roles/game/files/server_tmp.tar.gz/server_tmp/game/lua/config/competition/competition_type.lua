
-- pm.TbCompetitionType



return
{
[1] = 
{
	id=1,
	condition=
	{
	
		{
			type=4,
			param=
			{
				type=300,
				value=500,
			},
		},
	
		{
			type=6,
			param=
			{
				type=1,
				value=1,
			},
		},
	},
	match_max=10,
	duration=2700,
	limit_times=1,
	robot_group=
	{
	20001,
	20002,
	20003,
	20004,
	20005,
	20006,
	20007,
	20008,
	20009,
	20010,
	},
},
[2] = 
{
	id=2,
	condition=
	{
	
		{
			type=5,
			param=
			{
				type=450000,
				value=500000,
			},
		},
	
		{
			type=6,
			param=
			{
				type=2,
				value=2,
			},
		},
	},
	match_max=10,
	duration=2700,
	limit_times=1,
	robot_group=
	{
	20011,
	20012,
	20013,
	20014,
	20015,
	20016,
	20017,
	20018,
	20019,
	20020,
	},
},
[3] = 
{
	id=3,
	condition=
	{
	
		{
			type=10,
			param=
			{
				type=700000,
				value=800000,
			},
		},
	
		{
			type=6,
			param=
			{
				type=3,
				value=3,
			},
		},
	},
	match_max=10,
	duration=2700,
	limit_times=1,
	robot_group=
	{
	20021,
	20022,
	20023,
	20024,
	20025,
	20026,
	20027,
	20028,
	20029,
	20030,
	},
},
}
