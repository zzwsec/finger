
-- pm.TbBiKingnetEventTowerSweep



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="停留层数",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="扫荡层数",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="info",
	name="buff",
	type=1,
	opt=1,
	default_value="",
},
}
