
-- pm.TbFish



return
{
[211] = 
{
	id=211,
	pj=2,
	icon=211,
	name={key='fish_name/211',text="鲤鱼"},
	desc={key='fish_desc/211',text="一种常见的鱼类。"},
	price=50,
},
[212] = 
{
	id=212,
	pj=3,
	icon=212,
	name={key='fish_name/212',text="鲶鱼"},
	desc={key='fish_desc/212',text="一种能在小溪中找到的罕见鱼类。"},
	price=100,
},
[213] = 
{
	id=213,
	pj=4,
	icon=213,
	name={key='fish_name/213',text="鳕鱼"},
	desc={key='fish_desc/213',text="一种冷水性底栖海洋经济鱼类。"},
	price=300,
},
[214] = 
{
	id=214,
	pj=5,
	icon=214,
	name={key='fish_name/214',text="鳟鱼"},
	desc={key='fish_desc/214',text="一种能在江河流速较缓的水域或湖泊中找到的鱼类。"},
	price=800,
},
[215] = 
{
	id=215,
	pj=6,
	icon=215,
	name={key='fish_name/215',text="大嘴鲈鱼"},
	desc={key='fish_desc/215',text="一种在湖里的受欢迎鱼类。"},
	price=2000,
},
}
