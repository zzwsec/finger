
-- pm.TbBiKingnetEventGuildContribute



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="num",
	name="捐献类型",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="num1",
	name="捐献次数",
	type=0,
	opt=1,
	default_value="0",
},
}
