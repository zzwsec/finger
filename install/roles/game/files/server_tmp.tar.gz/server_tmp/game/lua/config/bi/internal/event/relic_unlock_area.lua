
-- pm.TbBiInternalEventRelicUnlockArea



return
{
[1] = 
{
	id=1,
	field="area_id",
	name="区域id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="slot_num",
	name="槽位数量",
	type=0,
	opt=1,
	default_value="",
},
}
