local class = require "utils.class"
local Constants = require "core.Constants"

local Composite = require 'core.Composite'

local Priority = class("Priority", Composite)

function Priority:ctor()
    Composite.ctor(self)

    self.name = "Priority"
end

function Priority:tick(tick)
    for i,v in pairs(self.children) do
        local status = v:_execute(tick)

        if status ~= Constants.FAILURE then
            return status
        end
    end

    return Constants.FAILURE
end

return Priority