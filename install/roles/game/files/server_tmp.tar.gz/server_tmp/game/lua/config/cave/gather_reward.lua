
-- pm.TbCaveGatherReward



return
{
[1] = 
{
	id=1,
	pre_id=0,
	name={key='gather_reward/1',text="宝物箱"},
	times=20,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
	payment=0,
	rebate=0,
},
[2] = 
{
	id=2,
	pre_id=1,
	name={key='gather_reward/2',text="金矿"},
	times=50,
	rewards=
	{
	
		{
			id=1,
			num=6000,
		},
	},
	payment=80081,
	rebate=2000,
},
[3] = 
{
	id=3,
	pre_id=2,
	name={key='gather_reward/3',text="神秘宝藏"},
	times=100,
	rewards=
	{
	
		{
			id=1,
			num=10000,
		},
	},
	payment=80082,
	rebate=1500,
},
}
