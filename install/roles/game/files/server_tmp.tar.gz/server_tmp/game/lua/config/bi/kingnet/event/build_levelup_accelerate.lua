
-- pm.TbBiKingnetEventBuildLevelupAccelerate



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="建筑id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="建筑等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="type",
	name="加速类型",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="page_staytime",
	name="加速时间",
	type=0,
	opt=1,
	default_value="",
},
}
