
-- pm.TbBiKingnetEventTower



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="层数",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="关卡",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="status",
	name="输赢",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="info",
	name="buff",
	type=1,
	opt=1,
	default_value="",
},
}
