
-- pm.TbXdaysRelicAera



return
{
[1] = 
{
	id=1,
	pre_tid=0,
	name={key='relic_name/1',text="金之谷"},
	desc={key='relic_desc/1',text="金系宠物探险收益翻倍"},
	aera_unlock=
	{
		id=56,
		num=2000,
	},
	solt_unlock=
	{
		id=56,
		num=200,
	},
	solt_num=4,
	type=1,
},
[2] = 
{
	id=2,
	pre_tid=1,
	name={key='relic_name/2',text="火之渊"},
	desc={key='relic_desc/2',text="火系宠物探险收益翻倍"},
	aera_unlock=
	{
		id=56,
		num=2000,
	},
	solt_unlock=
	{
		id=56,
		num=200,
	},
	solt_num=4,
	type=2,
},
[3] = 
{
	id=3,
	pre_tid=2,
	name={key='relic_name/3',text="水之境"},
	desc={key='relic_desc/3',text="水系宠物探险收益翻倍"},
	aera_unlock=
	{
		id=56,
		num=2000,
	},
	solt_unlock=
	{
		id=56,
		num=200,
	},
	solt_num=4,
	type=3,
},
[4] = 
{
	id=4,
	pre_tid=3,
	name={key='relic_name/4',text="土之陵"},
	desc={key='relic_desc/4',text="土系宠物探险收益翻倍"},
	aera_unlock=
	{
		id=56,
		num=2000,
	},
	solt_unlock=
	{
		id=56,
		num=200,
	},
	solt_num=4,
	type=4,
},
}
