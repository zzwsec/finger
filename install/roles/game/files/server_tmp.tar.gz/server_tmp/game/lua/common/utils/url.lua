local string = require("string")

local url = {}

function url.encode(s)
    s = string.gsub(s,"([^%w%.%-])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
    return string.gsub(s, " ", "+")
end

function url.decode(s)
    s = string.gsub(s, '%%(%x%x)', function(h)
        return string.char(tonumber(h, 16))
    end)
    return s
end

return url