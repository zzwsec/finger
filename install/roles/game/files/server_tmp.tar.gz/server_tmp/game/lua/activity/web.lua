local Log = require("common/logging")
local luadb = require("common/luadb/db")

local Convert = import("activity/convert")
local Root = import("config/root", true)

local M = {}

local PublishFileName = "publish.db"
local RevokeFileName  = "revoke.db"

local PublishPath = string.format("%s/%s", Root.Activity.PUBLISH_PATH, PublishFileName)
local RevokePath = string.format( "%s/%s", Root.Activity.PUBLISH_PATH, RevokeFileName)

Globals.OpenTimeList = {}
Globals.OpenTimeReadFlag = false
Globals.OpenRevokeList = {}
Globals.OpenRevokeReadFlag = false

-- 发布
function M.Publish(msg, now)
    for id, value in pairs(msg.activitys or {}) do
        local output = Convert.FormatOutput(value)
        output.time = now
        Globals.OpenTimeList[id] = output
    end
    Log.Debug("Web:Publish", "{}", table.dump(Globals.OpenTimeList))
    if next(msg.activitys) ~= nil then
        M.WriteConfig(PublishPath, Globals.OpenTimeList) 
        M.Merge()
    end
end

-- 撤销
function M.Revoke(msg, now)
    for _, id in ipairs(msg.ids or {}) do 
        Globals.OpenRevokeList[id] = {id = id, time = now}
    end
    if next(msg.ids) ~= nil then
        M.WriteConfig(RevokePath, Globals.OpenRevokeList)  
        M.Merge()
    end
end

-- 读取发布
function M.ReadOpenPublish(path)
    if Globals.OpenTimeReadFlag == false then
        local f = M.Opendb(path)
        for v in f:each() do
            local id = tonumber(v.name)
            Globals.OpenTimeList[id] = f:get(v)
        end
        f:close()
        Globals.OpenTimeReadFlag = true
    end
end

-- 读取撤销
function M.ReadOpenRevoke(path)
    if Globals.OpenRevokeReadFlag == false then 
        local f = M.Opendb(path)
        for v in f:each() do
            local id = tonumber(v.name)
            Globals.OpenRevokeList[id] = f:get(v)
        end
        f:close()
        Globals.OpenRevokeReadFlag = true
    end
end

-- 合并操作
function M.Merge()
    local union_set = {}
    for id, value in pairs(Globals.OpenTimeList or {}) do 
        if Globals.OpenRevokeList[id] ~= nil then
            table.insert(union_set, id)
        end 
    end
    if next(union_set) == nil then return end
    local remove_time_list = {}
    local remove_revoke_list = {}
    for _, id in ipairs(union_set or {}) do 
        local v1 = Globals.OpenTimeList[id]
        local v2 = Globals.OpenRevokeList[id]
        if v1 ~= nil and v2 ~= nil then
            if v1.time > v2.time then 
                table.insert(remove_revoke_list, id)
            else
                table.insert(remove_time_list, id)
            end
        end
    end
    if next(remove_revoke_list) ~= nil then
        for _, id in pairs(remove_revoke_list or {}) do 
            Globals.OpenRevokeList[id] = nil
        end
        M.WriteConfig(RevokePath, Globals.OpenRevokeList)
    end
    if next(remove_time_list) ~= nil then
        for _, id in pairs(remove_time_list or {}) do 
            Globals.OpenTimeList[id] = nil
        end
        M.WriteConfig(PublishPath, Globals.OpenTimeList)
    end
end

function M.Opendb(path)
    local f = luadb.open({
        path = path,
        can_each = true
    })
    return f
end

-- 发布的内容写入文件
function M.WriteConfig(path, content)
    local f = M.Opendb(path)
    for id, value in pairs(content or {}) do
        f:set(id, value)
    end
    f:close()
end

function M.OpenTimeList()
    return Globals.OpenTimeList
end

function  M.OpenRevokeList()
    return Globals.OpenRevokeList
end

-- 初始化
M.ReadOpenPublish(PublishPath)
M.ReadOpenRevoke(RevokePath)

return M