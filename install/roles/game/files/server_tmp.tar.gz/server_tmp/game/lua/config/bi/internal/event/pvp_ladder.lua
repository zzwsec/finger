
-- pm.TbBiInternalEventPvpLadder



return
{
[1] = 
{
	id=1,
	field="report_id",
	name="战报id",
	type=1,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="win",
	name="输赢",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="red_id",
	name="攻方id",
	type=1,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="red_rank",
	name="攻方排名",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="red_change",
	name="攻方变更排名",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="red_power",
	name="攻方战力",
	type=0,
	opt=1,
	default_value="0",
},
[7] = 
{
	id=7,
	field="blue_id",
	name="守方id",
	type=1,
	opt=1,
	default_value="0",
},
[8] = 
{
	id=8,
	field="blue_rank",
	name="守方排名",
	type=0,
	opt=1,
	default_value="0",
},
[9] = 
{
	id=9,
	field="blue_change",
	name="攻方变更排名",
	type=0,
	opt=1,
	default_value="0",
},
[10] = 
{
	id=10,
	field="blue_power",
	name="守方战力",
	type=0,
	opt=1,
	default_value="0",
},
}
