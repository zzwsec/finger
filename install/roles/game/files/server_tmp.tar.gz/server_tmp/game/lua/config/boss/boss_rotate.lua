
-- pm.TbBossRotate



return
{
[1] = 
{
	id=1,
	next=2,
	pet=1601,
	ratio=2.5,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	25,
	},
	attrs=
	{
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.2,
		},
	
		{
			id=123,
			value=0.2,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.2,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[2] = 
{
	id=2,
	next=3,
	pet=1602,
	ratio=2.5,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	25,
	},
	attrs=
	{
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.2,
		},
	
		{
			id=123,
			value=0.2,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.2,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[3] = 
{
	id=3,
	next=4,
	pet=1603,
	ratio=2.5,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	25,
	},
	attrs=
	{
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.2,
		},
	
		{
			id=123,
			value=0.2,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.2,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[4] = 
{
	id=4,
	next=5,
	pet=1604,
	ratio=2.5,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	25,
	},
	attrs=
	{
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.2,
		},
	
		{
			id=123,
			value=0.2,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.2,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[5] = 
{
	id=5,
	next=1,
	pet=1605,
	ratio=2.5,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	25,
	},
	attrs=
	{
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.2,
		},
	
		{
			id=123,
			value=0.2,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.2,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
}
