local class = require "utils.class"
local Constants = require "core.Constants"

local Composite = require 'core.Composite'

local Sequence = class("Sequence", Composite)

function Sequence:ctor()
    Composite.ctor(self)

    self.name = "Sequence"
end

function Sequence:tick(tick)
    for i = 1, #self.children do
        local v = self.children[i]
        local status = v:_execute(tick)
        if status ~= Constants.SUCCESS then
            return status
        end
    end
    return Constants.SUCCESS
end

return Sequence
