local Log = require("common.logging")
local Result = import("common.result")

local ConfigUtility = import("api.utility.config")
local CacheKey = import("api.service.leaderboard.cache_key")
local LeaderboardRemote = import("api.service.leaderboard.remote")
local Utility = import("api.service.leaderboard.utility")
local Record = import("api.service.leaderboard.record")

local ServerOptions = ConfigUtility.ServerOptions
local ProjectId = ServerOptions.ProjectId

local _M = {}

_M.ExistMap = {}

-- 获取排行列表
function _M.ListRecords(coro, message)
    local id = message.id or 0
    local area_id = message.area_id or 1
    local limit = message.limit or 1000
    local offset = message.offset or 0
    local extension = message.extension or ""

    local config = ConfigUtility.LeaderboardConfig(id)
    if not config then
        Log.Warn("ListRecords", "Invalid leaderboard config: id = {}", id)
        return Result.err("BAD_ARGUMENT")
    end

    local leaderboard_id = CacheKey.GenerateKey(id, area_id, config.tag, config.group, extension)
    if not _M.CheckLeaderboard(coro, leaderboard_id, config) then
        Log.Warn("ListRecords", "Leaderboard not found: leaderboard_id = {}, id = {}, area_id = {}",
            leaderboard_id, id, area_id)
        return Result.err("SYSTEM_BUSY")
    end
    local cached_records = g_local_cache:get(leaderboard_id)
    if cached_records then
        Log.Info("ListRecords", "Hit cache: leaderboard_id = {}, capacity = {}", leaderboard_id, g_local_cache:capacity())
        return Result.ok(cached_records)
    end

    Log.Info("ListRecords", "Query leaderboard: id = {}, area_id = {}, limit = {}, offset = {}", 
        id, area_id, limit, offset)
    local list_result = LeaderboardRemote.ListRecords(coro, {
        project_id = ProjectId,
        leaderboard_id = leaderboard_id,
        limit = limit,
        offset = offset,
    })

    if list_result:is_err() then
        Log.Warn("ListRecords", "Failed to list records: {}", list_result:unwrap_err())
        return list_result
    end

    local records = list_result:unwrap()
    if not records then
        Log.Warn("ListRecords", "Records is nil")
        return Result.err("SYSTEM_BUSY")
    end

    local result = {}
    for _, record in ipairs(records) do
        result[#result + 1] = Record.To(record)
    end

    g_local_cache:set(leaderboard_id, result, g_options.cache_ttl)
    
    return Result.ok(result)
end

-- 获取排行记录
function _M.GetRecord(coro, message)
    local id = message.id or 0
    local area_id = message.area_id or 1
    local player_id = message.player_id or 0
    local zone_id = message.zone_id or 0
    local extension = message.extension or ""

    local config = ConfigUtility.LeaderboardConfig(id)
    if not config then
        Log.Warn("GetRecord", "Config not found: id = {}", id)
        return Result.err("BAD_ARGUMENT")
    end

    local leaderboard_id = CacheKey.GenerateKey(id, area_id, config.tag, config.group, extension)
    if not _M.CheckLeaderboard(coro, leaderboard_id, config) then
        Log.Warn("GetRecord", "Leaderboard not found: leaderboard_id = {}", leaderboard_id)
        return Result.err("SYSTEM_BUSY")
    end

    local user_id = Record.EncodeId(player_id, zone_id)
    local record_result = LeaderboardRemote.GetRecord(coro, {
        project_id = ProjectId,
        leaderboard_id = leaderboard_id,
        user_id = user_id,
    })
    if record_result:is_err() then
        Log.Warn("GetRecord", "Failed to get record: {}", record_result:unwrap_err())
        return record_result
    end

    local record = record_result:unwrap()
    if not record then
        Log.Warn("GetRecord", "Record is nil")
        return Result.err("SYSTEM_BUSY")
    end
    return Result.ok(Record.To(record))
end

-- 批量获取排行记录
function _M.GetRecords(coro, message)
    local id = message.id or 0
    local area_id = message.area_id or 1
    local extension = message.extension or ""
    local player_ids = message.player_ids or {}

    local config = ConfigUtility.LeaderboardConfig(id) 
    if not config then
        Log.Warn("GetRecords", "Config not found: id = {}", id)
        return Result.err("BAD_ARGUMENT")
    end

    local leaderboard_id = CacheKey.GenerateKey(id, area_id, config.tag, config.group, extension)
    if not _M.CheckLeaderboard(coro, leaderboard_id, config) then
        Log.Warn("GetRecords", "Leaderboard not found: leaderboard_id = {}", leaderboard_id)
        return Result.err("SYSTEM_BUSY")
    end

    local user_ids = {}
    for player_id, zone_id in pairs(player_ids) do
        user_ids[#user_ids + 1] = Record.EncodeId(player_id, zone_id)
    end

    local get_result = LeaderboardRemote.GetRecords(coro, {
        project_id = ProjectId,
        leaderboard_id = leaderboard_id,
        user_ids = user_ids,
    })
    if get_result:is_err() then
        Log.Warn("GetRecords", "Failed to get records: {}", get_result:unwrap_err())
        return get_result
    end

    local result = {}
    local records = get_result:unwrap() 
    for _, record in ipairs(records or {}) do
        result[#result + 1] = Record.To(record)
    end
    return Result.ok(result)
end

-- 更新排行记录
function _M.WriteRecord(coro, message)
    local id = message.id or 0
    local area_id = message.area_id or 1
    local player_id = message.player_id or 0
    local zone_id = message.zone_id or 0
    local score = message.score or 0
    local time = message.time or os.time()
    local extension = message.extension or ""

    local config = ConfigUtility.LeaderboardConfig(id)
    if not config then
        Log.Warn("WriteRecord", "Config not found: id = {}", id)
        return Result.err("BAD_ARGUMENT")
    end

    local leaderboard_id = CacheKey.GenerateKey(id, area_id, config.tag, config.group, extension)
    if not _M.CheckLeaderboard(coro, leaderboard_id, config) then
        Log.Warn("WriteRecord", "Leaderboard not found: leaderboard_id = {}", leaderboard_id)
        return Result.err("SYSTEM_BUSY")
    end

    local user_id = Record.EncodeId(player_id, zone_id)

    local write_result = LeaderboardRemote.WriteRecord(coro, {
        project_id = ProjectId,
        leaderboard_id = leaderboard_id,
        user_id = user_id,
        score = score,
        time = time,
    })
    if write_result:is_err() then
        Log.Warn("WriteRecord", "Failed to write record: {}", write_result:unwrap_err())
        return write_result
    end

    local record = write_result:unwrap()
    if not record then
        Log.Warn("WriteRecord", "Record is nil")
        return Result.err("SYSTEM_BUSY")
    end

    g_local_cache:delete(leaderboard_id)
    return Result.ok(Record.To(record))
end

-- 删除排行记录
function _M.DeleteRecord(coro, message)
    local id = message.id or 0
    local area_id = message.area_id or 1
    local player_id = message.player_id or 0
    local zone_id = message.zone_id or 0
    local extension = message.extension or ""

    local config = ConfigUtility.LeaderboardConfig(id)
    if not config then
        Log.Warn("DeleteRecord", "Config not found: id = {}", id)
        return Result.err("BAD_ARGUMENT")
    end

    local leaderboard_id = CacheKey.GenerateKey(id, area_id, config.tag, config.group, extension)
    if not _M.CheckLeaderboard(coro, leaderboard_id, config) then
        Log.Warn("DeleteRecord", "Leaderboard not found: leaderboard_id = {}", leaderboard_id)
        return Result.err("SYSTEM_BUSY")
    end

    local user_id = Record.EncodeId(player_id, zone_id)
    local delete_result = LeaderboardRemote.DeleteRecord(coro, {
        project_id = ProjectId,
        leaderboard_id = leaderboard_id,
        user_id = user_id,
    })
    if delete_result:is_err() then
        Log.Warn("DeleteRecord", "Failed to delete record: {}", delete_result:unwrap_err())
        return delete_result
    end

    return Result.ok("OK")
end

-- 检查排行榜是否存在, 不存在则创建
function _M.CheckLeaderboard(coro, leaderboard_id, context)
    if _M.ExistMap[leaderboard_id] then
        return true
    end

    local get_result = LeaderboardRemote.Get(coro, {
        project_id = ProjectId,
        leaderboard_id = leaderboard_id,
    })
    if get_result:is_ok() then
        _M.ExistMap[leaderboard_id] = true
        return true
    end

    local create_result = LeaderboardRemote.Create(coro, {
        project_id = ProjectId,
        leaderboard_id = leaderboard_id,
        sort_type = Utility.GetSortType(context.sort),
        update_type = Utility.GetUpdateType(context.update),
        limit = context.limit,
    })
    if create_result:is_err() then
        Log.Warn("CheckLeaderboard", "Failed to create leaderboard: {}", create_result:unwrap_err())
        return false
    end
    _M.ExistMap[leaderboard_id] = true
    return true
end

return _M
