
-- pm.TbBPCommodity



return
{
[1] = 
{
	id=1,
	type=1,
	round=1,
	payment=80021,
	rebate=2000,
	rewards=
	{
		id=1,
		num=20400,
	},
},
[2] = 
{
	id=2,
	type=1,
	round=2,
	payment=80022,
	rebate=2500,
	rewards=
	{
		id=1,
		num=25200,
	},
},
[3] = 
{
	id=3,
	type=1,
	round=3,
	payment=80023,
	rebate=3000,
	rewards=
	{
		id=1,
		num=30000,
	},
},
[4] = 
{
	id=4,
	type=2,
	round=1,
	payment=80031,
	rebate=2000,
	rewards=
	{
		id=1,
		num=20000,
	},
},
[5] = 
{
	id=5,
	type=2,
	round=2,
	payment=80032,
	rebate=3000,
	rewards=
	{
		id=1,
		num=30000,
	},
},
[6] = 
{
	id=6,
	type=2,
	round=3,
	payment=80033,
	rebate=1700,
	rewards=
	{
		id=1,
		num=17000,
	},
},
[7] = 
{
	id=7,
	type=3,
	round=1,
	payment=80041,
	rebate=1200,
	rewards=
	{
		id=1,
		num=24000,
	},
},
[8] = 
{
	id=8,
	type=3,
	round=2,
	payment=80042,
	rebate=1600,
	rewards=
	{
		id=1,
		num=33000,
	},
},
[9] = 
{
	id=9,
	type=3,
	round=3,
	payment=80043,
	rebate=2200,
	rewards=
	{
		id=1,
		num=44000,
	},
},
[10] = 
{
	id=10,
	type=4,
	round=23,
	payment=80013,
	rebate=3300,
	rewards=
	{
		id=1,
		num=45000,
	},
},
[11] = 
{
	id=11,
	type=5,
	round=1,
	payment=80051,
	rebate=2000,
	rewards=
	{
		id=1,
		num=135000,
	},
},
[12] = 
{
	id=12,
	type=5,
	round=2,
	payment=80052,
	rebate=2400,
	rewards=
	{
		id=1,
		num=156000,
	},
},
[13] = 
{
	id=13,
	type=6,
	round=1,
	payment=80061,
	rebate=2000,
	rewards=
	{
		id=1,
		num=20000,
	},
},
[14] = 
{
	id=14,
	type=6,
	round=2,
	payment=80062,
	rebate=4000,
	rewards=
	{
		id=1,
		num=40000,
	},
},
[15] = 
{
	id=15,
	type=7,
	round=1,
	payment=80071,
	rebate=1000,
	rewards=
	{
		id=1,
		num=20000,
	},
},
[16] = 
{
	id=16,
	type=7,
	round=2,
	payment=80072,
	rebate=2000,
	rewards=
	{
		id=1,
		num=40000,
	},
},
}
