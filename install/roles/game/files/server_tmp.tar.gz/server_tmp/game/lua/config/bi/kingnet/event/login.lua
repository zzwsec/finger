
-- pm.TbBiKingnetEventLogin



return
{
[1] = 
{
	id=1,
	field="type",
	name="",
	type=1,
	opt=1,
	default_value="",
},
}
