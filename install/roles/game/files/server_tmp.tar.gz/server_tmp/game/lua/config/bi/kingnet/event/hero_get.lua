
-- pm.TbBiKingnetEventHeroGet



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="佣兵id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="佣兵等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="num1",
	name="佣兵星级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="num2",
	name="佣兵品阶",
	type=0,
	opt=1,
	default_value="",
},
}
