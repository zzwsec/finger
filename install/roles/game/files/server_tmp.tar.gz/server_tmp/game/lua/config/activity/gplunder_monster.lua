
-- pm.TbInvadeMonster



return
{
[1] = 
{
	id=1,
	level=1,
	name={key='gplunder_monster/1',text="盗贼"},
	rewards=
	{
	
		{
			id=171,
			num=1,
		},
	
		{
			id=1,
			num=10,
		},
	},
	score_reward=
	{
		id=70,
		num=1000,
	},
	npc=1099,
	fight=365000,
	npc_attrs=
	{
	
		{
			id=100,
			value=1535,
		},
	
		{
			id=101,
			value=184640,
		},
	
		{
			id=102,
			value=16376,
		},
	
		{
			id=103,
			value=5591,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0,
		},
	
		{
			id=143,
			value=0,
		},
	
		{
			id=144,
			value=0,
		},
	
		{
			id=145,
			value=0,
		},
	
		{
			id=146,
			value=0,
		},
	},
},
[2] = 
{
	id=2,
	level=2,
	name={key='gplunder_monster/2',text="盗贼"},
	rewards=
	{
	
		{
			id=172,
			num=1,
		},
	
		{
			id=1,
			num=10,
		},
	},
	score_reward=
	{
		id=70,
		num=2000,
	},
	npc=1099,
	fight=650000,
	npc_attrs=
	{
	
		{
			id=100,
			value=2287,
		},
	
		{
			id=101,
			value=300512,
		},
	
		{
			id=102,
			value=25289,
		},
	
		{
			id=103,
			value=8779,
		},
	
		{
			id=121,
			value=0.048,
		},
	
		{
			id=122,
			value=0.048,
		},
	
		{
			id=123,
			value=0.048,
		},
	
		{
			id=124,
			value=0.048,
		},
	
		{
			id=125,
			value=0.048,
		},
	
		{
			id=126,
			value=0.048,
		},
	
		{
			id=141,
			value=0.024,
		},
	
		{
			id=142,
			value=0.024,
		},
	
		{
			id=143,
			value=0.024,
		},
	
		{
			id=144,
			value=0.024,
		},
	
		{
			id=145,
			value=0.024,
		},
	
		{
			id=146,
			value=0.024,
		},
	},
},
[3] = 
{
	id=3,
	level=3,
	name={key='gplunder_monster/3',text="盗贼"},
	rewards=
	{
	
		{
			id=173,
			num=1,
		},
	
		{
			id=1,
			num=20,
		},
	},
	score_reward=
	{
		id=70,
		num=3000,
	},
	npc=1099,
	fight=1030000,
	npc_attrs=
	{
	
		{
			id=100,
			value=3194,
		},
	
		{
			id=101,
			value=468762,
		},
	
		{
			id=102,
			value=35507,
		},
	
		{
			id=103,
			value=12562,
		},
	
		{
			id=121,
			value=0.06,
		},
	
		{
			id=122,
			value=0.06,
		},
	
		{
			id=123,
			value=0.06,
		},
	
		{
			id=124,
			value=0.06,
		},
	
		{
			id=125,
			value=0.06,
		},
	
		{
			id=126,
			value=0.06,
		},
	
		{
			id=141,
			value=0.024,
		},
	
		{
			id=142,
			value=0.024,
		},
	
		{
			id=143,
			value=0.024,
		},
	
		{
			id=144,
			value=0.024,
		},
	
		{
			id=145,
			value=0.024,
		},
	
		{
			id=146,
			value=0.024,
		},
	},
},
[4] = 
{
	id=4,
	level=4,
	name={key='gplunder_monster/4',text="盗贼"},
	rewards=
	{
	
		{
			id=174,
			num=1,
		},
	
		{
			id=1,
			num=20,
		},
	},
	score_reward=
	{
		id=70,
		num=4500,
	},
	npc=1099,
	fight=1610000,
	npc_attrs=
	{
	
		{
			id=100,
			value=4145,
		},
	
		{
			id=101,
			value=699555,
		},
	
		{
			id=102,
			value=46791,
		},
	
		{
			id=103,
			value=16776,
		},
	
		{
			id=121,
			value=0.06,
		},
	
		{
			id=122,
			value=0.06,
		},
	
		{
			id=123,
			value=0.06,
		},
	
		{
			id=124,
			value=0.06,
		},
	
		{
			id=125,
			value=0.06,
		},
	
		{
			id=126,
			value=0.06,
		},
	
		{
			id=141,
			value=0.0456,
		},
	
		{
			id=142,
			value=0.0456,
		},
	
		{
			id=143,
			value=0.0456,
		},
	
		{
			id=144,
			value=0.0456,
		},
	
		{
			id=145,
			value=0.0456,
		},
	
		{
			id=146,
			value=0.0456,
		},
	},
},
[5] = 
{
	id=5,
	level=5,
	name={key='gplunder_monster/5',text="盗贼"},
	rewards=
	{
	
		{
			id=175,
			num=1,
		},
	
		{
			id=1,
			num=30,
		},
	},
	score_reward=
	{
		id=70,
		num=8000,
	},
	npc=1099,
	fight=3380000,
	npc_attrs=
	{
	
		{
			id=100,
			value=5800,
		},
	
		{
			id=101,
			value=1113940,
		},
	
		{
			id=102,
			value=67519,
		},
	
		{
			id=103,
			value=24444,
		},
	
		{
			id=121,
			value=0.108,
		},
	
		{
			id=122,
			value=0.108,
		},
	
		{
			id=123,
			value=0.108,
		},
	
		{
			id=124,
			value=0.108,
		},
	
		{
			id=125,
			value=0.108,
		},
	
		{
			id=126,
			value=0.108,
		},
	
		{
			id=141,
			value=0.0936,
		},
	
		{
			id=142,
			value=0.0936,
		},
	
		{
			id=143,
			value=0.0936,
		},
	
		{
			id=144,
			value=0.0936,
		},
	
		{
			id=145,
			value=0.0936,
		},
	
		{
			id=146,
			value=0.0936,
		},
	},
},
[6] = 
{
	id=6,
	level=6,
	name={key='gplunder_monster/6',text="盗贼"},
	rewards=
	{
	
		{
			id=176,
			num=1,
		},
	
		{
			id=1,
			num=30,
		},
	},
	score_reward=
	{
		id=70,
		num=10000,
	},
	npc=1099,
	fight=4620000,
	npc_attrs=
	{
	
		{
			id=100,
			value=6630,
		},
	
		{
			id=101,
			value=1468372,
		},
	
		{
			id=102,
			value=83476,
		},
	
		{
			id=103,
			value=30155,
		},
	
		{
			id=121,
			value=0.108,
		},
	
		{
			id=122,
			value=0.108,
		},
	
		{
			id=123,
			value=0.108,
		},
	
		{
			id=124,
			value=0.108,
		},
	
		{
			id=125,
			value=0.108,
		},
	
		{
			id=126,
			value=0.108,
		},
	
		{
			id=141,
			value=0.1152,
		},
	
		{
			id=142,
			value=0.1152,
		},
	
		{
			id=143,
			value=0.1152,
		},
	
		{
			id=144,
			value=0.1152,
		},
	
		{
			id=145,
			value=0.1152,
		},
	
		{
			id=146,
			value=0.1152,
		},
	},
},
[7] = 
{
	id=7,
	level=7,
	name={key='gplunder_monster/7',text="盗贼"},
	rewards=
	{
	
		{
			id=177,
			num=1,
		},
	
		{
			id=1,
			num=40,
		},
	},
	score_reward=
	{
		id=70,
		num=15000,
	},
	npc=1099,
	fight=6360000,
	npc_attrs=
	{
	
		{
			id=100,
			value=8080,
		},
	
		{
			id=101,
			value=2064052,
		},
	
		{
			id=102,
			value=108233,
		},
	
		{
			id=103,
			value=39048,
		},
	
		{
			id=121,
			value=0.108,
		},
	
		{
			id=122,
			value=0.108,
		},
	
		{
			id=123,
			value=0.108,
		},
	
		{
			id=124,
			value=0.108,
		},
	
		{
			id=125,
			value=0.108,
		},
	
		{
			id=126,
			value=0.108,
		},
	
		{
			id=141,
			value=0.1152,
		},
	
		{
			id=142,
			value=0.1152,
		},
	
		{
			id=143,
			value=0.1152,
		},
	
		{
			id=144,
			value=0.1152,
		},
	
		{
			id=145,
			value=0.1152,
		},
	
		{
			id=146,
			value=0.1152,
		},
	},
},
[8] = 
{
	id=8,
	level=8,
	name={key='gplunder_monster/8',text="盗贼"},
	rewards=
	{
	
		{
			id=178,
			num=1,
		},
	
		{
			id=1,
			num=50,
		},
	},
	score_reward=
	{
		id=70,
		num=20000,
	},
	npc=1099,
	fight=9330000,
	npc_attrs=
	{
	
		{
			id=100,
			value=9529,
		},
	
		{
			id=101,
			value=2668485,
		},
	
		{
			id=102,
			value=130786,
		},
	
		{
			id=103,
			value=47400,
		},
	
		{
			id=121,
			value=0.132,
		},
	
		{
			id=122,
			value=0.132,
		},
	
		{
			id=123,
			value=0.132,
		},
	
		{
			id=124,
			value=0.132,
		},
	
		{
			id=125,
			value=0.132,
		},
	
		{
			id=126,
			value=0.132,
		},
	
		{
			id=141,
			value=0.1512,
		},
	
		{
			id=142,
			value=0.1512,
		},
	
		{
			id=143,
			value=0.1512,
		},
	
		{
			id=144,
			value=0.1512,
		},
	
		{
			id=145,
			value=0.1512,
		},
	
		{
			id=146,
			value=0.1512,
		},
	},
},
}
