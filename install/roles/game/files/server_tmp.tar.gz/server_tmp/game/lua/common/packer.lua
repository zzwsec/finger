local Packer = {}

local map_state = 0
local map_key_state = 1
local array_state = 2

function Packer.new(...)
    local o = {}
    setmetatable(o, Packer)
    Packer.__index = Packer
    o:ctor(...)
    return o
end

function Packer:ctor()

end

function Packer:value()
    return self[#self]
end

function Packer:reset()
    local top = #self
    local value = self[top]
    while top > 0 do
        self[top] = nil
        top = top - 1
    end
    return value
end

function Packer:pack_map_begin()
    local top = #self
    self[top + 1] = {}
    self[top + 2] = map_state
    return self
end

function Packer:pack_map_end()
    local top = #self
    if top > 2 then
        local state = self[top - 2]
        if state == map_key_state then
            self[top - 4][self[top - 3]] = self[top - 1]
            self[top - 3] = map_state
            self[top - 2] = nil
        elseif state == array_state then
            local array = self[#self - 3]
            array[#array + 1] = self[top - 1]
        else
            assert(false, "state: " .. state)
        end
        self[top - 1] = nil
    end
    self[top] = nil
    return self
end

function Packer:pack_map_end_compress()
    local top = #self
    local value = self[top - 1]
    if next(value) == nill and not getmetatable(value) then
        value = nil
    end
    if top > 2 then
        local state = self[top - 2]
        if state == map_key_state then
            self[top - 4][self[top - 3]] = value
            self[top - 3] = map_state
            self[top - 2] = nil
        elseif state == array_state then
            local array = self[#self - 3]
            array[#array + 1] = value
        else
            assert(false, "state: " .. state)
        end
        self[top - 1] = nil
    elseif value == nil then
        self[top - 1] = nil
    end
    self[top] = nil
    return self
end

function Packer:pack_array_begin()
    local top = #self
    self[top + 1] = {}
    self[top + 2] = array_state
    return self
end

function Packer:pack_array_end()
    self:pack_map_end()
    return self
end

function Packer:pack_array_end_compress()
    self:pack_map_end_compress()
    return self
end

function Packer:pack_reset(t)
    setmetatable(self[#self - 1], t)
    return self
end

function Packer:pack_key(key)
    local top = #self
    self[top] = key
    self[top + 1] = map_key_state
    return self
end

function Packer:pack_kv(key, value)
    self[#self - 1][key] = value
    return self
end

function Packer:pack_item(value)
    table.insert(self[#self - 1], value)
    return self
end

return Packer