
-- pm.TbActivityLogin



return
{
[1] = 
{
	id=1,
	index=1,
	type=1,
	days=1,
	rewards=
	{
	
		{
			id=3,
			num=20,
		},
	
		{
			id=3,
			num=20,
		},
	},
	icon=
	{
		id=6012,
		num=0,
	},
	name={key='login_name/1_1',text="明日领取"},
	during=0,
},
[2] = 
{
	id=2,
	index=1,
	type=1,
	days=2,
	rewards=
	{
	
		{
			id=6012,
			num=1,
		},
	
		{
			id=3,
			num=100,
		},
	},
	icon=
	{
		id=39,
		num=10,
	},
	name={key='login_name/1_2',text="明日领取"},
	during=0,
},
[3] = 
{
	id=3,
	index=1,
	type=1,
	days=3,
	rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=3,
			num=100,
		},
	},
	icon=
	{
		id=6012,
		num=0,
	},
	name={key='login_name/1_3',text="七日领取"},
	during=259200,
},
[4] = 
{
	id=4,
	index=1,
	type=1,
	days=4,
	rewards=
	{
	
		{
			id=107,
			num=1,
		},
	
		{
			id=3,
			num=100,
		},
	},
	icon=
	{
		id=6012,
		num=0,
	},
	name={key='login_name/1_4',text="七日领取"},
	during=172800,
},
[5] = 
{
	id=5,
	index=1,
	type=1,
	days=5,
	rewards=
	{
	
		{
			id=44,
			num=12,
		},
	
		{
			id=3,
			num=100,
		},
	},
	icon=
	{
		id=6012,
		num=0,
	},
	name={key='login_name/1_5',text="七日领取"},
	during=86400,
},
[6] = 
{
	id=6,
	index=1,
	type=1,
	days=6,
	rewards=
	{
	
		{
			id=1,
			num=666,
		},
	
		{
			id=3,
			num=100,
		},
	},
	icon=
	{
		id=6012,
		num=0,
	},
	name={key='login_name/1_6',text="七日领取"},
	during=0,
},
[7] = 
{
	id=7,
	index=1,
	type=1,
	days=7,
	rewards=
	{
	
		{
			id=6012,
			num=1,
		},
	
		{
			id=14,
			num=100,
		},
	
		{
			id=33,
			num=100,
		},
	
		{
			id=3,
			num=100,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[8] = 
{
	id=8,
	index=2,
	type=2,
	days=1,
	rewards=
	{
	
		{
			id=2,
			num=10000,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[9] = 
{
	id=9,
	index=2,
	type=2,
	days=2,
	rewards=
	{
	
		{
			id=10004,
			num=50,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[10] = 
{
	id=10,
	index=2,
	type=2,
	days=3,
	rewards=
	{
	
		{
			id=12003,
			num=1,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[11] = 
{
	id=11,
	index=2,
	type=2,
	days=4,
	rewards=
	{
	
		{
			id=5,
			num=10000,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[12] = 
{
	id=12,
	index=2,
	type=2,
	days=5,
	rewards=
	{
	
		{
			id=20004,
			num=10,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[13] = 
{
	id=13,
	index=2,
	type=2,
	days=6,
	rewards=
	{
	
		{
			id=6,
			num=1000,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[14] = 
{
	id=14,
	index=2,
	type=2,
	days=7,
	rewards=
	{
	
		{
			id=1,
			num=500,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[15] = 
{
	id=15,
	index=3,
	type=1,
	days=1,
	rewards=
	{
	
		{
			id=10001,
			num=3,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[16] = 
{
	id=16,
	index=3,
	type=1,
	days=2,
	rewards=
	{
	
		{
			id=10001,
			num=10,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[17] = 
{
	id=17,
	index=3,
	type=1,
	days=3,
	rewards=
	{
	
		{
			id=1,
			num=200,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[18] = 
{
	id=18,
	index=3,
	type=1,
	days=4,
	rewards=
	{
	
		{
			id=20141,
			num=2,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[19] = 
{
	id=19,
	index=3,
	type=1,
	days=5,
	rewards=
	{
	
		{
			id=1,
			num=300,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[20] = 
{
	id=20,
	index=3,
	type=1,
	days=6,
	rewards=
	{
	
		{
			id=20151,
			num=1,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
[21] = 
{
	id=21,
	index=3,
	type=1,
	days=7,
	rewards=
	{
	
		{
			id=10002,
			num=10,
		},
	},
	icon=
	{
		id=0,
		num=0,
	},
	name={key='',text=""},
	during=0,
},
}
