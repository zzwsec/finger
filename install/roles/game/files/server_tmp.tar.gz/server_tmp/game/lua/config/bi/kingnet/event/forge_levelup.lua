
-- pm.TbBiKingnetEventForgeLevelup



return
{
[1] = 
{
	id=1,
	field="num",
	name="老等级",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num1",
	name="新等级",
	type=0,
	opt=1,
	default_value="",
},
}
