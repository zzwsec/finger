
-- pm.TbBiInternalEventGpvpFight



return
{
[1] = 
{
	id=1,
	field="report_id",
	name="战报id",
	type=1,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="win",
	name="输赢",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="blue_id",
	name="守方id",
	type=1,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="blue_power",
	name="守方战力",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="old_level",
	name="老段位",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="level",
	name="当前段位",
	type=0,
	opt=1,
	default_value="0",
},
[7] = 
{
	id=7,
	field="rasie_times",
	name="当前段位累计胜场",
	type=0,
	opt=1,
	default_value="0",
},
[8] = 
{
	id=8,
	field="streak_drop_times",
	name="连败次数",
	type=0,
	opt=1,
	default_value="0",
},
[9] = 
{
	id=9,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
}
