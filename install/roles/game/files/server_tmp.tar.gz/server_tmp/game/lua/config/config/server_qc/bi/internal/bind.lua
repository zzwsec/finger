
-- pm.TbBiInternalBind



return
{
[100] = 
{
	id=100,
	name="register",
	event="register",
	depend=true,
},
[101] = 
{
	id=101,
	name="login",
	event="login",
	depend=true,
},
[102] = 
{
	id=102,
	name="recharge",
	event="recharge",
	depend=true,
},
[103] = 
{
	id=103,
	name="goods_detail",
	event="goods_detail",
	depend=true,
},
[104] = 
{
	id=104,
	name="goods_get",
	event="goods_get",
	depend=true,
},
[105] = 
{
	id=105,
	name="goods_use",
	event="goods_use",
	depend=true,
},
[106] = 
{
	id=106,
	name="zone_loads",
	event="zone_loads",
	depend=false,
},
[107] = 
{
	id=107,
	name="ad",
	event="ad",
	depend=true,
},
[108] = 
{
	id=108,
	name="chat",
	event="chat",
	depend=true,
},
[109] = 
{
	id=109,
	name="level_up",
	event="level_up",
	depend=true,
},
[110] = 
{
	id=110,
	name="mail_add",
	event="mail_add",
	depend=true,
},
[111] = 
{
	id=111,
	name="mail_del",
	event="mail_del",
	depend=true,
},
[112] = 
{
	id=112,
	name="mining",
	event="mining",
	depend=true,
},
[113] = 
{
	id=113,
	name="mining_skill",
	event="mining_skill",
	depend=true,
},
[114] = 
{
	id=114,
	name="mining_event",
	event="mining_event",
	depend=true,
},
[115] = 
{
	id=115,
	name="event_unexpected",
	event="event_unexpected",
	depend=true,
},
[116] = 
{
	id=116,
	name="event_treasure",
	event="event_treasure",
	depend=true,
},
[117] = 
{
	id=117,
	name="event_stone_identify",
	event="event_stone_identify",
	depend=true,
},
[118] = 
{
	id=118,
	name="event_stone_sale",
	event="event_stone_sale",
	depend=true,
},
[119] = 
{
	id=119,
	name="task",
	event="task",
	depend=true,
},
[120] = 
{
	id=120,
	name="guide",
	event="guide",
	depend=true,
},
[121] = 
{
	id=121,
	name="build_levelup_star",
	event="build_levelup_star",
	depend=true,
},
[122] = 
{
	id=122,
	name="build_levelup_end",
	event="build_levelup_end",
	depend=true,
},
[123] = 
{
	id=123,
	name="build_levelup_accelerate",
	event="build_levelup_accelerate",
	depend=true,
},
[124] = 
{
	id=124,
	name="tech_tree",
	event="tech_tree",
	depend=true,
},
[125] = 
{
	id=125,
	name="trade",
	event="trade",
	depend=true,
},
[126] = 
{
	id=126,
	name="trade_talk",
	event="trade_talk",
	depend=true,
},
[127] = 
{
	id=127,
	name="mainline",
	event="mainline",
	depend=true,
},
[128] = 
{
	id=128,
	name="pvp",
	event="pvp",
	depend=false,
},
[129] = 
{
	id=129,
	name="trial",
	event="trial",
	depend=true,
},
[130] = 
{
	id=130,
	name="trial_sweep",
	event="trial_sweep",
	depend=true,
},
[131] = 
{
	id=131,
	name="boss",
	event="boss",
	depend=true,
},
[132] = 
{
	id=132,
	name="cave",
	event="cave",
	depend=true,
},
[133] = 
{
	id=133,
	name="shop",
	event="shop",
	depend=true,
},
[134] = 
{
	id=134,
	name="equip",
	event="equip",
	depend=true,
},
[135] = 
{
	id=135,
	name="mount_level_exp",
	event="mount_level_exp",
	depend=true,
},
[136] = 
{
	id=136,
	name="mount_level_up",
	event="mount_level_up",
	depend=true,
},
[137] = 
{
	id=137,
	name="mount_stage",
	event="mount_stage",
	depend=true,
},
[138] = 
{
	id=138,
	name="pet_get",
	event="pet_get",
	depend=true,
},
[139] = 
{
	id=139,
	name="pet_levelup",
	event="pet_levelup",
	depend=true,
},
[140] = 
{
	id=140,
	name="pet_devour",
	event="pet_devour",
	depend=true,
},
[141] = 
{
	id=141,
	name="pet_reset",
	event="pet_reset",
	depend=true,
},
[142] = 
{
	id=142,
	name="pet_release",
	event="pet_release",
	depend=true,
},
[143] = 
{
	id=143,
	name="pet_bag",
	event="pet_bag",
	depend=true,
},
[144] = 
{
	id=144,
	name="event_missile",
	event="event_missile",
	depend=true,
},
[145] = 
{
	id=145,
	name="event_turntable",
	event="event_turntable",
	depend=true,
},
[146] = 
{
	id=146,
	name="build_queue",
	event="build_queue",
	depend=true,
},
[147] = 
{
	id=147,
	name="build_reinforce",
	event="build_reinforce",
	depend=true,
},
[148] = 
{
	id=148,
	name="build_recruit",
	event="build_recruit",
	depend=true,
},
[149] = 
{
	id=149,
	name="forge_levelup",
	event="forge_levelup",
	depend=true,
},
[150] = 
{
	id=150,
	name="mount_change",
	event="mount_change",
	depend=true,
},
[151] = 
{
	id=151,
	name="pet_change",
	event="pet_change",
	depend=true,
},
[152] = 
{
	id=152,
	name="hero_change",
	event="hero_change",
	depend=true,
},
[153] = 
{
	id=153,
	name="hero_get",
	event="hero_get",
	depend=true,
},
[154] = 
{
	id=154,
	name="hero_lottery",
	event="hero_lottery",
	depend=true,
},
[155] = 
{
	id=155,
	name="hero_levelup",
	event="hero_levelup",
	depend=true,
},
[156] = 
{
	id=156,
	name="hero_stage",
	event="hero_stage",
	depend=true,
},
[157] = 
{
	id=157,
	name="hero_star",
	event="hero_star",
	depend=true,
},
[158] = 
{
	id=158,
	name="hero_reset",
	event="hero_reset",
	depend=true,
},
[159] = 
{
	id=159,
	name="hero_bag",
	event="hero_bag",
	depend=true,
},
[160] = 
{
	id=160,
	name="hero_dispatch",
	event="hero_dispatch",
	depend=true,
},
[161] = 
{
	id=161,
	name="guild_creat",
	event="guild_creat",
	depend=true,
},
[162] = 
{
	id=162,
	name="guild_join",
	event="guild_join",
	depend=true,
},
[163] = 
{
	id=163,
	name="guild_exit",
	event="guild_exit",
	depend=true,
},
[164] = 
{
	id=164,
	name="guild_disband",
	event="guild_disband",
	depend=true,
},
[165] = 
{
	id=165,
	name="guild_levelup",
	event="guild_levelup",
	depend=false,
},
[166] = 
{
	id=166,
	name="tower",
	event="tower",
	depend=true,
},
[167] = 
{
	id=167,
	name="tower_sweep",
	event="tower_sweep",
	depend=true,
},
[168] = 
{
	id=168,
	name="equip_refine",
	event="equip_refine",
	depend=true,
},
[169] = 
{
	id=169,
	name="equip_stage",
	event="equip_stage",
	depend=true,
},
[170] = 
{
	id=170,
	name="guild_approve",
	event="guild_approve",
	depend=true,
},
[171] = 
{
	id=171,
	name="guild_dismiss",
	event="guild_dismiss",
	depend=true,
},
[172] = 
{
	id=172,
	name="guild_job_change",
	event="guild_job_change",
	depend=true,
},
[173] = 
{
	id=173,
	name="event_shop",
	event="event_shop",
	depend=true,
},
[174] = 
{
	id=174,
	name="guild_contribute",
	event="guild_contribute",
	depend=true,
},
[175] = 
{
	id=175,
	name="activity_login",
	event="activity_login",
	depend=true,
},
[176] = 
{
	id=176,
	name="activity_xdays_reward",
	event="activity_xdays_reward",
	depend=true,
},
[177] = 
{
	id=177,
	name="activity_xdays_commodity",
	event="activity_xdays_commodity",
	depend=true,
},
[178] = 
{
	id=178,
	name="activity_ranks",
	event="activity_ranks",
	depend=false,
},
[179] = 
{
	id=179,
	name="ranks",
	event="ranks",
	depend=false,
},
[180] = 
{
	id=180,
	name="event_monster",
	event="event_monster",
	depend=true,
},
[181] = 
{
	id=181,
	name="competition_start",
	event="competition_start",
	depend=true,
},
[182] = 
{
	id=182,
	name="competition_end",
	event="competition_end",
	depend=true,
},
[183] = 
{
	id=183,
	name="relic_unlock_area",
	event="relic_unlock_area",
	depend=true,
},
[184] = 
{
	id=184,
	name="relic_slot_pet",
	event="relic_slot_pet",
	depend=true,
},
[185] = 
{
	id=185,
	name="dispatch_task_refresh",
	event="dispatch_task_refresh",
	depend=true,
},
[186] = 
{
	id=186,
	name="dispatch_task_start",
	event="dispatch_task_start",
	depend=true,
},
[187] = 
{
	id=187,
	name="dispatch_task_end",
	event="dispatch_task_end",
	depend=true,
},
[188] = 
{
	id=188,
	name="dispatch_task_accelerate",
	event="dispatch_task_accelerate",
	depend=true,
},
[189] = 
{
	id=189,
	name="guild_help",
	event="guild_help",
	depend=true,
},
[190] = 
{
	id=190,
	name="partner_get",
	event="partner_get",
	depend=true,
},
[191] = 
{
	id=191,
	name="partner_levelup",
	event="partner_levelup",
	depend=true,
},
[192] = 
{
	id=192,
	name="partner_change",
	event="partner_change",
	depend=true,
},
[193] = 
{
	id=193,
	name="guild_competition_match",
	event="guild_competition_match",
	depend=false,
},
[194] = 
{
	id=194,
	name="guild_competition_end_guild",
	event="guild_competition_end_guild",
	depend=false,
},
[195] = 
{
	id=195,
	name="guild_competition_end_player",
	event="guild_competition_end_player",
	depend=false,
},
[196] = 
{
	id=196,
	name="pvp_ladder",
	event="pvp_ladder",
	depend=true,
},
[197] = 
{
	id=197,
	name="gpvp_fight",
	event="gpvp_fight",
	depend=true,
},
[198] = 
{
	id=198,
	name="gpvp_end_player",
	event="gpvp_end_player",
	depend=false,
},
[199] = 
{
	id=199,
	name="gpvp_end_guild",
	event="gpvp_end_guild",
	depend=false,
},
[200] = 
{
	id=200,
	name="business_round",
	event="business_round",
	depend=true,
},
[201] = 
{
	id=201,
	name="business_bag",
	event="business_bag",
	depend=true,
},
[202] = 
{
	id=202,
	name="business_trade",
	event="business_trade",
	depend=true,
},
[203] = 
{
	id=203,
	name="business_end",
	event="business_end",
	depend=true,
},
[204] = 
{
	id=204,
	name="gplunder_refresh",
	event="gplunder_refresh",
	depend=true,
},
[205] = 
{
	id=205,
	name="gplunder_fight",
	event="gplunder_fight",
	depend=true,
},
[206] = 
{
	id=206,
	name="guild_ranks",
	event="guild_ranks",
	depend=false,
},
}
