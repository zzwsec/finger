
-- pm.TbBiInternalEventRecharge



return
{
[1] = 
{
	id=1,
	field="account_id",
	name="账号id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="cdkey",
	name="cdkey",
	type=1,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="device",
	name="设备",
	type=1,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="device_id",
	name="设备编号",
	type=1,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="order_no",
	name="cp订单号",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="order_id",
	name="渠道订单",
	type=1,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="item_id",
	name="道具id",
	type=0,
	opt=1,
	default_value="",
},
[8] = 
{
	id=8,
	field="item_amount",
	name="道具数量",
	type=0,
	opt=1,
	default_value="",
},
[9] = 
{
	id=9,
	field="channel",
	name="渠道",
	type=0,
	opt=1,
	default_value="",
},
[10] = 
{
	id=10,
	field="sku",
	name="商品号",
	type=1,
	opt=1,
	default_value="",
},
[11] = 
{
	id=11,
	field="money",
	name="价格",
	type=0,
	opt=1,
	default_value="",
},
[12] = 
{
	id=12,
	field="pay_status",
	name="首充",
	type=0,
	opt=1,
	default_value="",
},
}
