
-- pm.TbBossReward



return
{
[1] = 
{
	id=1,
	damage=100,
	total_damage=100,
	rewards=
	{
	
		{
			id=14,
			num=3,
			pr=1,
		},
	
		{
			id=15,
			num=100,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=100,
			pr=0.2,
		},
	
		{
			id=25,
			num=10,
			pr=0.8,
		},
	},
},
[2] = 
{
	id=2,
	damage=2000,
	total_damage=2100,
	rewards=
	{
	
		{
			id=14,
			num=3,
			pr=1,
		},
	
		{
			id=15,
			num=150,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=150,
			pr=0.2,
		},
	
		{
			id=25,
			num=10,
			pr=0.8,
		},
	},
},
[3] = 
{
	id=3,
	damage=5000,
	total_damage=7100,
	rewards=
	{
	
		{
			id=14,
			num=4,
			pr=1,
		},
	
		{
			id=15,
			num=200,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=200,
			pr=0.2,
		},
	
		{
			id=25,
			num=10,
			pr=0.8,
		},
	},
},
[4] = 
{
	id=4,
	damage=10000,
	total_damage=17100,
	rewards=
	{
	
		{
			id=14,
			num=4,
			pr=1,
		},
	
		{
			id=15,
			num=250,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=250,
			pr=0.2,
		},
	
		{
			id=25,
			num=10,
			pr=0.8,
		},
	},
},
[5] = 
{
	id=5,
	damage=20000,
	total_damage=37100,
	rewards=
	{
	
		{
			id=14,
			num=5,
			pr=1,
		},
	
		{
			id=15,
			num=300,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=300,
			pr=0.2,
		},
	
		{
			id=25,
			num=10,
			pr=0.8,
		},
	},
},
[6] = 
{
	id=6,
	damage=30000,
	total_damage=67100,
	rewards=
	{
	
		{
			id=14,
			num=5,
			pr=1,
		},
	
		{
			id=15,
			num=350,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=350,
			pr=0.2,
		},
	
		{
			id=25,
			num=10,
			pr=0.8,
		},
	},
},
[7] = 
{
	id=7,
	damage=50000,
	total_damage=117100,
	rewards=
	{
	
		{
			id=14,
			num=6,
			pr=1,
		},
	
		{
			id=15,
			num=400,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=400,
			pr=0.2,
		},
	
		{
			id=25,
			num=15,
			pr=0.8,
		},
	},
},
[8] = 
{
	id=8,
	damage=70000,
	total_damage=187100,
	rewards=
	{
	
		{
			id=14,
			num=6,
			pr=1,
		},
	
		{
			id=15,
			num=450,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=450,
			pr=0.2,
		},
	
		{
			id=25,
			num=15,
			pr=0.8,
		},
	},
},
[9] = 
{
	id=9,
	damage=90000,
	total_damage=277100,
	rewards=
	{
	
		{
			id=14,
			num=6,
			pr=1,
		},
	
		{
			id=15,
			num=500,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=500,
			pr=0.2,
		},
	
		{
			id=25,
			num=15,
			pr=0.8,
		},
	},
},
[10] = 
{
	id=10,
	damage=120000,
	total_damage=397100,
	rewards=
	{
	
		{
			id=14,
			num=7,
			pr=1,
		},
	
		{
			id=15,
			num=550,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=550,
			pr=0.2,
		},
	
		{
			id=25,
			num=15,
			pr=0.8,
		},
	},
},
[11] = 
{
	id=11,
	damage=150000,
	total_damage=547100,
	rewards=
	{
	
		{
			id=14,
			num=7,
			pr=1,
		},
	
		{
			id=15,
			num=600,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=600,
			pr=0.2,
		},
	
		{
			id=25,
			num=15,
			pr=0.8,
		},
	},
},
[12] = 
{
	id=12,
	damage=180000,
	total_damage=727100,
	rewards=
	{
	
		{
			id=14,
			num=7,
			pr=1,
		},
	
		{
			id=15,
			num=650,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=650,
			pr=0.2,
		},
	
		{
			id=25,
			num=15,
			pr=0.8,
		},
	},
},
[13] = 
{
	id=13,
	damage=210000,
	total_damage=937100,
	rewards=
	{
	
		{
			id=14,
			num=8,
			pr=1,
		},
	
		{
			id=15,
			num=700,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=700,
			pr=0.2,
		},
	
		{
			id=25,
			num=20,
			pr=0.8,
		},
	},
},
[14] = 
{
	id=14,
	damage=250000,
	total_damage=1187100,
	rewards=
	{
	
		{
			id=14,
			num=8,
			pr=1,
		},
	
		{
			id=15,
			num=750,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=750,
			pr=0.2,
		},
	
		{
			id=25,
			num=20,
			pr=0.8,
		},
	},
},
[15] = 
{
	id=15,
	damage=300000,
	total_damage=1487100,
	rewards=
	{
	
		{
			id=14,
			num=8,
			pr=1,
		},
	
		{
			id=15,
			num=800,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=800,
			pr=0.2,
		},
	
		{
			id=25,
			num=20,
			pr=0.8,
		},
	},
},
[16] = 
{
	id=16,
	damage=350000,
	total_damage=1837100,
	rewards=
	{
	
		{
			id=14,
			num=9,
			pr=1,
		},
	
		{
			id=15,
			num=850,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=850,
			pr=0.2,
		},
	
		{
			id=25,
			num=20,
			pr=0.8,
		},
	},
},
[17] = 
{
	id=17,
	damage=400000,
	total_damage=2237100,
	rewards=
	{
	
		{
			id=14,
			num=9,
			pr=1,
		},
	
		{
			id=15,
			num=900,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=900,
			pr=0.2,
		},
	
		{
			id=25,
			num=20,
			pr=0.8,
		},
	},
},
[18] = 
{
	id=18,
	damage=500000,
	total_damage=2737100,
	rewards=
	{
	
		{
			id=14,
			num=9,
			pr=1,
		},
	
		{
			id=15,
			num=950,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=950,
			pr=0.2,
		},
	
		{
			id=25,
			num=20,
			pr=0.8,
		},
	},
},
[19] = 
{
	id=19,
	damage=600000,
	total_damage=3337100,
	rewards=
	{
	
		{
			id=14,
			num=10,
			pr=1,
		},
	
		{
			id=15,
			num=1000,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1000,
			pr=0.2,
		},
	
		{
			id=25,
			num=25,
			pr=0.8,
		},
	},
},
[20] = 
{
	id=20,
	damage=700000,
	total_damage=4037100,
	rewards=
	{
	
		{
			id=14,
			num=10,
			pr=1,
		},
	
		{
			id=15,
			num=1050,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1050,
			pr=0.2,
		},
	
		{
			id=25,
			num=25,
			pr=0.8,
		},
	},
},
[21] = 
{
	id=21,
	damage=800000,
	total_damage=4837100,
	rewards=
	{
	
		{
			id=14,
			num=10,
			pr=1,
		},
	
		{
			id=15,
			num=1100,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1100,
			pr=0.2,
		},
	
		{
			id=25,
			num=25,
			pr=0.8,
		},
	},
},
[22] = 
{
	id=22,
	damage=900000,
	total_damage=5737100,
	rewards=
	{
	
		{
			id=14,
			num=10,
			pr=1,
		},
	
		{
			id=15,
			num=1150,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1150,
			pr=0.2,
		},
	
		{
			id=25,
			num=25,
			pr=0.8,
		},
	},
},
[23] = 
{
	id=23,
	damage=1000000,
	total_damage=6737100,
	rewards=
	{
	
		{
			id=14,
			num=11,
			pr=1,
		},
	
		{
			id=15,
			num=1200,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1200,
			pr=0.2,
		},
	
		{
			id=25,
			num=25,
			pr=0.8,
		},
	},
},
[24] = 
{
	id=24,
	damage=1100000,
	total_damage=7837100,
	rewards=
	{
	
		{
			id=14,
			num=11,
			pr=1,
		},
	
		{
			id=15,
			num=1250,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1250,
			pr=0.2,
		},
	
		{
			id=25,
			num=25,
			pr=0.8,
		},
	},
},
[25] = 
{
	id=25,
	damage=1200000,
	total_damage=9037100,
	rewards=
	{
	
		{
			id=14,
			num=11,
			pr=1,
		},
	
		{
			id=15,
			num=1300,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1300,
			pr=0.2,
		},
	
		{
			id=25,
			num=30,
			pr=0.8,
		},
	},
},
[26] = 
{
	id=26,
	damage=1300000,
	total_damage=10337100,
	rewards=
	{
	
		{
			id=14,
			num=11,
			pr=1,
		},
	
		{
			id=15,
			num=1350,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1350,
			pr=0.2,
		},
	
		{
			id=25,
			num=30,
			pr=0.8,
		},
	},
},
[27] = 
{
	id=27,
	damage=1400000,
	total_damage=11737100,
	rewards=
	{
	
		{
			id=14,
			num=12,
			pr=1,
		},
	
		{
			id=15,
			num=1400,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1400,
			pr=0.2,
		},
	
		{
			id=25,
			num=30,
			pr=0.8,
		},
	},
},
[28] = 
{
	id=28,
	damage=1500000,
	total_damage=13237100,
	rewards=
	{
	
		{
			id=14,
			num=12,
			pr=1,
		},
	
		{
			id=15,
			num=1450,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1450,
			pr=0.2,
		},
	
		{
			id=25,
			num=30,
			pr=0.8,
		},
	},
},
[29] = 
{
	id=29,
	damage=1600000,
	total_damage=14837100,
	rewards=
	{
	
		{
			id=14,
			num=12,
			pr=1,
		},
	
		{
			id=15,
			num=1500,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1500,
			pr=0.2,
		},
	
		{
			id=25,
			num=30,
			pr=0.8,
		},
	},
},
[30] = 
{
	id=30,
	damage=1700000,
	total_damage=16537100,
	rewards=
	{
	
		{
			id=14,
			num=12,
			pr=1,
		},
	
		{
			id=15,
			num=1550,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1550,
			pr=0.2,
		},
	
		{
			id=25,
			num=30,
			pr=0.8,
		},
	},
},
[31] = 
{
	id=31,
	damage=1800000,
	total_damage=18337100,
	rewards=
	{
	
		{
			id=14,
			num=13,
			pr=1,
		},
	
		{
			id=15,
			num=1600,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1600,
			pr=0.2,
		},
	
		{
			id=25,
			num=35,
			pr=0.8,
		},
	},
},
[32] = 
{
	id=32,
	damage=1900000,
	total_damage=20237100,
	rewards=
	{
	
		{
			id=14,
			num=13,
			pr=1,
		},
	
		{
			id=15,
			num=1650,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1650,
			pr=0.2,
		},
	
		{
			id=25,
			num=35,
			pr=0.8,
		},
	},
},
[33] = 
{
	id=33,
	damage=2000000,
	total_damage=22237100,
	rewards=
	{
	
		{
			id=14,
			num=13,
			pr=1,
		},
	
		{
			id=15,
			num=1700,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1700,
			pr=0.2,
		},
	
		{
			id=25,
			num=35,
			pr=0.8,
		},
	},
},
[34] = 
{
	id=34,
	damage=2100000,
	total_damage=24337100,
	rewards=
	{
	
		{
			id=14,
			num=13,
			pr=1,
		},
	
		{
			id=15,
			num=1750,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1750,
			pr=0.2,
		},
	
		{
			id=25,
			num=35,
			pr=0.8,
		},
	},
},
[35] = 
{
	id=35,
	damage=2200000,
	total_damage=26537100,
	rewards=
	{
	
		{
			id=14,
			num=14,
			pr=1,
		},
	
		{
			id=15,
			num=1800,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1800,
			pr=0.2,
		},
	
		{
			id=25,
			num=35,
			pr=0.8,
		},
	},
},
[36] = 
{
	id=36,
	damage=2300000,
	total_damage=28837100,
	rewards=
	{
	
		{
			id=14,
			num=14,
			pr=1,
		},
	
		{
			id=15,
			num=1850,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1850,
			pr=0.2,
		},
	
		{
			id=25,
			num=35,
			pr=0.8,
		},
	},
},
[37] = 
{
	id=37,
	damage=2400000,
	total_damage=31237100,
	rewards=
	{
	
		{
			id=14,
			num=14,
			pr=1,
		},
	
		{
			id=15,
			num=1900,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1900,
			pr=0.2,
		},
	
		{
			id=25,
			num=40,
			pr=0.8,
		},
	},
},
[38] = 
{
	id=38,
	damage=2500000,
	total_damage=33737100,
	rewards=
	{
	
		{
			id=14,
			num=14,
			pr=1,
		},
	
		{
			id=15,
			num=1950,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=1950,
			pr=0.2,
		},
	
		{
			id=25,
			num=40,
			pr=0.8,
		},
	},
},
[39] = 
{
	id=39,
	damage=2600000,
	total_damage=36337100,
	rewards=
	{
	
		{
			id=14,
			num=14,
			pr=1,
		},
	
		{
			id=15,
			num=2000,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2000,
			pr=0.2,
		},
	
		{
			id=25,
			num=40,
			pr=0.8,
		},
	},
},
[40] = 
{
	id=40,
	damage=2700000,
	total_damage=39037100,
	rewards=
	{
	
		{
			id=14,
			num=14,
			pr=1,
		},
	
		{
			id=15,
			num=2050,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2050,
			pr=0.2,
		},
	
		{
			id=25,
			num=40,
			pr=0.8,
		},
	},
},
[41] = 
{
	id=41,
	damage=2800000,
	total_damage=41837100,
	rewards=
	{
	
		{
			id=14,
			num=15,
			pr=1,
		},
	
		{
			id=15,
			num=2100,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2100,
			pr=0.2,
		},
	
		{
			id=25,
			num=40,
			pr=0.8,
		},
	},
},
[42] = 
{
	id=42,
	damage=2900000,
	total_damage=44737100,
	rewards=
	{
	
		{
			id=14,
			num=15,
			pr=1,
		},
	
		{
			id=15,
			num=2150,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2150,
			pr=0.2,
		},
	
		{
			id=25,
			num=40,
			pr=0.8,
		},
	},
},
[43] = 
{
	id=43,
	damage=3000000,
	total_damage=47737100,
	rewards=
	{
	
		{
			id=14,
			num=15,
			pr=1,
		},
	
		{
			id=15,
			num=2200,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2200,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[44] = 
{
	id=44,
	damage=3100000,
	total_damage=50837100,
	rewards=
	{
	
		{
			id=14,
			num=15,
			pr=1,
		},
	
		{
			id=15,
			num=2250,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2250,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[45] = 
{
	id=45,
	damage=3200000,
	total_damage=54037100,
	rewards=
	{
	
		{
			id=14,
			num=15,
			pr=1,
		},
	
		{
			id=15,
			num=2300,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2300,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[46] = 
{
	id=46,
	damage=3300000,
	total_damage=57337100,
	rewards=
	{
	
		{
			id=14,
			num=15,
			pr=1,
		},
	
		{
			id=15,
			num=2350,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2350,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[47] = 
{
	id=47,
	damage=3400000,
	total_damage=60737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2400,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2400,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[48] = 
{
	id=48,
	damage=3500000,
	total_damage=64237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2450,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2450,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[49] = 
{
	id=49,
	damage=3500000,
	total_damage=67737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2500,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2500,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[50] = 
{
	id=50,
	damage=3500000,
	total_damage=71237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2550,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2550,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[51] = 
{
	id=51,
	damage=4000000,
	total_damage=75237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2600,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2600,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[52] = 
{
	id=52,
	damage=4500000,
	total_damage=79737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2650,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2650,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[53] = 
{
	id=53,
	damage=5000000,
	total_damage=84737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2700,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2700,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[54] = 
{
	id=54,
	damage=5500000,
	total_damage=90237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2750,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2750,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[55] = 
{
	id=55,
	damage=6000000,
	total_damage=96237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2800,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2800,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[56] = 
{
	id=56,
	damage=6500000,
	total_damage=102737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2850,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2850,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[57] = 
{
	id=57,
	damage=7000000,
	total_damage=109737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2900,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2900,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[58] = 
{
	id=58,
	damage=7500000,
	total_damage=117237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=2950,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=2950,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[59] = 
{
	id=59,
	damage=8000000,
	total_damage=125237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3000,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3000,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[60] = 
{
	id=60,
	damage=8500000,
	total_damage=133737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3050,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3050,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[61] = 
{
	id=61,
	damage=9000000,
	total_damage=142737100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3100,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3100,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[62] = 
{
	id=62,
	damage=9500000,
	total_damage=152237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3150,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3150,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[63] = 
{
	id=63,
	damage=10000000,
	total_damage=162237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3200,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3200,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[64] = 
{
	id=64,
	damage=10000000,
	total_damage=172237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3250,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3250,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[65] = 
{
	id=65,
	damage=10000000,
	total_damage=182237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3300,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3300,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[66] = 
{
	id=66,
	damage=10000000,
	total_damage=192237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3350,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3350,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[67] = 
{
	id=67,
	damage=10000000,
	total_damage=202237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3400,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3400,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[68] = 
{
	id=68,
	damage=10000000,
	total_damage=212237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3450,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3450,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[69] = 
{
	id=69,
	damage=10000000,
	total_damage=222237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3500,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3500,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[70] = 
{
	id=70,
	damage=10000000,
	total_damage=232237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3550,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3550,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[71] = 
{
	id=71,
	damage=10000000,
	total_damage=242237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3600,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3600,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[72] = 
{
	id=72,
	damage=10000000,
	total_damage=252237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3650,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3650,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[73] = 
{
	id=73,
	damage=10000000,
	total_damage=262237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3700,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3700,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[74] = 
{
	id=74,
	damage=10000000,
	total_damage=272237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3750,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3750,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[75] = 
{
	id=75,
	damage=10000000,
	total_damage=282237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3800,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3800,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[76] = 
{
	id=76,
	damage=10000000,
	total_damage=292237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3850,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3850,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[77] = 
{
	id=77,
	damage=10000000,
	total_damage=302237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3900,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3900,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[78] = 
{
	id=78,
	damage=10000000,
	total_damage=312237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=3950,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=3950,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[79] = 
{
	id=79,
	damage=10000000,
	total_damage=322237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4000,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4000,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[80] = 
{
	id=80,
	damage=10000000,
	total_damage=332237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4050,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4050,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[81] = 
{
	id=81,
	damage=10000000,
	total_damage=342237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4100,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4100,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[82] = 
{
	id=82,
	damage=10000000,
	total_damage=352237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4150,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4150,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[83] = 
{
	id=83,
	damage=10000000,
	total_damage=362237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4200,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4200,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[84] = 
{
	id=84,
	damage=10000000,
	total_damage=372237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4250,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4250,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[85] = 
{
	id=85,
	damage=10000000,
	total_damage=382237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4300,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4300,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[86] = 
{
	id=86,
	damage=10000000,
	total_damage=392237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4350,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4350,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[87] = 
{
	id=87,
	damage=10000000,
	total_damage=402237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4400,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4400,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[88] = 
{
	id=88,
	damage=10000000,
	total_damage=412237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4450,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4450,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[89] = 
{
	id=89,
	damage=10000000,
	total_damage=422237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4500,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4500,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[90] = 
{
	id=90,
	damage=10000000,
	total_damage=432237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4550,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4550,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[91] = 
{
	id=91,
	damage=10000000,
	total_damage=442237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4600,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4600,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[92] = 
{
	id=92,
	damage=10000000,
	total_damage=452237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4650,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4650,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[93] = 
{
	id=93,
	damage=10000000,
	total_damage=462237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4700,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4700,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[94] = 
{
	id=94,
	damage=10000000,
	total_damage=472237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4750,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4750,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[95] = 
{
	id=95,
	damage=10000000,
	total_damage=482237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4800,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4800,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[96] = 
{
	id=96,
	damage=10000000,
	total_damage=492237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4850,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4850,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[97] = 
{
	id=97,
	damage=10000000,
	total_damage=502237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4900,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4900,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[98] = 
{
	id=98,
	damage=10000000,
	total_damage=512237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=4950,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=4950,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[99] = 
{
	id=99,
	damage=10000000,
	total_damage=522237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=5000,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=5000,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
[100] = 
{
	id=100,
	damage=10000000,
	total_damage=532237100,
	rewards=
	{
	
		{
			id=14,
			num=16,
			pr=1,
		},
	
		{
			id=15,
			num=5050,
			pr=1,
		},
	
		{
			id=1,
			num=10,
			pr=0.1,
		},
	
		{
			id=3,
			num=10,
			pr=1,
		},
	
		{
			id=3,
			num=5,
			pr=0.5,
		},
	
		{
			id=15,
			num=5050,
			pr=0.2,
		},
	
		{
			id=25,
			num=45,
			pr=0.8,
		},
	},
},
}
