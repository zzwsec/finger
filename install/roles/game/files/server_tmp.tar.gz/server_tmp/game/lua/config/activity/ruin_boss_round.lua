
-- pm.TbRuinBossRound



return
{
[1] = 
{
	id=1,
	open=
	{
		min=1,
		max=10,
	},
	npcid=1010,
	name={key='ruin_boss/1',text="药剂师"},
	skill=
	{
	2010,
	2011,
	},
	show_rewards=
	{
	30,
	1,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.2,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0.4,
		},
	
		{
			id=142,
			value=0.4,
		},
	
		{
			id=143,
			value=0.4,
		},
	
		{
			id=144,
			value=0.4,
		},
	
		{
			id=145,
			value=0.4,
		},
	
		{
			id=146,
			value=0.6,
		},
	},
},
[2] = 
{
	id=2,
	open=
	{
		min=11,
		max=20,
	},
	npcid=1015,
	name={key='ruin_boss/2',text="处刑人"},
	skill=
	{
	2020,
	2021,
	},
	show_rewards=
	{
	30,
	1,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0.2,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0.4,
		},
	
		{
			id=142,
			value=0.4,
		},
	
		{
			id=143,
			value=0.4,
		},
	
		{
			id=144,
			value=0.4,
		},
	
		{
			id=145,
			value=0.4,
		},
	
		{
			id=146,
			value=0.6,
		},
	},
},
[3] = 
{
	id=3,
	open=
	{
		min=21,
		max=30,
	},
	npcid=1013,
	name={key='ruin_boss/3',text="异形"},
	skill=
	{
	2030,
	2031,
	},
	show_rewards=
	{
	30,
	1,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0.2,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0.4,
		},
	
		{
			id=142,
			value=0.4,
		},
	
		{
			id=143,
			value=0.4,
		},
	
		{
			id=144,
			value=0.4,
		},
	
		{
			id=145,
			value=0.4,
		},
	
		{
			id=146,
			value=0.6,
		},
	},
},
[4] = 
{
	id=4,
	open=
	{
		min=31,
		max=40,
	},
	npcid=1008,
	name={key='ruin_boss/4',text="重装怪婴"},
	skill=
	{
	2040,
	2041,
	},
	show_rewards=
	{
	30,
	1,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0.05,
		},
	
		{
			id=122,
			value=0,
		},
	
		{
			id=123,
			value=0,
		},
	
		{
			id=124,
			value=0.2,
		},
	
		{
			id=125,
			value=0,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0.4,
		},
	
		{
			id=142,
			value=0.4,
		},
	
		{
			id=143,
			value=0.4,
		},
	
		{
			id=144,
			value=0.4,
		},
	
		{
			id=145,
			value=0.4,
		},
	
		{
			id=146,
			value=0.6,
		},
	},
},
}
