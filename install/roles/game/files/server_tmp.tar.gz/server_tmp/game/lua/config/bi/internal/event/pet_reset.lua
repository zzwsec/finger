
-- pm.TbBiInternalEventPetReset



return
{
[1] = 
{
	id=1,
	field="pet_id",
	name="宠物id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="old_level",
	name="宠物老等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="new_level",
	name="宠物新等级",
	type=0,
	opt=1,
	default_value="",
},
}
