local class = require "utils.class"
local Constants = require "core.Constants"

local Action = require 'core.Action'

local Error = class("Error", Action)

function Error:ctor()
    Action.ctor(self)
    
    self.name = "Error"
end

function Error:tick()
    return Constants.ERROR
end

return Error