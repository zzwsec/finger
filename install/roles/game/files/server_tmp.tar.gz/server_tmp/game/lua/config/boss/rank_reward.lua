
-- pm.TbBossRankReward



return
{
[1] = 
{
	id=1,
	rank_range=
	{
	1,
	1,
	},
	mailid=301,
},
[2] = 
{
	id=2,
	rank_range=
	{
	2,
	2,
	},
	mailid=302,
},
[3] = 
{
	id=3,
	rank_range=
	{
	3,
	3,
	},
	mailid=303,
},
[4] = 
{
	id=4,
	rank_range=
	{
	4,
	10,
	},
	mailid=304,
},
[5] = 
{
	id=5,
	rank_range=
	{
	11,
	50,
	},
	mailid=305,
},
[6] = 
{
	id=6,
	rank_range=
	{
	51,
	100,
	},
	mailid=306,
},
[7] = 
{
	id=7,
	rank_range=
	{
	101,
	9999,
	},
	mailid=307,
},
}
