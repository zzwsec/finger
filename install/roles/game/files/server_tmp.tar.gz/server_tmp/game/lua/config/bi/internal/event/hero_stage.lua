
-- pm.TbBiInternalEventHeroStage



return
{
[1] = 
{
	id=1,
	field="hero_id",
	name="佣兵id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="old_stage",
	name="佣兵老阶级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="new_stage",
	name="佣兵新阶级",
	type=0,
	opt=1,
	default_value="",
},
}
