
-- pm.TbBiKingnetBind



return
{
[100] = 
{
	id=100,
	name="register",
	event="register",
	depend=true,
	channel="http",
},
[101] = 
{
	id=101,
	name="login",
	event="login",
	depend=true,
	channel="http",
},
[102] = 
{
	id=102,
	name="enter_sid",
	event="enter_sid",
	depend=true,
	channel="http",
},
[103] = 
{
	id=103,
	name="create",
	event="create",
	depend=true,
	channel="http",
},
[104] = 
{
	id=104,
	name="role_login",
	event="role_login",
	depend=true,
	channel="http",
},
[105] = 
{
	id=105,
	name="role_exit",
	event="role_exit",
	depend=true,
	channel="http",
},
[106] = 
{
	id=106,
	name="order",
	event="order",
	depend=true,
	channel="http",
},
[107] = 
{
	id=107,
	name="level_up",
	event="level_up",
	depend=true,
	channel="http",
},
[108] = 
{
	id=108,
	name="change_item",
	event="change_item",
	depend=true,
	channel="http",
},
[109] = 
{
	id=109,
	name="change_coin",
	event="change_coin",
	depend=true,
	channel="http",
},
[110] = 
{
	id=110,
	name="online_count",
	event="online_count",
	depend=false,
	channel="http",
},
[111] = 
{
	id=111,
	name="online_num",
	event="online_num",
	depend=false,
	channel="http",
},
[112] = 
{
	id=112,
	name="ad",
	event="ad",
	depend=true,
	channel="http",
},
[113] = 
{
	id=113,
	name="chat",
	event="chat",
	depend=true,
	channel="http",
},
[114] = 
{
	id=114,
	name="mail_add",
	event="mail_add",
	depend=true,
	channel="http",
},
[115] = 
{
	id=115,
	name="mail_del",
	event="mail_del",
	depend=true,
	channel="http",
},
[116] = 
{
	id=116,
	name="mining",
	event="mining",
	depend=true,
	channel="http",
},
[117] = 
{
	id=117,
	name="mining_skill",
	event="mining_skill",
	depend=true,
	channel="http",
},
[118] = 
{
	id=118,
	name="mining_event",
	event="mining_event",
	depend=true,
	channel="http",
},
[119] = 
{
	id=119,
	name="event_unexpected",
	event="event_unexpected",
	depend=true,
	channel="http",
},
[120] = 
{
	id=120,
	name="event_treasure",
	event="event_treasure",
	depend=true,
	channel="http",
},
[121] = 
{
	id=121,
	name="event_stone_identify",
	event="event_stone_identify",
	depend=true,
	channel="http",
},
[122] = 
{
	id=122,
	name="event_stone_sale",
	event="event_stone_sale",
	depend=true,
	channel="http",
},
[123] = 
{
	id=123,
	name="task",
	event="task",
	depend=true,
	channel="http",
},
[124] = 
{
	id=124,
	name="guide",
	event="guide",
	depend=true,
	channel="http",
},
[125] = 
{
	id=125,
	name="build_levelup_star",
	event="build_levelup_star",
	depend=true,
	channel="http",
},
[126] = 
{
	id=126,
	name="build_levelup_end",
	event="build_levelup_end",
	depend=true,
	channel="http",
},
[127] = 
{
	id=127,
	name="build_levelup_accelerate",
	event="build_levelup_accelerate",
	depend=true,
	channel="http",
},
[128] = 
{
	id=128,
	name="tech_tree",
	event="tech_tree",
	depend=true,
	channel="http",
},
[129] = 
{
	id=129,
	name="trade",
	event="trade",
	depend=true,
	channel="http",
},
[130] = 
{
	id=130,
	name="trade_talk",
	event="trade_talk",
	depend=true,
	channel="http",
},
[131] = 
{
	id=131,
	name="mainline",
	event="mainline",
	depend=true,
	channel="http",
},
[132] = 
{
	id=132,
	name="pvp",
	event="pvp",
	depend=true,
	channel="http",
},
[133] = 
{
	id=133,
	name="trial",
	event="trial",
	depend=true,
	channel="http",
},
[134] = 
{
	id=134,
	name="trial_sweep",
	event="trial_sweep",
	depend=false,
	channel="http",
},
[135] = 
{
	id=135,
	name="boss",
	event="boss",
	depend=false,
	channel="http",
},
[136] = 
{
	id=136,
	name="cave",
	event="cave",
	depend=true,
	channel="http",
},
[137] = 
{
	id=137,
	name="shop",
	event="shop",
	depend=true,
	channel="http",
},
[138] = 
{
	id=138,
	name="equip",
	event="equip",
	depend=false,
	channel="http",
},
[139] = 
{
	id=139,
	name="mount_level_exp",
	event="mount_level_exp",
	depend=true,
	channel="http",
},
[140] = 
{
	id=140,
	name="mount_level_up",
	event="mount_level_up",
	depend=true,
	channel="http",
},
[141] = 
{
	id=141,
	name="mount_stage",
	event="mount_stage",
	depend=true,
	channel="http",
},
[142] = 
{
	id=142,
	name="pet_get",
	event="pet_get",
	depend=true,
	channel="http",
},
[143] = 
{
	id=143,
	name="pet_levelup",
	event="pet_levelup",
	depend=true,
	channel="http",
},
[144] = 
{
	id=144,
	name="pet_devour",
	event="pet_devour",
	depend=true,
	channel="http",
},
[145] = 
{
	id=145,
	name="pet_reset",
	event="pet_reset",
	depend=true,
	channel="http",
},
[146] = 
{
	id=146,
	name="pet_release",
	event="pet_release",
	depend=true,
	channel="http",
},
[147] = 
{
	id=147,
	name="pet_bag",
	event="pet_bag",
	depend=true,
	channel="http",
},
[148] = 
{
	id=148,
	name="event_missile",
	event="event_missile",
	depend=true,
	channel="http",
},
[149] = 
{
	id=149,
	name="event_turntable",
	event="event_turntable",
	depend=true,
	channel="http",
},
[150] = 
{
	id=150,
	name="build_queue",
	event="build_queue",
	depend=true,
	channel="http",
},
[151] = 
{
	id=151,
	name="build_reinforce",
	event="build_reinforce",
	depend=true,
	channel="http",
},
[152] = 
{
	id=152,
	name="build_recruit",
	event="build_recruit",
	depend=true,
	channel="http",
},
[153] = 
{
	id=153,
	name="forge_levelup",
	event="forge_levelup",
	depend=true,
	channel="http",
},
[154] = 
{
	id=154,
	name="mount_change",
	event="mount_change",
	depend=true,
	channel="http",
},
[155] = 
{
	id=155,
	name="pet_change",
	event="pet_change",
	depend=true,
	channel="http",
},
[156] = 
{
	id=156,
	name="hero_change",
	event="hero_change",
	depend=true,
	channel="http",
},
[157] = 
{
	id=157,
	name="hero_get",
	event="hero_get",
	depend=true,
	channel="http",
},
[158] = 
{
	id=158,
	name="hero_lottery",
	event="hero_lottery",
	depend=true,
	channel="http",
},
[159] = 
{
	id=159,
	name="hero_levelup",
	event="hero_levelup",
	depend=true,
	channel="http",
},
[160] = 
{
	id=160,
	name="hero_stage",
	event="hero_stage",
	depend=true,
	channel="http",
},
[161] = 
{
	id=161,
	name="hero_star",
	event="hero_star",
	depend=true,
	channel="http",
},
[162] = 
{
	id=162,
	name="hero_reset",
	event="hero_reset",
	depend=true,
	channel="http",
},
[163] = 
{
	id=163,
	name="hero_bag",
	event="hero_bag",
	depend=true,
	channel="http",
},
[164] = 
{
	id=164,
	name="hero_dispatch",
	event="hero_dispatch",
	depend=true,
	channel="http",
},
[165] = 
{
	id=165,
	name="guild_creat",
	event="guild_creat",
	depend=true,
	channel="http",
},
[166] = 
{
	id=166,
	name="guild_join",
	event="guild_join",
	depend=true,
	channel="http",
},
[167] = 
{
	id=167,
	name="guild_exit",
	event="guild_exit",
	depend=true,
	channel="http",
},
[168] = 
{
	id=168,
	name="guild_disband",
	event="guild_disband",
	depend=true,
	channel="http",
},
[169] = 
{
	id=169,
	name="guild_levelup",
	event="guild_levelup",
	depend=false,
	channel="http",
},
[170] = 
{
	id=170,
	name="tower",
	event="tower",
	depend=true,
	channel="http",
},
[171] = 
{
	id=171,
	name="tower_sweep",
	event="tower_sweep",
	depend=true,
	channel="http",
},
[172] = 
{
	id=172,
	name="equip_refine",
	event="equip_refine",
	depend=true,
	channel="http",
},
[173] = 
{
	id=173,
	name="equip_stage",
	event="equip_stage",
	depend=true,
	channel="http",
},
[174] = 
{
	id=174,
	name="guild_approve",
	event="guild_approve",
	depend=true,
	channel="http",
},
[175] = 
{
	id=175,
	name="guild_dismiss",
	event="guild_dismiss",
	depend=true,
	channel="http",
},
[176] = 
{
	id=176,
	name="guild_job_change",
	event="guild_job_change",
	depend=true,
	channel="http",
},
[177] = 
{
	id=177,
	name="event_shop",
	event="event_shop",
	depend=true,
	channel="http",
},
[178] = 
{
	id=178,
	name="guild_contribute",
	event="guild_contribute",
	depend=true,
	channel="http",
},
[179] = 
{
	id=179,
	name="activity_login",
	event="activity_login",
	depend=true,
	channel="http",
},
[180] = 
{
	id=180,
	name="activity_xdays_reward",
	event="activity_xdays_reward",
	depend=true,
	channel="http",
},
[181] = 
{
	id=181,
	name="activity_xdays_commodity",
	event="activity_xdays_commodity",
	depend=true,
	channel="http",
},
[182] = 
{
	id=182,
	name="activity_ranks",
	event="activity_ranks",
	depend=false,
	channel="http",
},
}
