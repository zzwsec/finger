--[[
公共, 基础, 全局函数
]]--

-- class
function class(classname, super)
    local superType = type(super)
    local cls

    --如果父类既不是函数也不是table则说明父类为空
    if superType ~= "function" and superType ~= "table" then
        superType = nil
        super = nil
    end

    --如果父类的类型是函数或者是C对象
    if superType == "function" or (super and super.__ctype == 1) then
        -- inherited from native C++ Object
        cls = {}

        --如果父类是表则复制成员并且设置这个类的继承信息
        --如果是函数类型则设置构造方法并且设置ctor函数
        if superType == "table" then
            -- copy fields from super
            for k,v in pairs(super) do cls[k] = v end
            cls.__create = super.__create
            cls.super    = super
        else
            cls.__create = super
            cls.ctor = function() end
        end

        --设置类型的名称
        cls.__cname = classname
        cls.__ctype = 1

        --定义该类型的创建实例的函数为基类的构造函数后复制到子类实例
        --并且调用子数的ctor方法
        function cls.new(...)
            local instance = cls.__create(...)
            -- copy fields from class to native object
            for k,v in pairs(cls) do instance[k] = v end
            instance.class = cls
            instance:ctor(...)
            return instance
        end

    else
        --如果是继承自普通的lua表,则设置一下原型，并且构造实例后也会调用ctor方法
        -- inherited from Lua Object
        if super then
            cls = {}
            setmetatable(cls, {__index = super})
            cls.super = super
        else
            cls = {ctor = function() end}
        end

        cls.__cname = classname
        cls.__ctype = 2 -- lua
        cls.__index = cls

        function cls.new(...)
            local instance = setmetatable({}, cls)
            instance.class = cls
            instance:ctor(...)
            return instance
        end
    end

    return cls
end

-- 标准库os扩展
local System = require("common/system")

--[[
获取当前时间戳
@return int
]]--
function os.now()
    return System.GetNowTimeSec()
end

-- 标准库string扩展

--[[
字符串分割
@param string input
@param string delimiter
@return array
]]--
function string.split(input, delimiter)
    input = tostring(input)
    delimiter = tostring(delimiter)
    if (delimiter == '') then return false end
    local pos, arr = 0, {}
    for st, sp in function() return string.find(input, delimiter, pos, true) end do 
        table.insert(arr, string.sub(input, pos, st - 1))
        pos = sp + 1
    end
    table.insert(arr, string.sub(input, pos))
    return arr
end

--[[
字符串拼接
@param array array
@param string delimiter
@return string
]]--
function string.join(array, delimiter)
    assert(type(array) == "table")
    delimiter = tostring(delimiter)
    if #array == 0 then 
        return ""
    end
    local output = tostring(array[1])
    for i = 2, #array do 
        output = string.format("%s%s%s", output, delimiter, tostring(array[i]))
    end
    return output
end

--[[
删除字符串头部空格
@param  string input
@return string
]]--
function string.ltrim(input)
    return string.gsub(input, "^[ \t\n\r]+", "")
end

--[[
删除字符串尾部空格
@param  string input
@return string
]]--
function string.rtrim(input)
    return string.gsub(input, "[ \t\n\r]+$", "")
end

--[[
删除字符串开头,结尾空格
@param  string input
@return string
]]--
function string.trim(input)
    input = string.gsub(input, "^[ \t\n\r]+", "")
    return string.gsub(input, "[ \t\n\r]+$", "")
end

--[[
    删除字符串开头,结尾双引号
]]
function string.trim_quotes(input)
    return string.match(input, '"(.*)"$') or input
end

--[[
url编码
@param string s
@param string
]]--
function string.urlencode(s)
    s = string.gsub(s,"([^%w%.%-])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
    return string.gsub(s, " ", "+")
end

--[[
url解码
@param string s
@param string
]]--
function string.urldecode(s)
    s = string.gsub(s, '%%(%x%x)', function(h)
        return string.char(tonumber(h, 16))
    end)
    return s
end

--[[
获取uft8字符串长度
@param string input
@return int
]]--
function string.utf8len(input)
    local left = string.len(input)
    local cnt = 0
    local arr = {0, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc}
    while left > 0 do 
        local tmp = string.byte(input, -left)
        local i = #arr
        while arr[i] do 
            if tmp >= arr[i] then 
                left = left - i
                break
            end
            i = i - 1
        end
        cnt = cnt + 1
    end
    return cnt
end

-- 标准库io扩展相关

--[[
文件是否存在
@param string path
@return boolean
]]--
function io.exists(path)
    local file = io.open(path, "r")
    if file then 
        io.close(file)
        return true
    end
    return false
end


--[[
文件读取
@param string path
@reurn string
]]--
function io.readfile(path)
    local file = io.open(path, "r")
    if file then 
        local content = file:read("*a")
        io.close(file)
        return content
    end
    return nil
end 

--[[
文件写入
@param string path
@param string content
@param string mode
@return boolean
]]-- 
function io.writefile(path, content, mode)
    mode = mode or "w+b"
    local file = io.open(path, mode)
    if file then 
        if file:write(content) == nil then return false end
        io.close(file)
        return true
    else 
        return false
    end
end

function io.filesize(fp)
    local file = fp
    local is_path = type(fp) == "string"
    if is_path then 
        file = io.open(path, "r")
    end

    local length = assert(file:seek("end"))
    if is_path then 
        file:close()
    end
    return length
end

--[[
创建目录
@param string path
]]--
function io.mkdir(path)
    local folders = {}
    for folder in string.gmatch(path, "([^'/']+)") do
        if folder ~= nil then 
            table.insert(folders, folder)
        end
    end
    local tmp_path = ""
    for _, value in ipairs(folders) do
        if string.len(tmp_path) == 0 then 
            tmp_path = value
        else 
            tmp_path = tmp_path .."/".. value
        end
        if not io.exists(tmp_path) then
            os.execute("mkdir ".. tmp_path)
        end
    end
end

-- 标准库table扩展

--[[
计算表格包含的字段数量
@param table t 要检查的表格
@return integer
--]]
function table.nums(t)
    local count = 0
    for k, v in pairs(t) do
        count = count + 1
    end
    return count
end

--[[
返回指定表格中的所有键
local hashtable = {a = 1, b = 2, c = 3}
local keys = table.keys(hashtable)
-- keys = {"a", "b", "c"}

@param table hashtable 要检查的表格
@return table
--]]
function table.keys(hashtable)
    local keys = {}
    for k, v in pairs(hashtable) do
        keys[#keys + 1] = k
    end
    return keys
end

--[[
返回指定表格中的所有值
local hashtable = {a = 1, b = 2, c = 3}
local keys = table.keys(hashtable)
-- keys = {"a", "b", "c"}

@param table hashtable 要检查的表格
@return table
--]]
function table.values(hashtable)
    local values = {}
    for k, v in pairs(hashtable) do
        values[#values + 1] = v
    end
    return values
end

--[[
比较数组table 是否相等
]]--
function table.equal(lhs, rhs)
    if #lhs ~= #rhs then 
        return false
    end 
    for index = 1, #lhs do 
        if lhs[index] ~= rhs[index] then 
            return false
        end
    end
    return true 
end

--[[
将来源表格中所有键及其值复制到目标表格对象中，如果存在同名键，则覆盖其值
local dest = {a = 1, b = 2}
local src  = {c = 3, d = 4}
table.merge(dest, src)
-- dest = {a = 1, b = 2, c = 3, d = 4}

@param table dest 目标表格
@param table src 来源表格
--]]
function table.merge(dest, src)
    for k, v in pairs(src) do
        dest[k] = v
    end
end

--[[
表格合并
local dest = {a = 1, b = 2}
local src  = {c = 3, d = 4}
local ret = table.union(dest, src)
-- ret = {a = 1, b = 2, c = 3, d = 4}

@param table t1 表格
@param table t2 表格
--]]
function table.union(t1, t2)
    local ret = {}
    table.merge(ret, t1)
    table.merge(ret, t2)
    return ret
end

--[[
表格交集
local dest = {a = 1, b = 2}
local src  = {b = 2, c = 3}
local ret = table.intersection(dest, src)
-- ret = { b = 2}

@param table t1 表格
@param table t2 表格
]]--
function table.intersection(t1, t2)
    local ret = {}
    for k,v in pairs(t1) do
        if t2[k] then ret[k] = v end 
    end
    return ret 
end

--[[
表格差集
local dest = {a = 1, b = 2}
local src  = {b = 2, c = 3}
local ret = table.difference(dest, src)
-- ret = { a = 1, c = 3}

@param table t1 表格
@param table t2 表格
]]--
function table.difference(t1, t2)
    local ret = {}
    for k,v in pairs(t1) do
        if t2[k] == nil then ret[k] = v end
    end

    for k,v in pairs(t2) do
        if t1[k] == nil then ret[k] = v end
    end
    return ret
end


--[[
在目标表格的指定位置插入来源表格，如果没有指定位置则连接两个表格
local dest = {1, 2, 3}
local src  = {4, 5, 6}
table.insertto(dest, src)
-- dest = {1, 2, 3, 4, 5, 6}
dest = {1, 2, 3}
table.insertto(dest, src, 5)
-- dest = {1, 2, 3, nil, 4, 5, 6}

@param table dest 目标表格
@param table src 来源表格
@param [integer begin] 插入位置
--]]
function table.insertto(dest, src, begin)
    begin = tonumber(begin) or 0
    if begin <= 0 then
        begin = #dest + 1
    end

    local len = #src
    for i = 0, len - 1 do
        dest[i + begin] = src[i + 1]
    end
end

--[[
从表格中查找指定值，返回其索引，如果没找到返回 false
local array = {"a", "b", "c"}
print(table.indexof(array, "b")) -- 输出 2

@param table array 表格
@param mixed value 要查找的值
@param [integer begin] 起始索引值
@return integer
--]]
function table.indexof(array, value, begin)
    for i = begin or 1, #array do
        if array[i] == value then
            return i
        end
    end
    return false
end

--[[
从表格中查找指定值，返回其 key，如果没找到返回 nil
local hashtable = {name = "dualface", comp = "chukong"}
print(table.keyof(hashtable, "chukong")) -- 输出 comp

@param table hashtable 表格
@param mixed value 要查找的值
@return string 该值对应的 key
--]]
function table.keyof(hashtable, value)
    for k, v in pairs(hashtable) do
        if v == value then
            return k
        end
    end
    return nil
end

--[[
从表格中删除指定值，返回删除的值的个数
local array = {"a", "b", "c", "c"}
print(table.removebyvalue(array, "c", true)) -- 输出 2

@param table array 表格
@param mixed value 要删除的值
@param [boolean removeall] 是否删除所有相同的值
@return integer
--]]
function table.removebyvalue(array, value, removeall)
    local c, i, max = 0, 1, #array
    while i <= max do
        if array[i] == value then
            table.remove(array, i)
            c = c + 1
            i = i - 1
            max = max - 1
            if not removeall then
                break
            end
        end
        i = i + 1
    end
    return c
end

--[[
对表格中每一个值执行一次指定的函数，并用函数返回值更新表格内容
local t = {name = "dualface", comp = "chukong"}
table.map(t, function(v, k)
    -- 在每一个值前后添加括号
    return "[" .. v .. "]"
end)
-- 输出修改后的表格内容
for k, v in pairs(t) do
    print(k, v)
end

@param table t 表格
@param function fn 函数
--]]
function table.map(t, fn)
    for k, v in pairs(t) do
        t[k] = fn(v, k)
    end
end

--[[
对表格中每一个值执行一次指定的函数，但不改变表格内容
local t = {name = "dualface", comp = "chukong"}
table.walk(t, function(v, k)
    -- 输出每一个值
    print(v)
end)

@param table t 表格
@param function fn 函数
--]]
function table.walk(t, fn)
    for k, v in pairs(t) do
        fn(v, k)
    end
end

--[[
获取table 指定的属性转换为array
]]--
function table.prop(t, property)
    local result = {}
    for _, v in pairs(t or {}) do 
        if v[property] ~= nil then 
            table.insert(result, v[property])
        end
    end
    return result
end

--[[
求最大值
]]--
function table.max_element(t, compare)  
    compare = compare or function(lhs, rhs)
        return lhs < rhs
    end

    local _, largest = next(t)
    for index = 2, #t do 
        if compare(largest, t[index]) then 
            largest = t[index]
        end
    end
    return largest
end

--[[
求最小值
]]--
function table.min_element(t, compare)
    compare = compare or function(lhs, rhs)
        return rhs < lhs
    end

    local _, smallest = next(t)
    for index = 2, #t do
        if compare(smallest, t[index]) then 
            smallest = t[index]
        end
    end
    return smallest
end

--[[
对表格中每一个值执行一次指定的函数，如果该函数返回 false，则对应的值会从表格中删除
local t = {name = "dualface", comp = "chukong"}
table.filter(t, function(v, k)
    return v ~= "dualface" -- 当值等于 dualface 时过滤掉该值
end)
-- 输出修改后的表格内容
for k, v in pairs(t) do
    print(k, v)
end
-- 输出
-- comp chukong

@param table t 表格
@param function fn 函数
--]]
function table.filter(t, fn)
    for k, v in pairs(t) do
        if not fn(v, k) then
            t[k] = nil
        end
    end
end

--[[
对表格中执行查找,并范围查找的结果集
local t = {name = "dualface", company = "karken"}
local ret = table.find_if(t, function(v, k)
    return v == "dualface"
end)
-- 输出查找的结果集
for k, v in pairs(ret) do
    print(k, v)
end
-- 输出
-- name dualface

@param table t 表格
@param function fn 函数
--]]

function table.find_if(t, fn)
    local ret = {}
    for k, v in pairs(t or {}) do 
        if fn(k, v) == true then 
            ret[k] = v
        end
    end
    return ret
end

function table.all_if(t, fn)
    local ret = {}
    for k, v in pairs(t or {}) do 
        if fn(k, v) == false then 
            return false
        end
    end
    return true
end

function table.any_if(t, fn)
    local ret = table.find_if(t, fn)
    return next(ret) ~= nil
end

--[[
遍历表格，确保其中的值唯一
local t = {name = "dualface", comp = "chukong"}
table.filter(t, function(v, k)
    return v ~= "dualface" -- 当值等于 dualface 时过滤掉该值
end)
-- 输出修改后的表格内容
for k, v in pairs(t) do
    print(k, v)
end
-- 输出
-- comp chukong

@param table t 表格
@return table 包含所有唯一值的新表格
]]--
function table.unique(t)
    local check = {}
    local n = {}
    for k, v in pairs(t) do
        if not check[v] then
            n[k] = v
            check[v] = true
        end
    end
    return n
end

--[[
table clone
]]--
function table.clone(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then 
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local new_table = {}
        lookup_table[object] = new_table
        for key, value in pairs(object) do 
            new_table[_copy(key)] = _copy(value)
        end
        return setmetatable(new_table, getmetatable(object))
    end
    return _copy(object)
end


--[[
table转换为字符串
local t = {host = "127.0.0.1", user = "42", pwd = "mysql"}
print(table.dump(t))

-- 输出
-- "t" = {
--    "host" = "127.0.0.1"
--    "pwd"  = "mysql"
--    "user" = "42"
-- }

@param value 输出的值
@param desc  描述
@param nesting 嵌套层次, 默认为3层
]]--
function table.dump(value, desc, nesting)
    if type (nesting) ~= "number" then 
        nesting = 10
    end

    local lookup_table = {}
    local result = {}
    local function _v(v)
        if type(v) == "string" then 
            v="\""..v.."\""
        end
        return tostring(v)
    end
    
    local function _dump(value, desc, indent, nest, keylen)
        desc = desc or "<var>"
        spc = ""
        if type(keylen) == "number" then 
            spc = string.rep(" ", keylen - string.len(_v(desc)))
        end

        if type(value) ~= "table" then 
            result[#result + 1] = string.format("%s%s%s = %s", indent, _v(desc), spc, _v(value))
        elseif lookup_table[value] then 
            result[#result + 1] = string.format("%s%s%s = *REF*", indent, desc, spc)
        else
            lookup_table[value] = true
            if nest > nesting then 
                result[#result + 1] = string.format("%s%s = *MAX NESTING*", indent, desc)
            else 
                result[#result + 1] = string.format( "%s%s = {", indent, _v(desc))
                local indent2 = indent.. "    "
                local keys = {}
                local keylen = 0
                local values = {}
                for k, v in pairs(value) do 
                    keys[#keys + 1] = k 
                    local vk =_v(k)
                    local vkl = string.len(vk)
                    if vkl > keylen then keylen = vkl end
                    values[k] = v
                end
                table.sort(keys, function(a, b)
                    if type(a) == "number" and type(b) == "number" then 
                        return a < b 
                    else
                        return tostring(a) < tostring(b)
                    end
                end)

                for i, k in ipairs(keys) do 
                    _dump(values[k], k, indent2, nest + 1, keylen)
                end
                result[#result + 1] = string.format("%s}", indent)
            end
        end
    end
    
    _dump(value, desc, "", 1)

    local format = ""
    for i, line in ipairs(result) do
        format = string.format("%s%s\n", format, line)
    end
    return format
end