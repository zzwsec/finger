local Log = require("common/logging")

local AppGameLib = require("app.game.lib")

local g_game_activity_service = AppGameLib.ActivityService_Stub.new(g_channel)

local function OnHandleEvent_ApplyTeam(team, coro, type, message)
    local service_id = g_router_manager:MatchGameService(message.leader_id, message.leader_zone_id)
    if service_id == nil then
        Log.Debug("OnHandleEvent_ApplyTeam", "game service is not online")
        return
    end
    local request = {
        id = message.leader_id,
        leader_zone_id = message.leader_zone_id,
        apply_id = message.apply_id,
        apply_zone_id = message.apply_zone_id,
        join = message.join,
    }
    assert(g_game_activity_service:ApplyTeamNotify(service_id, request, function(request_error, resp)
        coroutine.resume(coro, request_error, resp)
    end))
    local request_error, resp = coroutine.yield()
    if (request_error ~= "OK") or (resp.result ~= "OK") then
        -- Log.Debug("OnHandleEvent_ApplyTeam", "ApplyTeamNotify faield: error = {}, result = {}", request_error, resp.result)
        return
    end
end
Handlers["ApplyTeamEvent"] = Handlers["ApplyTeamEvent"] or {}
table.insert(Handlers["ApplyTeamEvent"], OnHandleEvent_ApplyTeam)