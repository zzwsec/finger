local Constant = import("api.service.leaderboard.constant")
local ServiceGroup = import("api.utility.service_group")

local _M = {}

local SortType = Constant.SortType
local UpdateType = Constant.UpdateType
local TagType = Constant.TagType
local GroupType = Constant.GroupType

-- 排序类型映射表
local SortTypeMap = {
    [SortType.Desc] = "desc",
    [SortType.Asc]  = "asc"
}

-- 更新类型映射表 
local UpdateTypeMap = {
    [UpdateType.Aggregate] = "aggregate", 
    [UpdateType.Best]      = "best",
    [UpdateType.Replace]   = "replace"
}

-- 标签映射表
local TagTypeMap = {
    [TagType.Player] = "player",
    [TagType.Guild]  = "guild"
}

-- 获取排序类型
function _M.GetSortType(sort_type)
    return SortTypeMap[sort_type] or "desc"
end

-- 获取更新类型
function _M.GetUpdateType(update_type)
    return UpdateTypeMap[update_type] or "replace"
end

-- 获取标签
function _M.GetTagType(tag_id)
    return TagTypeMap[tag_id] or "player"
end

-- 获取组
function _M.GetGroupId(group_type, area_id)
    if group_type == GroupType.Local then
        return area_id
    elseif group_type == GroupType.Group then
        return ServiceGroup.GetGroupId(area_id)
    else
        return 0
    end
end

return _M