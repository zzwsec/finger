
-- pm.TbBiInternalEventPetDevour



return
{
[1] = 
{
	id=1,
	field="pet_id",
	name="宠物id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="old_star",
	name="宠物老星级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="new_star",
	name="宠物新星级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="devour_pet_id",
	name="吞噬宠物id",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="devour_pet_level",
	name="吞噬宠物等级",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="devour_pet_star",
	name="吞噬宠物星级",
	type=0,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="new_passive_attrs",
	name="新被动属性",
	type=1,
	opt=1,
	default_value="",
},
}
