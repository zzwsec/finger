
-- pm.TbBiKingnetEventMountChange



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="切换前座驾id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="config_id1",
	name="切换后座驾id",
	type=0,
	opt=1,
	default_value="",
},
}
