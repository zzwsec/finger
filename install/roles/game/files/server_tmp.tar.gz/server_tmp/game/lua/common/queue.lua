-- 队列
local Queue = {}

-- 创建
function Queue.new(...)
    local o = {}
    setmetatable(o, Queue)
    Queue.__index = Queue
    o:ctor(...)
    return o
end

-- 构造函数
function Queue:ctor()
    self.queue_ = {}
    self.start_index_ = 0
    self.stop_index_ = 0
end

-- 入队
function Queue:Push(e)
    self.queue_[self.stop_index_] = e
    self.stop_index_ = self.stop_index_ + 1
end

-- 出队
function Queue:Pop()
    assert(self.start_index_ < self.stop_index_)
    local element = self.queue_[self.start_index_]
    self.queue_[self.start_index_] = nil
    self.start_index_ = self.start_index_ + 1
    return element
end

-- 清空
function Queue:Clear()
    for i = self.start_index_, self.stop_index_ - 1 do
        self.queue_[i] = nil
    end
    self.start_index_ = 0
    self.stop_index_ = 0
end

-- 队头
function Queue:Top()
    return self.queue_[self.start_index_]
end

-- 数量
function Queue:Size()
    return self.stop_index_ - self.start_index_
end

-- 是否为空
function Queue:IsEmpty()
    return self.start_index_ == self.stop_index_
end

return Queue
