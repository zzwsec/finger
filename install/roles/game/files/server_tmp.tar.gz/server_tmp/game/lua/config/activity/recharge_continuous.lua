
-- pm.TbRechargeContinuous



return
{
[101] = 
{
	id=101,
	index=1,
	desc={key='recharge_continuous_desc/101',text="今日充值6元"},
	days=1,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=60,
		},
	
		{
			id=39,
			num=1,
		},
	},
	grand_rewards=
	{
	},
},
[102] = 
{
	id=102,
	index=1,
	desc={key='recharge_continuous_desc/102',text="今日充值12元"},
	days=2,
	recharge=12,
	rewards=
	{
	
		{
			id=1,
			num=120,
		},
	
		{
			id=39,
			num=2,
		},
	},
	grand_rewards=
	{
	},
},
[103] = 
{
	id=103,
	index=1,
	desc={key='recharge_continuous_desc/103',text="今日充值18元"},
	days=3,
	recharge=18,
	rewards=
	{
	
		{
			id=1,
			num=180,
		},
	
		{
			id=39,
			num=3,
		},
	},
	grand_rewards=
	{
	},
},
[104] = 
{
	id=104,
	index=1,
	desc={key='recharge_continuous_desc/104',text="今日充值30元"},
	days=4,
	recharge=30,
	rewards=
	{
	
		{
			id=1,
			num=300,
		},
	
		{
			id=39,
			num=4,
		},
	},
	grand_rewards=
	{
	},
},
[105] = 
{
	id=105,
	index=1,
	desc={key='recharge_continuous_desc/105',text="今日充值50元"},
	days=5,
	recharge=50,
	rewards=
	{
	
		{
			id=1,
			num=500,
		},
	
		{
			id=39,
			num=5,
		},
	},
	grand_rewards=
	{
	
		{
			id=39,
			num=15,
		},
	},
},
[201] = 
{
	id=201,
	index=2,
	desc={key='recharge_continuous_desc/201',text="今日充值6元"},
	days=1,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=60,
		},
	
		{
			id=148,
			num=1,
		},
	},
	grand_rewards=
	{
	},
},
[202] = 
{
	id=202,
	index=2,
	desc={key='recharge_continuous_desc/202',text="今日充值12元"},
	days=2,
	recharge=12,
	rewards=
	{
	
		{
			id=1,
			num=120,
		},
	
		{
			id=148,
			num=2,
		},
	},
	grand_rewards=
	{
	},
},
[203] = 
{
	id=203,
	index=2,
	desc={key='recharge_continuous_desc/203',text="今日充值18元"},
	days=3,
	recharge=18,
	rewards=
	{
	
		{
			id=1,
			num=180,
		},
	
		{
			id=148,
			num=3,
		},
	},
	grand_rewards=
	{
	},
},
[204] = 
{
	id=204,
	index=2,
	desc={key='recharge_continuous_desc/204',text="今日充值30元"},
	days=4,
	recharge=30,
	rewards=
	{
	
		{
			id=1,
			num=300,
		},
	
		{
			id=148,
			num=4,
		},
	},
	grand_rewards=
	{
	},
},
[205] = 
{
	id=205,
	index=2,
	desc={key='recharge_continuous_desc/205',text="今日充值50元"},
	days=5,
	recharge=50,
	rewards=
	{
	
		{
			id=1,
			num=500,
		},
	
		{
			id=148,
			num=5,
		},
	},
	grand_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[301] = 
{
	id=301,
	index=3,
	desc={key='recharge_continuous_desc/301',text="累计1天充值6元"},
	days=1,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[302] = 
{
	id=302,
	index=3,
	desc={key='recharge_continuous_desc/302',text="累计2天充值6元"},
	days=2,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[303] = 
{
	id=303,
	index=3,
	desc={key='recharge_continuous_desc/303',text="累计3天充值6元"},
	days=3,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[304] = 
{
	id=304,
	index=3,
	desc={key='recharge_continuous_desc/304',text="累计4天充值6元"},
	days=4,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[305] = 
{
	id=305,
	index=3,
	desc={key='recharge_continuous_desc/305',text="累计5天充值6元"},
	days=5,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[401] = 
{
	id=401,
	index=4,
	desc={key='recharge_continuous_desc/401',text="累计1天充值6元"},
	days=1,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[402] = 
{
	id=402,
	index=4,
	desc={key='recharge_continuous_desc/402',text="累计2天充值6元"},
	days=2,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[403] = 
{
	id=403,
	index=4,
	desc={key='recharge_continuous_desc/403',text="累计3天充值6元"},
	days=3,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[404] = 
{
	id=404,
	index=4,
	desc={key='recharge_continuous_desc/404',text="累计4天充值6元"},
	days=4,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[405] = 
{
	id=405,
	index=4,
	desc={key='recharge_continuous_desc/405',text="累计5天充值6元"},
	days=5,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[501] = 
{
	id=501,
	index=5,
	desc={key='recharge_continuous_desc/501',text="累计1天充值6元"},
	days=1,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[502] = 
{
	id=502,
	index=5,
	desc={key='recharge_continuous_desc/502',text="累计2天充值6元"},
	days=2,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[503] = 
{
	id=503,
	index=5,
	desc={key='recharge_continuous_desc/503',text="累计3天充值6元"},
	days=3,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[504] = 
{
	id=504,
	index=5,
	desc={key='recharge_continuous_desc/504',text="累计4天充值6元"},
	days=4,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
[505] = 
{
	id=505,
	index=5,
	desc={key='recharge_continuous_desc/505',text="累计5天充值6元"},
	days=5,
	recharge=6,
	rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	
		{
			id=2,
			num=10000,
		},
	},
	grand_rewards=
	{
	},
},
}
