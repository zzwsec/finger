
-- pm.TbBiInternalEventActivityRanks



return
{
[1] = 
{
	id=1,
	field="activity_id",
	name="活动id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="player_id",
	name="角色id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="zone_id",
	name="区服id",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="type",
	name="排名类型",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="rank",
	name="活动排行",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="value",
	name="活动数据",
	type=0,
	opt=1,
	default_value="0",
},
}
