
-- pm.TbBiKingnetEventCommon



return
{
[1] = 
{
	id=1,
	field="did",
	name="设备id",
	type=1,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="terminal",
	name="终端(Android/iOS)",
	type=1,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="platid",
	name="平台",
	type=1,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="channel",
	name="渠道",
	type=1,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="sid",
	name="区服",
	type=1,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="source_sid",
	name="合服前的区服id",
	type=1,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="server_onlyid",
	name="服务器id",
	type=1,
	opt=1,
	default_value="",
},
[8] = 
{
	id=8,
	field="openid",
	name="平台账号id",
	type=1,
	opt=1,
	default_value="",
},
[9] = 
{
	id=9,
	field="ouid",
	name="游戏账号id",
	type=1,
	opt=1,
	default_value="",
},
[10] = 
{
	id=10,
	field="roleid",
	name="角色id",
	type=1,
	opt=1,
	default_value="",
},
[11] = 
{
	id=11,
	field="rolename",
	name="角色名称",
	type=1,
	opt=1,
	default_value="",
},
[12] = 
{
	id=12,
	field="level",
	name="角色等级",
	type=0,
	opt=1,
	default_value="",
},
[13] = 
{
	id=13,
	field="power",
	name="战力",
	type=0,
	opt=1,
	default_value="",
},
[14] = 
{
	id=14,
	field="vip",
	name="vip",
	type=0,
	opt=1,
	default_value="",
},
[15] = 
{
	id=15,
	field="diamond",
	name="剩余付费货币数量",
	type=0,
	opt=1,
	default_value="",
},
[16] = 
{
	id=16,
	field="bind_diamond",
	name="剩余绑定付费货币数量",
	type=0,
	opt=0,
	default_value="",
},
[17] = 
{
	id=17,
	field="gid",
	name="游戏id",
	type=0,
	opt=1,
	default_value="300167",
},
}
