
-- pm.TbCaveGoblinState



return
{
[1] = 
{
	id=1,
	name={key='goblin_state/1',text="充沛"},
	resource=
	{
	0,
	30,
	},
	gather_speed=2,
},
[2] = 
{
	id=2,
	name={key='goblin_state/2',text="正常"},
	resource=
	{
	31,
	60,
	},
	gather_speed=1,
},
[3] = 
{
	id=3,
	name={key='goblin_state/3',text="虚弱"},
	resource=
	{
	61,
	120,
	},
	gather_speed=0.5,
},
[4] = 
{
	id=4,
	name={key='goblin_state/4',text="枯竭"},
	resource=
	{
	121,
	99999,
	},
	gather_speed=0.01,
},
}
