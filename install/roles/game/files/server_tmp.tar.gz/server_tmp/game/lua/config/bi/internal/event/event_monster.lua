
-- pm.TbBiInternalEventEventMonster



return
{
[1] = 
{
	id=1,
	field="event_id",
	name="事件类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="win",
	name="输赢",
	type=0,
	opt=1,
	default_value="",
},
}
