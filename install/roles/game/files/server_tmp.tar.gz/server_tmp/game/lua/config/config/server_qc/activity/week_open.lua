
-- pm.TbActivityWeekOpen



return
{
[1] = 
{
	id=1,
	open_week=3,
	open_day=1,
	activity=11501,
	start_offset=36000,
	duration=43192800,
	delay=0,
},
[2] = 
{
	id=2,
	open_week=3,
	open_day=1,
	activity=11301,
	start_offset=0,
	duration=43199999,
	delay=0,
},
[3] = 
{
	id=3,
	open_week=3,
	open_day=5,
	activity=11801,
	start_offset=0,
	duration=43192800,
	delay=0,
},
[4] = 
{
	id=4,
	open_week=3,
	open_day=6,
	activity=11001,
	start_offset=0,
	duration=25912800,
	delay=0,
},
[5] = 
{
	id=5,
	open_week=3,
	open_day=6,
	activity=12301,
	start_offset=0,
	duration=25912800,
	delay=0,
},
[6] = 
{
	id=6,
	open_week=4,
	open_day=1,
	activity=11202,
	start_offset=0,
	duration=60479999,
	delay=0,
},
[7] = 
{
	id=7,
	open_week=4,
	open_day=2,
	activity=11101,
	start_offset=0,
	duration=25912800,
	delay=0,
},
[8] = 
{
	id=8,
	open_week=4,
	open_day=2,
	activity=12401,
	start_offset=0,
	duration=25912800,
	delay=0,
},
[9] = 
{
	id=9,
	open_week=4,
	open_day=3,
	activity=10901,
	start_offset=36000,
	duration=43192800,
	delay=0,
},
[10] = 
{
	id=10,
	open_week=5,
	open_day=1,
	activity=10801,
	start_offset=0,
	duration=60472800,
	delay=0,
},
[11] = 
{
	id=11,
	open_week=5,
	open_day=1,
	activity=12501,
	start_offset=0,
	duration=60472800,
	delay=0,
},
[12] = 
{
	id=12,
	open_week=6,
	open_day=1,
	activity=11701,
	start_offset=0,
	duration=431999,
	delay=0,
},
[13] = 
{
	id=13,
	open_week=6,
	open_day=1,
	activity=11401,
	start_offset=0,
	duration=604799,
	delay=0,
},
[14] = 
{
	id=14,
	open_week=6,
	open_day=6,
	activity=11001,
	start_offset=0,
	duration=252000,
	delay=0,
},
[15] = 
{
	id=15,
	open_week=6,
	open_day=6,
	activity=12301,
	start_offset=0,
	duration=252000,
	delay=0,
},
[16] = 
{
	id=16,
	open_week=7,
	open_day=2,
	activity=11101,
	start_offset=0,
	duration=252000,
	delay=0,
},
[17] = 
{
	id=17,
	open_week=7,
	open_day=2,
	activity=12401,
	start_offset=0,
	duration=252000,
	delay=0,
},
[18] = 
{
	id=18,
	open_week=7,
	open_day=3,
	activity=11901,
	start_offset=0,
	duration=431999,
	delay=0,
},
[19] = 
{
	id=19,
	open_week=8,
	open_day=1,
	activity=11501,
	start_offset=36000,
	duration=424800,
	delay=0,
},
[20] = 
{
	id=20,
	open_week=8,
	open_day=1,
	activity=11301,
	start_offset=0,
	duration=431999,
	delay=0,
},
[21] = 
{
	id=21,
	open_week=8,
	open_day=5,
	activity=11801,
	start_offset=0,
	duration=424800,
	delay=0,
},
[22] = 
{
	id=22,
	open_week=9,
	open_day=1,
	activity=10801,
	start_offset=0,
	duration=597600,
	delay=0,
},
[23] = 
{
	id=23,
	open_week=9,
	open_day=1,
	activity=11202,
	start_offset=0,
	duration=604799,
	delay=0,
},
[24] = 
{
	id=24,
	open_week=9,
	open_day=3,
	activity=10901,
	start_offset=36000,
	duration=424800,
	delay=0,
},
[25] = 
{
	id=25,
	open_week=9,
	open_day=6,
	activity=11001,
	start_offset=0,
	duration=252000,
	delay=0,
},
[26] = 
{
	id=26,
	open_week=9,
	open_day=6,
	activity=12301,
	start_offset=0,
	duration=252000,
	delay=0,
},
[27] = 
{
	id=27,
	open_week=10,
	open_day=1,
	activity=12501,
	start_offset=0,
	duration=597600,
	delay=0,
},
[28] = 
{
	id=28,
	open_week=10,
	open_day=2,
	activity=11101,
	start_offset=0,
	duration=252000,
	delay=0,
},
[29] = 
{
	id=29,
	open_week=10,
	open_day=2,
	activity=12401,
	start_offset=0,
	duration=252000,
	delay=0,
},
}
