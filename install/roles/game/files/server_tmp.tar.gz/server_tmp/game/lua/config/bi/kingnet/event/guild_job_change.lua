
-- pm.TbBiKingnetEventGuildJobChange



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="config_id1",
	name="目标角色id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="type",
	name="变更职务",
	type=0,
	opt=1,
	default_value="0",
},
}
