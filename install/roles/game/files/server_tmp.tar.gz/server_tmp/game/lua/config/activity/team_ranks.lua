
-- pm.TbActivityTeamRanks



return
{
[1] = 
{
	id=1,
	type=201,
	rank_range=
	{
	1,
	1,
	},
	mailid=10001,
	conditions=80,
},
[2] = 
{
	id=2,
	type=201,
	rank_range=
	{
	2,
	2,
	},
	mailid=10002,
	conditions=70,
},
[3] = 
{
	id=3,
	type=201,
	rank_range=
	{
	3,
	3,
	},
	mailid=10003,
	conditions=60,
},
[4] = 
{
	id=4,
	type=201,
	rank_range=
	{
	4,
	10,
	},
	mailid=10004,
	conditions=50,
},
[5] = 
{
	id=5,
	type=201,
	rank_range=
	{
	11,
	20,
	},
	mailid=10005,
	conditions=45,
},
[6] = 
{
	id=6,
	type=201,
	rank_range=
	{
	21,
	50,
	},
	mailid=10006,
	conditions=40,
},
[7] = 
{
	id=7,
	type=201,
	rank_range=
	{
	51,
	100,
	},
	mailid=10007,
	conditions=35,
},
[8] = 
{
	id=8,
	type=201,
	rank_range=
	{
	101,
	9999,
	},
	mailid=10008,
	conditions=0,
},
}
