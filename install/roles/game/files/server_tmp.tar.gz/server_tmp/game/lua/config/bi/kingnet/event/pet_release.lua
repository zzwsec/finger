
-- pm.TbBiKingnetEventPetRelease



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="宠物id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="宠物等级",
	type=0,
	opt=1,
	default_value="",
},
}
