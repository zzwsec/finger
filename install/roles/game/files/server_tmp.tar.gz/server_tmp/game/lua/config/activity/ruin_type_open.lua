
-- pm.TbRuinTypeOpen



return
{
[1] = 
{
	id=1,
	conditions=
	{
		type=6,
		value=1,
	},
},
[2] = 
{
	id=2,
	conditions=
	{
		type=6,
		value=1,
	},
},
[3] = 
{
	id=3,
	conditions=
	{
		type=6,
		value=24,
	},
},
[4] = 
{
	id=4,
	conditions=
	{
		type=6,
		value=50,
	},
},
}
