
-- pm.TbRuinAttribute



return
{
[1] = 
{
	id=1,
	attr=
	{
		id=201,
		value=0.02,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[2] = 
{
	id=2,
	attr=
	{
		id=202,
		value=0.02,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[3] = 
{
	id=3,
	attr=
	{
		id=203,
		value=0.02,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[4] = 
{
	id=4,
	attr=
	{
		id=123,
		value=0.03,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[5] = 
{
	id=5,
	attr=
	{
		id=122,
		value=0.03,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[6] = 
{
	id=6,
	attr=
	{
		id=121,
		value=0.03,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[7] = 
{
	id=7,
	attr=
	{
		id=124,
		value=0.03,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[8] = 
{
	id=8,
	attr=
	{
		id=125,
		value=0.03,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
[9] = 
{
	id=9,
	attr=
	{
		id=126,
		value=0.03,
	},
	cost=
	{
		id=76,
		num=1,
	},
	max_level=20,
},
}
