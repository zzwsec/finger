
-- pm.TbBiInternalEventPvp



return
{
[1] = 
{
	id=1,
	field="report_id",
	name="战报id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="win",
	name="输赢",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="red_id",
	name="攻方id",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="red_zone_id",
	name="攻方区服id",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="red_score",
	name="攻方老分数",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="red_change",
	name="攻方变更分数",
	type=0,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="red_power",
	name="攻方战力",
	type=0,
	opt=1,
	default_value="",
},
[8] = 
{
	id=8,
	field="blue_id",
	name="守方id",
	type=0,
	opt=1,
	default_value="",
},
[9] = 
{
	id=9,
	field="blue_zone_id",
	name="守方区服id",
	type=0,
	opt=1,
	default_value="",
},
[10] = 
{
	id=10,
	field="blue_score",
	name="守方老分数",
	type=0,
	opt=1,
	default_value="",
},
[11] = 
{
	id=11,
	field="blue_change",
	name="守方变更分数",
	type=0,
	opt=1,
	default_value="",
},
[12] = 
{
	id=12,
	field="blue_power",
	name="守方战力",
	type=0,
	opt=1,
	default_value="",
},
}
