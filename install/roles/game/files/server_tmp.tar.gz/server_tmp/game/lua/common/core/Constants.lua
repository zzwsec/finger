local Constants = {
    VERSION = "0.2.0",

    --Returning status
    SUCCESS = 1,
    FAILURE = 2,
    RUNNING = 3,
    ERROR     = 4,

    --Node categories
    COMPOSITE = "composite",
    DECORATOR = "decorator",
    ACTION = "action",
    CONDITION = "condition",
}

return Constants