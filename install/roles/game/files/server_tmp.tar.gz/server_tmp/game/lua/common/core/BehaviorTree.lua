local class = require "utils.class"
local uuid = require "utils.uuid"

local All = {}

All.Action = require 'core.Action'
All.BaseNode = require 'core.BaseNode'
All.Blackboard = require 'core.Blackboard'
All.Composite = require 'core.Composite'
All.Condition = require 'core.Condition'
All.Decorator = require 'core.Decorator'
All.Tick = require 'core.Tick'

All.Error = require 'actions.Error'
All.Failer = require 'actions.Failer'
All.Runner = require 'actions.Runner'
All.Succeeder = require 'actions.Succeeder'
All.Wait = require 'actions.Wait'

All.MemPriority = require 'composites.MemPriority'
All.MemSequence = require 'composites.MemSequence'
All.Priority = require 'composites.Priority'
All.Sequence = require 'composites.Sequence'
All.Selector = require 'composites.Selector'

All.Inverter = require 'decorators.Inverter'
All.Limiter = require 'decorators.Limiter'
All.MaxTime = require 'decorators.MaxTime'
All.Repeater = require 'decorators.Repeater'
All.RepeatUntilFailure = require 'decorators.RepeatUntilFailure'
All.RepeatUntilSuccess = require 'decorators.RepeatUntilSuccess'

local BehaviorTree = class("BehaviorTree")
All.BehaviorTree = BehaviorTree

function BehaviorTree:ctor()
    self.id             = uuid()
    self.title             = "The behavior tree"
    self.description     = "Default description"
    self.properties     = {}
    self.root            = nil
    self.nodes             = {}
    self.debug            = nil
end

function BehaviorTree:load(data, names)
    names = names or {}
    
    self.title             = data.title or self.title
    self.description     = data.description or self.description
    self.properties     = data.properties or self.properties

    for _, spec in pairs(data.nodes) do
        local Cls
        if names[spec.name] then
            Cls = names[spec.name]
        elseif All[spec.name] then
            Cls = All[spec.name]
        end
        assert(Cls, "Error : BehaviorTree.load : Invalid node name + " .. spec.name .. ".")
        local node = Cls.new(spec.properties)
        node.id = spec.id or node.id
        node.title = spec.title or node.title
        node.description = spec.description or node.description
        node.properties = spec.properties or node.proerties

        self.nodes[node.id] = node
    end

    for _, spec in pairs(data.nodes) do
        local node = self.nodes[spec.id]
        if spec.child then
            node.child = assert(self.nodes[spec.child])
        end
        if spec.children then
            for i = 1, #spec.children do
                local cid = assert(spec.children[i])
                table.insert(node.children, self.nodes[cid])
            end
        end
    end

    self.root = assert(self.nodes[data.root])
end

function BehaviorTree:dump()
    local data = {}
    local customNames = {}

    data.title             = self.title
    data.description     = self.description
    if self.root then
        data.root        = self.root.id
    else
        data.root        = nil
    end
    data.properties        = self.properties
    data.nodes             = {}
    data.custom_nodes    = {}

    if self.root then
        return data
    end

    --TODO:
end

function BehaviorTree:tick(nowTime, target, blackboard)
    assert(blackboard, "The blackboard parameter is obligatory and must be an instance of b3.Blackboard")

    local tick = All.Tick.new()
    tick.debug         = self.debug
    tick.target        = target
    tick.nowTime     = nowTime
    tick.blackboard = blackboard
    tick.tree         = self

    --TICK NODE
    local state = self.root:_execute(tick)

    --CLOSE NODES FROM LAST TICK, IF NEEDED
    local lastOpenNodes = blackboard:get("openNodes", self.id)
    local currOpenNodes = tick._openNodes[0]
    if not lastOpenNodes then
        lastOpenNodes = {}
    end

    if not currOpenNodes then
        currOpenNodes = {}
    end

    local start = 0
    local i
    for i = 0, math.min(#lastOpenNodes, #currOpenNodes) do
        start = i + 1
        if lastOpenNodes[i] ~= currOpenNodes[i] then
            break
        end
    end

    for i = #lastOpenNodes, 0, -1 do
        if lastOpenNodes[i] then
            lastOpenNodes[i]:_close(tick)
        end
    end

    blackboard:set("openNodes", currOpenNodes, self.id)
    blackboard:set("nodeCount", tick._nodeCount, self.id)

    return state
end

return BehaviorTree
