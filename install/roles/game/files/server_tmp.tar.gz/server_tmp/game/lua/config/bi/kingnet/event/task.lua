
-- pm.TbBiKingnetEventTask



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="任务id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="type",
	name="任务类型",
	type=0,
	opt=1,
	default_value="",
},
}
