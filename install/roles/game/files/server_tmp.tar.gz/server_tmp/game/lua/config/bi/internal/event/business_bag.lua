
-- pm.TbBiInternalEventBusinessBag



return
{
[1] = 
{
	id=1,
	field="round_id",
	name="轮数id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="old_bag_limit",
	name="旧背包上限",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="bag_limit",
	name="背包上限",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="old_fund",
	name="扩充前资金",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="fund",
	name="当前资金",
	type=0,
	opt=1,
	default_value="0",
},
}
