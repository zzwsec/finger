
local _M = {}

-- 验证请求参数
function _M.validateParams(request, fields)
    for _, field in ipairs(fields) do
        if not request[field] then
            return false
        end
    end
    return true
end

return _M