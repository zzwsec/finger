
-- pm.TbBiKingnetEventGuildCreat



return
{
[1] = 
{
	id=1,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="",
},
}
