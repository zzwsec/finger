
-- pm.TbBiInternalEventGuildHelp



return
{
[1] = 
{
	id=1,
	field="target_player_id",
	name="目标角色id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="build_id",
	name="目标建筑id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="build_level",
	name="目标建筑等级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="accelerate_times",
	name="已加速次数",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="accelerate_time",
	name="加速时间(秒)",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="help_times",
	name="累计互助次数",
	type=0,
	opt=1,
	default_value="",
},
}
