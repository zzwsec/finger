local Log = require("common/logging")
local luadb = require("common/luadb/db")

local Root = import("config/root", true)

local M = {}

local FileName = "last_time.db"
local FilePath = string.format("%s/%s", Root.Activity.PUBLISH_PATH, FileName)

Globals.LastCheckList = Globals.LastCheckList or {}
Globals.LastCheckReadFlag = Globals.LastCheckReadFlag or false

function M.Opendb(path)
    local f = luadb.open({
        path = path,
        can_each = true
    })
    return f
end

-- 初始化校验列表
function M.ReadOpenLastTime(path)
    if Globals.LastCheckReadFlag == false then
        local f = M.Opendb(path)
        for v in f:each() do
            local id = tonumber(v.name)
            Globals.LastCheckList[id] = f:get(v)
        end
        f:close()
        Globals.LastCheckReadFlag = true
    end
end

-- 合并
function M.Merge()
    M.WriteConfig(FilePath, Globals.LastCheckList)
end

-- 写入
function M.WriteConfig(path, content)
    local f = M.Opendb(path)
    for id, value in pairs(content or {}) do
        f:set(id, value)
    end
    f:close()
end

-- 获取列表
function M.OpenLastCheckList()
    return Globals.LastCheckList
end

-- 初始化
M.ReadOpenLastTime(FilePath)

return M