local Log = require("common/logging")
local Time = require("common/time")

local Config = import("activity/config")
local Const = import("activity/const")

local Root = import("config/root", true)

local M = {}

-- 调用
function M.Invoke(open_list, now_time)
    local cb = function(items, config)
        if next(items) == nil then
            return
        end
        local active = items[1]
        for _, item in pairs(items or {}) do
            if item.begin_time <= now_time and item.end_time >= now_time then
                active = item
                break
            end
        end
        if active.begin_time == 0 or active.end_time == 0 then 
            return
        end

        local activity_id = active.activity
        local value = {
            id = activity_id,
            type = config.type,
            index = config.index,
            order = config.order,
            icon = config.icon,
            visible = config.visible,
            rank = config.rank or 0,
            guild_rank = config.guild_rank or 0,
            mode = Const.ActiveTimeMode.SERVER,
            time_solt = {
                begin_time = active.begin_time, 
                end_time = active.end_time,
            }
        }
        return activity_id, value
    end
    local configs = Config.ServerOpenConfigByActivityId()
    for act_id, sub_cfgs in pairs(configs or {}) do 
        local config = Config.ActivityConfig(act_id)
        if config ~= nil then
            local id, value = cb(sub_cfgs, config)
            if id ~= nil then 
                open_list[id] = value
            end 
        else
            Log.Debug("TimePolicy.Invoke", "not find activity config, id = {}", act_id)
        end
    end
end

return M