
-- pm.TbBiInternalEventBusinessTrade



return
{
[1] = 
{
	id=1,
	field="round_id",
	name="轮数id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="hearsay_id",
	name="传闻id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="type",
	name="类型",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="old_fund",
	name="买卖前资金",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="fund",
	name="当前资金",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="bag_limit",
	name="背包上限",
	type=0,
	opt=1,
	default_value="0",
},
[7] = 
{
	id=7,
	field="old_bag_goods",
	name="买卖前背包商品",
	type=1,
	opt=1,
	default_value="0",
},
[8] = 
{
	id=8,
	field="bag_goods",
	name="当前背包商品",
	type=1,
	opt=1,
	default_value="0",
},
}
