
-- pm.TbBossRound



return
{
[1] = 
{
	id=1,
	next=2,
	model=1607,
	ratio=0.75,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	1,
	25,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.2,
		},
	
		{
			id=123,
			value=0.1,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.1,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=0.2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0.1,
		},
	},
},
[2] = 
{
	id=2,
	next=3,
	model=1608,
	ratio=0.75,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	1,
	25,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.1,
		},
	
		{
			id=123,
			value=0.2,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.1,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=0.2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0.1,
		},
	},
},
[3] = 
{
	id=3,
	next=4,
	model=1609,
	ratio=0.75,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	1,
	25,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.1,
		},
	
		{
			id=123,
			value=0.1,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.2,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=0.2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0.1,
		},
	},
},
[4] = 
{
	id=4,
	next=5,
	model=1610,
	ratio=0.75,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	1,
	25,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.1,
		},
	
		{
			id=123,
			value=0.15,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.15,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=0.2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0.1,
		},
	},
},
[5] = 
{
	id=5,
	next=1,
	model=1611,
	ratio=0.75,
	during=1,
	show_rewards=
	{
	14,
	15,
	3,
	1,
	25,
	},
	attrs=
	{
	
		{
			id=120,
			value=2,
		},
	
		{
			id=121,
			value=0,
		},
	
		{
			id=122,
			value=0.15,
		},
	
		{
			id=123,
			value=0.15,
		},
	
		{
			id=124,
			value=0,
		},
	
		{
			id=125,
			value=0.1,
		},
	
		{
			id=126,
			value=0,
		},
	
		{
			id=141,
			value=0,
		},
	
		{
			id=142,
			value=0.2,
		},
	
		{
			id=143,
			value=0.2,
		},
	
		{
			id=144,
			value=0.2,
		},
	
		{
			id=145,
			value=0.2,
		},
	
		{
			id=146,
			value=0.1,
		},
	},
},
}
