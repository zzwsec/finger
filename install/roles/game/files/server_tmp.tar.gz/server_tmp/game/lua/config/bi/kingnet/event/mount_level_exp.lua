
-- pm.TbBiKingnetEventMountLevelExp



return
{
[1] = 
{
	id=1,
	field="num",
	name="当前等级",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num1",
	name="升级前经验",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="num2",
	name="升级获得经验",
	type=0,
	opt=1,
	default_value="",
},
}
