
-- pm.TbBattlePass



return
{
[1] = 
{
	id=1,
	type=1,
	round=1,
	index=1,
	level=3,
	free_rewards=
	{
		id=3,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=300,
		},
	},
},
[2] = 
{
	id=2,
	type=1,
	round=1,
	index=2,
	level=6,
	free_rewards=
	{
		id=3,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=300,
		},
	},
},
[3] = 
{
	id=3,
	type=1,
	round=1,
	index=3,
	level=9,
	free_rewards=
	{
		id=3,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=300,
		},
	},
},
[4] = 
{
	id=4,
	type=1,
	round=1,
	index=4,
	level=12,
	free_rewards=
	{
		id=3,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[5] = 
{
	id=5,
	type=1,
	round=1,
	index=5,
	level=15,
	free_rewards=
	{
		id=3,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[6] = 
{
	id=6,
	type=1,
	round=1,
	index=6,
	level=18,
	free_rewards=
	{
		id=3,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[7] = 
{
	id=7,
	type=1,
	round=1,
	index=7,
	level=21,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[8] = 
{
	id=8,
	type=1,
	round=1,
	index=8,
	level=24,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[9] = 
{
	id=9,
	type=1,
	round=1,
	index=9,
	level=27,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[10] = 
{
	id=10,
	type=1,
	round=1,
	index=10,
	level=30,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[11] = 
{
	id=11,
	type=1,
	round=1,
	index=11,
	level=33,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[12] = 
{
	id=12,
	type=1,
	round=1,
	index=12,
	level=36,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[13] = 
{
	id=13,
	type=1,
	round=1,
	index=13,
	level=40,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[14] = 
{
	id=14,
	type=1,
	round=1,
	index=14,
	level=45,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[15] = 
{
	id=15,
	type=1,
	round=1,
	index=15,
	level=50,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[16] = 
{
	id=16,
	type=1,
	round=2,
	index=1,
	level=52,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=600,
		},
	},
},
[17] = 
{
	id=17,
	type=1,
	round=2,
	index=2,
	level=54,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=600,
		},
	},
},
[18] = 
{
	id=18,
	type=1,
	round=2,
	index=3,
	level=56,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=600,
		},
	},
},
[19] = 
{
	id=19,
	type=1,
	round=2,
	index=4,
	level=58,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=600,
		},
	},
},
[20] = 
{
	id=20,
	type=1,
	round=2,
	index=5,
	level=60,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=600,
		},
	},
},
[21] = 
{
	id=21,
	type=1,
	round=2,
	index=6,
	level=62,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=600,
		},
	},
},
[22] = 
{
	id=22,
	type=1,
	round=2,
	index=7,
	level=64,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[23] = 
{
	id=23,
	type=1,
	round=2,
	index=8,
	level=66,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[24] = 
{
	id=24,
	type=1,
	round=2,
	index=9,
	level=68,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[25] = 
{
	id=25,
	type=1,
	round=2,
	index=10,
	level=70,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[26] = 
{
	id=26,
	type=1,
	round=2,
	index=11,
	level=72,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[27] = 
{
	id=27,
	type=1,
	round=2,
	index=12,
	level=75,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[28] = 
{
	id=28,
	type=1,
	round=3,
	index=1,
	level=77,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[29] = 
{
	id=29,
	type=1,
	round=3,
	index=2,
	level=79,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[30] = 
{
	id=30,
	type=1,
	round=3,
	index=3,
	level=81,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[31] = 
{
	id=31,
	type=1,
	round=3,
	index=4,
	level=83,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[32] = 
{
	id=32,
	type=1,
	round=3,
	index=5,
	level=85,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[33] = 
{
	id=33,
	type=1,
	round=3,
	index=6,
	level=87,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[34] = 
{
	id=34,
	type=1,
	round=3,
	index=7,
	level=89,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[35] = 
{
	id=35,
	type=1,
	round=3,
	index=8,
	level=91,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[36] = 
{
	id=36,
	type=1,
	round=3,
	index=9,
	level=93,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[37] = 
{
	id=37,
	type=1,
	round=3,
	index=10,
	level=95,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1000,
		},
	},
},
[38] = 
{
	id=38,
	type=2,
	round=1,
	index=1,
	level=100,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[39] = 
{
	id=39,
	type=2,
	round=1,
	index=2,
	level=500,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[40] = 
{
	id=40,
	type=2,
	round=1,
	index=3,
	level=1000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[41] = 
{
	id=41,
	type=2,
	round=1,
	index=4,
	level=2000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[42] = 
{
	id=42,
	type=2,
	round=1,
	index=5,
	level=5000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[43] = 
{
	id=43,
	type=2,
	round=1,
	index=6,
	level=8000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[44] = 
{
	id=44,
	type=2,
	round=1,
	index=7,
	level=11000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[45] = 
{
	id=45,
	type=2,
	round=1,
	index=8,
	level=14000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[46] = 
{
	id=46,
	type=2,
	round=1,
	index=9,
	level=17000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[47] = 
{
	id=47,
	type=2,
	round=1,
	index=10,
	level=20000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[48] = 
{
	id=48,
	type=2,
	round=1,
	index=11,
	level=23000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[49] = 
{
	id=49,
	type=2,
	round=1,
	index=12,
	level=26000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[50] = 
{
	id=50,
	type=2,
	round=1,
	index=13,
	level=29000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[51] = 
{
	id=51,
	type=2,
	round=1,
	index=14,
	level=32000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[52] = 
{
	id=52,
	type=2,
	round=1,
	index=15,
	level=35000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[53] = 
{
	id=53,
	type=2,
	round=1,
	index=16,
	level=38000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[54] = 
{
	id=54,
	type=2,
	round=1,
	index=17,
	level=41000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[55] = 
{
	id=55,
	type=2,
	round=1,
	index=18,
	level=44000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[56] = 
{
	id=56,
	type=2,
	round=1,
	index=19,
	level=47000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[57] = 
{
	id=57,
	type=2,
	round=1,
	index=20,
	level=50000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1000,
		},
	},
},
[58] = 
{
	id=58,
	type=2,
	round=2,
	index=1,
	level=53000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[59] = 
{
	id=59,
	type=2,
	round=2,
	index=2,
	level=56000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[60] = 
{
	id=60,
	type=2,
	round=2,
	index=3,
	level=59000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[61] = 
{
	id=61,
	type=2,
	round=2,
	index=4,
	level=62000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[62] = 
{
	id=62,
	type=2,
	round=2,
	index=5,
	level=65000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[63] = 
{
	id=63,
	type=2,
	round=2,
	index=6,
	level=68000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[64] = 
{
	id=64,
	type=2,
	round=2,
	index=7,
	level=71000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[65] = 
{
	id=65,
	type=2,
	round=2,
	index=8,
	level=74000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[66] = 
{
	id=66,
	type=2,
	round=2,
	index=9,
	level=77000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[67] = 
{
	id=67,
	type=2,
	round=2,
	index=10,
	level=80000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[68] = 
{
	id=68,
	type=2,
	round=2,
	index=11,
	level=83000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[69] = 
{
	id=69,
	type=2,
	round=2,
	index=12,
	level=86000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[70] = 
{
	id=70,
	type=2,
	round=2,
	index=13,
	level=89000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[71] = 
{
	id=71,
	type=2,
	round=2,
	index=14,
	level=92000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[72] = 
{
	id=72,
	type=2,
	round=2,
	index=15,
	level=95000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[73] = 
{
	id=73,
	type=2,
	round=2,
	index=16,
	level=98000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[74] = 
{
	id=74,
	type=2,
	round=2,
	index=17,
	level=101000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[75] = 
{
	id=75,
	type=2,
	round=2,
	index=18,
	level=104000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[76] = 
{
	id=76,
	type=2,
	round=2,
	index=19,
	level=107000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[77] = 
{
	id=77,
	type=2,
	round=2,
	index=20,
	level=110000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[78] = 
{
	id=78,
	type=2,
	round=3,
	index=1,
	level=115000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[79] = 
{
	id=79,
	type=2,
	round=3,
	index=2,
	level=120000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[80] = 
{
	id=80,
	type=2,
	round=3,
	index=3,
	level=125000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[81] = 
{
	id=81,
	type=2,
	round=3,
	index=4,
	level=130000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[82] = 
{
	id=82,
	type=2,
	round=3,
	index=5,
	level=135000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[83] = 
{
	id=83,
	type=2,
	round=3,
	index=6,
	level=140000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[84] = 
{
	id=84,
	type=2,
	round=3,
	index=7,
	level=145000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[85] = 
{
	id=85,
	type=2,
	round=3,
	index=8,
	level=150000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[86] = 
{
	id=86,
	type=2,
	round=3,
	index=9,
	level=155000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[87] = 
{
	id=87,
	type=2,
	round=3,
	index=10,
	level=160000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=1500,
		},
	},
},
[88] = 
{
	id=88,
	type=2,
	round=3,
	index=11,
	level=165000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[89] = 
{
	id=89,
	type=2,
	round=3,
	index=12,
	level=170000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[90] = 
{
	id=90,
	type=2,
	round=3,
	index=13,
	level=175000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[91] = 
{
	id=91,
	type=2,
	round=3,
	index=14,
	level=180000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[92] = 
{
	id=92,
	type=2,
	round=3,
	index=15,
	level=185000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[93] = 
{
	id=93,
	type=2,
	round=3,
	index=16,
	level=190000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[94] = 
{
	id=94,
	type=2,
	round=3,
	index=17,
	level=195000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[95] = 
{
	id=95,
	type=2,
	round=3,
	index=18,
	level=200000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[96] = 
{
	id=96,
	type=2,
	round=3,
	index=19,
	level=205000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[97] = 
{
	id=97,
	type=2,
	round=3,
	index=20,
	level=210000,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=2000,
		},
	},
},
[98] = 
{
	id=98,
	type=3,
	round=1,
	index=1,
	level=3,
	free_rewards=
	{
		id=11,
		num=12,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=120,
		},
	},
},
[99] = 
{
	id=99,
	type=3,
	round=1,
	index=2,
	level=6,
	free_rewards=
	{
		id=11,
		num=12,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=120,
		},
	},
},
[100] = 
{
	id=100,
	type=3,
	round=1,
	index=3,
	level=9,
	free_rewards=
	{
		id=12,
		num=8,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=80,
		},
	},
},
[101] = 
{
	id=101,
	type=3,
	round=1,
	index=4,
	level=12,
	free_rewards=
	{
		id=11,
		num=12,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=120,
		},
	},
},
[102] = 
{
	id=102,
	type=3,
	round=1,
	index=5,
	level=15,
	free_rewards=
	{
		id=11,
		num=12,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=120,
		},
	},
},
[103] = 
{
	id=103,
	type=3,
	round=1,
	index=6,
	level=18,
	free_rewards=
	{
		id=12,
		num=8,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=80,
		},
	},
},
[104] = 
{
	id=104,
	type=3,
	round=1,
	index=7,
	level=21,
	free_rewards=
	{
		id=11,
		num=12,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=120,
		},
	},
},
[105] = 
{
	id=105,
	type=3,
	round=1,
	index=8,
	level=24,
	free_rewards=
	{
		id=11,
		num=12,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=120,
		},
	},
},
[106] = 
{
	id=106,
	type=3,
	round=1,
	index=9,
	level=27,
	free_rewards=
	{
		id=12,
		num=8,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=80,
		},
	},
},
[107] = 
{
	id=107,
	type=3,
	round=1,
	index=10,
	level=30,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[108] = 
{
	id=108,
	type=3,
	round=1,
	index=11,
	level=33,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[109] = 
{
	id=109,
	type=3,
	round=1,
	index=12,
	level=36,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[110] = 
{
	id=110,
	type=3,
	round=1,
	index=13,
	level=39,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[111] = 
{
	id=111,
	type=3,
	round=1,
	index=14,
	level=42,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[112] = 
{
	id=112,
	type=3,
	round=1,
	index=15,
	level=45,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[113] = 
{
	id=113,
	type=3,
	round=2,
	index=1,
	level=48,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[114] = 
{
	id=114,
	type=3,
	round=2,
	index=2,
	level=51,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[115] = 
{
	id=115,
	type=3,
	round=2,
	index=3,
	level=54,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[116] = 
{
	id=116,
	type=3,
	round=2,
	index=4,
	level=57,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[117] = 
{
	id=117,
	type=3,
	round=2,
	index=5,
	level=60,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[118] = 
{
	id=118,
	type=3,
	round=2,
	index=6,
	level=63,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[119] = 
{
	id=119,
	type=3,
	round=2,
	index=7,
	level=66,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[120] = 
{
	id=120,
	type=3,
	round=2,
	index=8,
	level=69,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[121] = 
{
	id=121,
	type=3,
	round=2,
	index=9,
	level=72,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[122] = 
{
	id=122,
	type=3,
	round=2,
	index=10,
	level=75,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[123] = 
{
	id=123,
	type=3,
	round=2,
	index=11,
	level=78,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[124] = 
{
	id=124,
	type=3,
	round=2,
	index=12,
	level=81,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[125] = 
{
	id=125,
	type=3,
	round=2,
	index=13,
	level=84,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[126] = 
{
	id=126,
	type=3,
	round=2,
	index=14,
	level=87,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[127] = 
{
	id=127,
	type=3,
	round=2,
	index=15,
	level=90,
	free_rewards=
	{
		id=12,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=200,
		},
	},
},
[128] = 
{
	id=128,
	type=3,
	round=3,
	index=1,
	level=93,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[129] = 
{
	id=129,
	type=3,
	round=3,
	index=2,
	level=96,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[130] = 
{
	id=130,
	type=3,
	round=3,
	index=3,
	level=99,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[131] = 
{
	id=131,
	type=3,
	round=3,
	index=4,
	level=102,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[132] = 
{
	id=132,
	type=3,
	round=3,
	index=5,
	level=105,
	free_rewards=
	{
		id=11,
		num=15,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=150,
		},
	},
},
[133] = 
{
	id=133,
	type=3,
	round=3,
	index=6,
	level=108,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[134] = 
{
	id=134,
	type=3,
	round=3,
	index=7,
	level=111,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[135] = 
{
	id=135,
	type=3,
	round=3,
	index=8,
	level=114,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[136] = 
{
	id=136,
	type=3,
	round=3,
	index=9,
	level=117,
	free_rewards=
	{
		id=12,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=200,
		},
	},
},
[137] = 
{
	id=137,
	type=3,
	round=3,
	index=10,
	level=120,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[138] = 
{
	id=138,
	type=3,
	round=3,
	index=11,
	level=123,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[139] = 
{
	id=139,
	type=3,
	round=3,
	index=12,
	level=126,
	free_rewards=
	{
		id=12,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=200,
		},
	},
},
[140] = 
{
	id=140,
	type=3,
	round=3,
	index=13,
	level=129,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[141] = 
{
	id=141,
	type=3,
	round=3,
	index=14,
	level=132,
	free_rewards=
	{
		id=11,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=300,
		},
	},
},
[142] = 
{
	id=142,
	type=3,
	round=3,
	index=15,
	level=135,
	free_rewards=
	{
		id=12,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=200,
		},
	},
},
[143] = 
{
	id=143,
	type=5,
	round=1,
	index=1,
	level=50,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
},
[144] = 
{
	id=144,
	type=5,
	round=1,
	index=2,
	level=60,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
},
[145] = 
{
	id=145,
	type=5,
	round=1,
	index=3,
	level=70,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[146] = 
{
	id=146,
	type=5,
	round=1,
	index=4,
	level=80,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
},
[147] = 
{
	id=147,
	type=5,
	round=1,
	index=5,
	level=90,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
},
[148] = 
{
	id=148,
	type=5,
	round=1,
	index=6,
	level=100,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[149] = 
{
	id=149,
	type=5,
	round=1,
	index=7,
	level=110,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[150] = 
{
	id=150,
	type=5,
	round=1,
	index=8,
	level=120,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[151] = 
{
	id=151,
	type=5,
	round=1,
	index=9,
	level=130,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[152] = 
{
	id=152,
	type=5,
	round=1,
	index=10,
	level=140,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[153] = 
{
	id=153,
	type=5,
	round=1,
	index=11,
	level=150,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[154] = 
{
	id=154,
	type=5,
	round=1,
	index=12,
	level=160,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[155] = 
{
	id=155,
	type=5,
	round=1,
	index=13,
	level=170,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[156] = 
{
	id=156,
	type=5,
	round=1,
	index=14,
	level=180,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[157] = 
{
	id=157,
	type=5,
	round=1,
	index=15,
	level=190,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[158] = 
{
	id=158,
	type=5,
	round=1,
	index=16,
	level=200,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=15,
		},
	},
},
[159] = 
{
	id=159,
	type=5,
	round=1,
	index=17,
	level=210,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=15,
		},
	},
},
[160] = 
{
	id=160,
	type=5,
	round=1,
	index=18,
	level=220,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=30,
		},
	},
},
[161] = 
{
	id=161,
	type=5,
	round=1,
	index=19,
	level=230,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=15,
		},
	},
},
[162] = 
{
	id=162,
	type=5,
	round=1,
	index=20,
	level=240,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=15,
		},
	},
},
[163] = 
{
	id=163,
	type=5,
	round=1,
	index=21,
	level=250,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=30,
		},
	},
},
[164] = 
{
	id=164,
	type=5,
	round=1,
	index=22,
	level=260,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[165] = 
{
	id=165,
	type=5,
	round=1,
	index=23,
	level=270,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[166] = 
{
	id=166,
	type=5,
	round=1,
	index=24,
	level=280,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=40,
		},
	},
},
[167] = 
{
	id=167,
	type=5,
	round=1,
	index=25,
	level=290,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[168] = 
{
	id=168,
	type=5,
	round=1,
	index=26,
	level=300,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[169] = 
{
	id=169,
	type=5,
	round=1,
	index=27,
	level=310,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=50,
		},
	},
},
[170] = 
{
	id=170,
	type=5,
	round=2,
	index=1,
	level=320,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[171] = 
{
	id=171,
	type=5,
	round=2,
	index=2,
	level=330,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[172] = 
{
	id=172,
	type=5,
	round=2,
	index=3,
	level=340,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=40,
		},
	},
},
[173] = 
{
	id=173,
	type=5,
	round=2,
	index=4,
	level=350,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[174] = 
{
	id=174,
	type=5,
	round=2,
	index=5,
	level=360,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[175] = 
{
	id=175,
	type=5,
	round=2,
	index=6,
	level=370,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=40,
		},
	},
},
[176] = 
{
	id=176,
	type=5,
	round=2,
	index=7,
	level=380,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[177] = 
{
	id=177,
	type=5,
	round=2,
	index=8,
	level=390,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[178] = 
{
	id=178,
	type=5,
	round=2,
	index=9,
	level=400,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=40,
		},
	},
},
[179] = 
{
	id=179,
	type=5,
	round=2,
	index=10,
	level=410,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[180] = 
{
	id=180,
	type=5,
	round=2,
	index=11,
	level=420,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[181] = 
{
	id=181,
	type=5,
	round=2,
	index=12,
	level=430,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=40,
		},
	},
},
[182] = 
{
	id=182,
	type=5,
	round=2,
	index=13,
	level=440,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[183] = 
{
	id=183,
	type=5,
	round=2,
	index=14,
	level=450,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[184] = 
{
	id=184,
	type=5,
	round=2,
	index=15,
	level=460,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=40,
		},
	},
},
[185] = 
{
	id=185,
	type=5,
	round=2,
	index=16,
	level=470,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=30,
		},
	},
},
[186] = 
{
	id=186,
	type=5,
	round=2,
	index=17,
	level=480,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=30,
		},
	},
},
[187] = 
{
	id=187,
	type=5,
	round=2,
	index=18,
	level=490,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=60,
		},
	},
},
[188] = 
{
	id=188,
	type=6,
	round=1,
	index=1,
	level=10,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[189] = 
{
	id=189,
	type=6,
	round=1,
	index=2,
	level=20,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[190] = 
{
	id=190,
	type=6,
	round=1,
	index=3,
	level=30,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[191] = 
{
	id=191,
	type=6,
	round=1,
	index=4,
	level=40,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[192] = 
{
	id=192,
	type=6,
	round=1,
	index=5,
	level=50,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[193] = 
{
	id=193,
	type=6,
	round=1,
	index=6,
	level=55,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[194] = 
{
	id=194,
	type=6,
	round=1,
	index=7,
	level=60,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[195] = 
{
	id=195,
	type=6,
	round=1,
	index=8,
	level=65,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[196] = 
{
	id=196,
	type=6,
	round=1,
	index=9,
	level=70,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[197] = 
{
	id=197,
	type=6,
	round=1,
	index=10,
	level=75,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[198] = 
{
	id=198,
	type=6,
	round=1,
	index=11,
	level=80,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[199] = 
{
	id=199,
	type=6,
	round=1,
	index=12,
	level=85,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[200] = 
{
	id=200,
	type=6,
	round=1,
	index=13,
	level=90,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[201] = 
{
	id=201,
	type=6,
	round=1,
	index=14,
	level=95,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[202] = 
{
	id=202,
	type=6,
	round=1,
	index=15,
	level=100,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[203] = 
{
	id=203,
	type=6,
	round=2,
	index=1,
	level=103,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[204] = 
{
	id=204,
	type=6,
	round=2,
	index=2,
	level=106,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[205] = 
{
	id=205,
	type=6,
	round=2,
	index=3,
	level=109,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[206] = 
{
	id=206,
	type=6,
	round=2,
	index=4,
	level=112,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[207] = 
{
	id=207,
	type=6,
	round=2,
	index=5,
	level=115,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[208] = 
{
	id=208,
	type=6,
	round=2,
	index=6,
	level=118,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[209] = 
{
	id=209,
	type=6,
	round=2,
	index=7,
	level=121,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[210] = 
{
	id=210,
	type=6,
	round=2,
	index=8,
	level=124,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[211] = 
{
	id=211,
	type=6,
	round=2,
	index=9,
	level=127,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[212] = 
{
	id=212,
	type=6,
	round=2,
	index=10,
	level=130,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=500,
		},
	},
},
[213] = 
{
	id=213,
	type=6,
	round=2,
	index=11,
	level=133,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=600,
		},
	},
},
[214] = 
{
	id=214,
	type=6,
	round=2,
	index=12,
	level=136,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=600,
		},
	},
},
[215] = 
{
	id=215,
	type=6,
	round=2,
	index=13,
	level=140,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=600,
		},
	},
},
[216] = 
{
	id=216,
	type=6,
	round=2,
	index=14,
	level=145,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=600,
		},
	},
},
[217] = 
{
	id=217,
	type=6,
	round=2,
	index=15,
	level=150,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=600,
		},
	},
},
[218] = 
{
	id=218,
	type=7,
	round=1,
	index=1,
	level=10,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[219] = 
{
	id=219,
	type=7,
	round=1,
	index=2,
	level=20,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[220] = 
{
	id=220,
	type=7,
	round=1,
	index=3,
	level=30,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=400,
		},
	},
},
[221] = 
{
	id=221,
	type=7,
	round=1,
	index=4,
	level=40,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[222] = 
{
	id=222,
	type=7,
	round=1,
	index=5,
	level=50,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[223] = 
{
	id=223,
	type=7,
	round=1,
	index=6,
	level=60,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=400,
		},
	},
},
[224] = 
{
	id=224,
	type=7,
	round=1,
	index=7,
	level=70,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[225] = 
{
	id=225,
	type=7,
	round=1,
	index=8,
	level=80,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[226] = 
{
	id=226,
	type=7,
	round=1,
	index=9,
	level=90,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=400,
		},
	},
},
[227] = 
{
	id=227,
	type=7,
	round=1,
	index=10,
	level=100,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[228] = 
{
	id=228,
	type=7,
	round=1,
	index=11,
	level=110,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[229] = 
{
	id=229,
	type=7,
	round=1,
	index=12,
	level=120,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=400,
		},
	},
},
[230] = 
{
	id=230,
	type=7,
	round=1,
	index=13,
	level=130,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[231] = 
{
	id=231,
	type=7,
	round=1,
	index=14,
	level=140,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=100,
		},
	},
},
[232] = 
{
	id=232,
	type=7,
	round=1,
	index=15,
	level=150,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=400,
		},
	},
},
[233] = 
{
	id=233,
	type=7,
	round=2,
	index=1,
	level=160,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[234] = 
{
	id=234,
	type=7,
	round=2,
	index=2,
	level=170,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[235] = 
{
	id=235,
	type=7,
	round=2,
	index=3,
	level=180,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=500,
		},
	},
},
[236] = 
{
	id=236,
	type=7,
	round=2,
	index=4,
	level=190,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[237] = 
{
	id=237,
	type=7,
	round=2,
	index=5,
	level=200,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[238] = 
{
	id=238,
	type=7,
	round=2,
	index=6,
	level=210,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=500,
		},
	},
},
[239] = 
{
	id=239,
	type=7,
	round=2,
	index=7,
	level=220,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[240] = 
{
	id=240,
	type=7,
	round=2,
	index=8,
	level=230,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[241] = 
{
	id=241,
	type=7,
	round=2,
	index=9,
	level=240,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=500,
		},
	},
},
[242] = 
{
	id=242,
	type=7,
	round=2,
	index=10,
	level=250,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[243] = 
{
	id=243,
	type=7,
	round=2,
	index=11,
	level=260,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[244] = 
{
	id=244,
	type=7,
	round=2,
	index=12,
	level=270,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=500,
		},
	},
},
[245] = 
{
	id=245,
	type=7,
	round=2,
	index=13,
	level=280,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[246] = 
{
	id=246,
	type=7,
	round=2,
	index=14,
	level=290,
	free_rewards=
	{
		id=37,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=150,
		},
	},
},
[247] = 
{
	id=247,
	type=7,
	round=2,
	index=15,
	level=300,
	free_rewards=
	{
		id=37,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=37,
			num=500,
		},
	},
},
[248] = 
{
	id=248,
	type=8,
	round=1,
	index=1,
	level=0,
	free_rewards=
	{
		id=1,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=6011,
			num=1,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[249] = 
{
	id=249,
	type=8,
	round=1,
	index=2,
	level=200,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[250] = 
{
	id=250,
	type=8,
	round=1,
	index=3,
	level=500,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[251] = 
{
	id=251,
	type=8,
	round=1,
	index=4,
	level=700,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[252] = 
{
	id=252,
	type=8,
	round=1,
	index=5,
	level=1000,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[253] = 
{
	id=253,
	type=8,
	round=1,
	index=6,
	level=1300,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[254] = 
{
	id=254,
	type=8,
	round=1,
	index=7,
	level=1600,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[255] = 
{
	id=255,
	type=8,
	round=1,
	index=8,
	level=1900,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[256] = 
{
	id=256,
	type=8,
	round=1,
	index=9,
	level=2200,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[257] = 
{
	id=257,
	type=8,
	round=1,
	index=10,
	level=2500,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[258] = 
{
	id=258,
	type=8,
	round=1,
	index=11,
	level=2800,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[259] = 
{
	id=259,
	type=8,
	round=1,
	index=12,
	level=3100,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[260] = 
{
	id=260,
	type=8,
	round=1,
	index=13,
	level=3400,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[261] = 
{
	id=261,
	type=8,
	round=1,
	index=14,
	level=3700,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[262] = 
{
	id=262,
	type=8,
	round=1,
	index=15,
	level=4000,
	free_rewards=
	{
		id=14,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=14,
			num=200,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[263] = 
{
	id=263,
	type=8,
	round=1,
	index=16,
	level=4300,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[264] = 
{
	id=264,
	type=8,
	round=1,
	index=17,
	level=4600,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[265] = 
{
	id=265,
	type=8,
	round=1,
	index=18,
	level=4900,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[266] = 
{
	id=266,
	type=8,
	round=1,
	index=19,
	level=5200,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[267] = 
{
	id=267,
	type=8,
	round=1,
	index=20,
	level=5500,
	free_rewards=
	{
		id=17,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=17,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[268] = 
{
	id=268,
	type=8,
	round=1,
	index=21,
	level=5800,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[269] = 
{
	id=269,
	type=8,
	round=1,
	index=22,
	level=6100,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[270] = 
{
	id=270,
	type=8,
	round=1,
	index=23,
	level=6400,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[271] = 
{
	id=271,
	type=8,
	round=1,
	index=24,
	level=6700,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[272] = 
{
	id=272,
	type=8,
	round=1,
	index=25,
	level=7000,
	free_rewards=
	{
		id=9,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=9,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[273] = 
{
	id=273,
	type=8,
	round=1,
	index=26,
	level=7300,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[274] = 
{
	id=274,
	type=8,
	round=1,
	index=27,
	level=7600,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[275] = 
{
	id=275,
	type=8,
	round=1,
	index=28,
	level=7900,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[276] = 
{
	id=276,
	type=8,
	round=1,
	index=29,
	level=8200,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[277] = 
{
	id=277,
	type=8,
	round=1,
	index=30,
	level=8500,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[278] = 
{
	id=278,
	type=8,
	round=1,
	index=31,
	level=8800,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[279] = 
{
	id=279,
	type=8,
	round=1,
	index=32,
	level=9100,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[280] = 
{
	id=280,
	type=8,
	round=1,
	index=33,
	level=9400,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[281] = 
{
	id=281,
	type=8,
	round=1,
	index=34,
	level=9700,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[282] = 
{
	id=282,
	type=8,
	round=1,
	index=35,
	level=10000,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[283] = 
{
	id=283,
	type=8,
	round=1,
	index=36,
	level=10300,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[284] = 
{
	id=284,
	type=8,
	round=1,
	index=37,
	level=10600,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[285] = 
{
	id=285,
	type=8,
	round=1,
	index=38,
	level=10900,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[286] = 
{
	id=286,
	type=8,
	round=1,
	index=39,
	level=11200,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[287] = 
{
	id=287,
	type=8,
	round=1,
	index=40,
	level=11500,
	free_rewards=
	{
		id=14,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=14,
			num=200,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[288] = 
{
	id=288,
	type=8,
	round=1,
	index=41,
	level=11800,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[289] = 
{
	id=289,
	type=8,
	round=1,
	index=42,
	level=12100,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[290] = 
{
	id=290,
	type=8,
	round=1,
	index=43,
	level=12400,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[291] = 
{
	id=291,
	type=8,
	round=1,
	index=44,
	level=12700,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[292] = 
{
	id=292,
	type=8,
	round=1,
	index=45,
	level=13000,
	free_rewards=
	{
		id=17,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=17,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[293] = 
{
	id=293,
	type=8,
	round=1,
	index=46,
	level=13300,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[294] = 
{
	id=294,
	type=8,
	round=1,
	index=47,
	level=13600,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[295] = 
{
	id=295,
	type=8,
	round=1,
	index=48,
	level=14000,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[296] = 
{
	id=296,
	type=8,
	round=1,
	index=49,
	level=14500,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[297] = 
{
	id=297,
	type=8,
	round=1,
	index=50,
	level=15000,
	free_rewards=
	{
		id=9,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=9,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[298] = 
{
	id=298,
	type=8,
	round=1,
	index=51,
	level=16000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[299] = 
{
	id=299,
	type=8,
	round=1,
	index=52,
	level=17000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[300] = 
{
	id=300,
	type=8,
	round=1,
	index=53,
	level=18000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[301] = 
{
	id=301,
	type=8,
	round=1,
	index=54,
	level=19000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[302] = 
{
	id=302,
	type=8,
	round=1,
	index=55,
	level=20000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[303] = 
{
	id=303,
	type=8,
	round=1,
	index=56,
	level=21000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[304] = 
{
	id=304,
	type=8,
	round=1,
	index=57,
	level=22000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[305] = 
{
	id=305,
	type=8,
	round=1,
	index=58,
	level=23000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[306] = 
{
	id=306,
	type=8,
	round=1,
	index=59,
	level=24000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[307] = 
{
	id=307,
	type=8,
	round=1,
	index=60,
	level=25000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[308] = 
{
	id=308,
	type=8,
	round=1,
	index=61,
	level=26000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[309] = 
{
	id=309,
	type=8,
	round=1,
	index=62,
	level=27000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[310] = 
{
	id=310,
	type=8,
	round=1,
	index=63,
	level=28000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[311] = 
{
	id=311,
	type=8,
	round=1,
	index=64,
	level=29000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[312] = 
{
	id=312,
	type=8,
	round=1,
	index=65,
	level=30000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[313] = 
{
	id=313,
	type=8,
	round=1,
	index=66,
	level=31000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[314] = 
{
	id=314,
	type=8,
	round=1,
	index=67,
	level=32000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[315] = 
{
	id=315,
	type=8,
	round=1,
	index=68,
	level=33000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[316] = 
{
	id=316,
	type=8,
	round=1,
	index=69,
	level=34000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[317] = 
{
	id=317,
	type=8,
	round=1,
	index=70,
	level=35000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[318] = 
{
	id=318,
	type=8,
	round=1,
	index=71,
	level=36000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[319] = 
{
	id=319,
	type=8,
	round=1,
	index=72,
	level=37000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[320] = 
{
	id=320,
	type=8,
	round=1,
	index=73,
	level=38000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[321] = 
{
	id=321,
	type=8,
	round=1,
	index=74,
	level=39000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[322] = 
{
	id=322,
	type=8,
	round=1,
	index=75,
	level=40000,
	free_rewards=
	{
		id=50,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=20,
		},
	},
},
[323] = 
{
	id=323,
	type=9,
	round=1,
	index=1,
	level=0,
	free_rewards=
	{
		id=1,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=6011,
			num=1,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[324] = 
{
	id=324,
	type=9,
	round=1,
	index=2,
	level=200,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[325] = 
{
	id=325,
	type=9,
	round=1,
	index=3,
	level=500,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[326] = 
{
	id=326,
	type=9,
	round=1,
	index=4,
	level=700,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[327] = 
{
	id=327,
	type=9,
	round=1,
	index=5,
	level=1000,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[328] = 
{
	id=328,
	type=9,
	round=1,
	index=6,
	level=1300,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[329] = 
{
	id=329,
	type=9,
	round=1,
	index=7,
	level=1600,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[330] = 
{
	id=330,
	type=9,
	round=1,
	index=8,
	level=1900,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[331] = 
{
	id=331,
	type=9,
	round=1,
	index=9,
	level=2200,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[332] = 
{
	id=332,
	type=9,
	round=1,
	index=10,
	level=2500,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[333] = 
{
	id=333,
	type=9,
	round=1,
	index=11,
	level=2800,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[334] = 
{
	id=334,
	type=9,
	round=1,
	index=12,
	level=3100,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[335] = 
{
	id=335,
	type=9,
	round=1,
	index=13,
	level=3400,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[336] = 
{
	id=336,
	type=9,
	round=1,
	index=14,
	level=3700,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[337] = 
{
	id=337,
	type=9,
	round=1,
	index=15,
	level=4000,
	free_rewards=
	{
		id=14,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=14,
			num=200,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[338] = 
{
	id=338,
	type=9,
	round=1,
	index=16,
	level=4300,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[339] = 
{
	id=339,
	type=9,
	round=1,
	index=17,
	level=4600,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[340] = 
{
	id=340,
	type=9,
	round=1,
	index=18,
	level=4900,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[341] = 
{
	id=341,
	type=9,
	round=1,
	index=19,
	level=5200,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[342] = 
{
	id=342,
	type=9,
	round=1,
	index=20,
	level=5500,
	free_rewards=
	{
		id=17,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=17,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[343] = 
{
	id=343,
	type=9,
	round=1,
	index=21,
	level=5800,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[344] = 
{
	id=344,
	type=9,
	round=1,
	index=22,
	level=6100,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[345] = 
{
	id=345,
	type=9,
	round=1,
	index=23,
	level=6400,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[346] = 
{
	id=346,
	type=9,
	round=1,
	index=24,
	level=6700,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[347] = 
{
	id=347,
	type=9,
	round=1,
	index=25,
	level=7000,
	free_rewards=
	{
		id=9,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=9,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[348] = 
{
	id=348,
	type=9,
	round=1,
	index=26,
	level=7300,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[349] = 
{
	id=349,
	type=9,
	round=1,
	index=27,
	level=7600,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[350] = 
{
	id=350,
	type=9,
	round=1,
	index=28,
	level=7900,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[351] = 
{
	id=351,
	type=9,
	round=1,
	index=29,
	level=8200,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[352] = 
{
	id=352,
	type=9,
	round=1,
	index=30,
	level=8500,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[353] = 
{
	id=353,
	type=10,
	round=1,
	index=1,
	level=0,
	free_rewards=
	{
		id=1,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=6011,
			num=1,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[354] = 
{
	id=354,
	type=10,
	round=1,
	index=2,
	level=200,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[355] = 
{
	id=355,
	type=10,
	round=1,
	index=3,
	level=500,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[356] = 
{
	id=356,
	type=10,
	round=1,
	index=4,
	level=700,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[357] = 
{
	id=357,
	type=10,
	round=1,
	index=5,
	level=1000,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[358] = 
{
	id=358,
	type=10,
	round=1,
	index=6,
	level=1300,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[359] = 
{
	id=359,
	type=10,
	round=1,
	index=7,
	level=1600,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[360] = 
{
	id=360,
	type=10,
	round=1,
	index=8,
	level=1900,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[361] = 
{
	id=361,
	type=10,
	round=1,
	index=9,
	level=2200,
	free_rewards=
	{
		id=11,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=50,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[362] = 
{
	id=362,
	type=10,
	round=1,
	index=10,
	level=2500,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[363] = 
{
	id=363,
	type=10,
	round=1,
	index=11,
	level=2800,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[364] = 
{
	id=364,
	type=10,
	round=1,
	index=12,
	level=3100,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[365] = 
{
	id=365,
	type=10,
	round=1,
	index=13,
	level=3400,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[366] = 
{
	id=366,
	type=10,
	round=1,
	index=14,
	level=3700,
	free_rewards=
	{
		id=15,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=15,
			num=2000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[367] = 
{
	id=367,
	type=10,
	round=1,
	index=15,
	level=4000,
	free_rewards=
	{
		id=14,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=14,
			num=200,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[368] = 
{
	id=368,
	type=10,
	round=1,
	index=16,
	level=4300,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[369] = 
{
	id=369,
	type=10,
	round=1,
	index=17,
	level=4600,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[370] = 
{
	id=370,
	type=10,
	round=1,
	index=18,
	level=4900,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[371] = 
{
	id=371,
	type=10,
	round=1,
	index=19,
	level=5200,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[372] = 
{
	id=372,
	type=10,
	round=1,
	index=20,
	level=5500,
	free_rewards=
	{
		id=17,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=17,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[373] = 
{
	id=373,
	type=10,
	round=1,
	index=21,
	level=5800,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[374] = 
{
	id=374,
	type=10,
	round=1,
	index=22,
	level=6100,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[375] = 
{
	id=375,
	type=10,
	round=1,
	index=23,
	level=6400,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[376] = 
{
	id=376,
	type=10,
	round=1,
	index=24,
	level=6700,
	free_rewards=
	{
		id=8,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=8,
			num=1000,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[377] = 
{
	id=377,
	type=10,
	round=1,
	index=25,
	level=7000,
	free_rewards=
	{
		id=9,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=9,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[378] = 
{
	id=378,
	type=10,
	round=1,
	index=26,
	level=7300,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[379] = 
{
	id=379,
	type=10,
	round=1,
	index=27,
	level=7600,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[380] = 
{
	id=380,
	type=10,
	round=1,
	index=28,
	level=7900,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[381] = 
{
	id=381,
	type=10,
	round=1,
	index=29,
	level=8200,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[382] = 
{
	id=382,
	type=10,
	round=1,
	index=30,
	level=8500,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=100,
		},
	},
},
[383] = 
{
	id=383,
	type=11,
	round=1,
	index=1,
	level=0,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=300,
		},
	},
},
[384] = 
{
	id=384,
	type=11,
	round=1,
	index=2,
	level=5,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[385] = 
{
	id=385,
	type=11,
	round=1,
	index=3,
	level=10,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[386] = 
{
	id=386,
	type=11,
	round=1,
	index=4,
	level=15,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[387] = 
{
	id=387,
	type=11,
	round=1,
	index=5,
	level=20,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[388] = 
{
	id=388,
	type=11,
	round=1,
	index=6,
	level=25,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
},
[389] = 
{
	id=389,
	type=11,
	round=1,
	index=7,
	level=30,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[390] = 
{
	id=390,
	type=11,
	round=1,
	index=8,
	level=35,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[391] = 
{
	id=391,
	type=11,
	round=1,
	index=9,
	level=40,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[392] = 
{
	id=392,
	type=11,
	round=1,
	index=10,
	level=45,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[393] = 
{
	id=393,
	type=11,
	round=1,
	index=11,
	level=50,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
},
[394] = 
{
	id=394,
	type=11,
	round=1,
	index=12,
	level=55,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[395] = 
{
	id=395,
	type=11,
	round=1,
	index=13,
	level=60,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[396] = 
{
	id=396,
	type=11,
	round=1,
	index=14,
	level=65,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[397] = 
{
	id=397,
	type=11,
	round=1,
	index=15,
	level=70,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[398] = 
{
	id=398,
	type=11,
	round=1,
	index=16,
	level=75,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=5,
		},
	},
},
[399] = 
{
	id=399,
	type=11,
	round=1,
	index=17,
	level=80,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[400] = 
{
	id=400,
	type=11,
	round=1,
	index=18,
	level=85,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[401] = 
{
	id=401,
	type=11,
	round=1,
	index=19,
	level=90,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[402] = 
{
	id=402,
	type=11,
	round=1,
	index=20,
	level=95,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[403] = 
{
	id=403,
	type=11,
	round=1,
	index=21,
	level=100,
	free_rewards=
	{
		id=39,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[404] = 
{
	id=404,
	type=11,
	round=1,
	index=22,
	level=105,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[405] = 
{
	id=405,
	type=11,
	round=1,
	index=23,
	level=110,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[406] = 
{
	id=406,
	type=11,
	round=1,
	index=24,
	level=115,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[407] = 
{
	id=407,
	type=11,
	round=1,
	index=25,
	level=120,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[408] = 
{
	id=408,
	type=11,
	round=1,
	index=26,
	level=125,
	free_rewards=
	{
		id=39,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[409] = 
{
	id=409,
	type=11,
	round=1,
	index=27,
	level=130,
	free_rewards=
	{
		id=50,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=150,
		},
	},
},
[410] = 
{
	id=410,
	type=11,
	round=1,
	index=28,
	level=135,
	free_rewards=
	{
		id=50,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=150,
		},
	},
},
[411] = 
{
	id=411,
	type=11,
	round=1,
	index=29,
	level=140,
	free_rewards=
	{
		id=50,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=150,
		},
	},
},
[412] = 
{
	id=412,
	type=11,
	round=1,
	index=30,
	level=145,
	free_rewards=
	{
		id=50,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=150,
		},
	},
},
[413] = 
{
	id=413,
	type=11,
	round=1,
	index=31,
	level=150,
	free_rewards=
	{
		id=39,
		num=3,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=15,
		},
	},
},
[414] = 
{
	id=414,
	type=12,
	round=1,
	index=1,
	level=0,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=300,
		},
	},
},
[415] = 
{
	id=415,
	type=12,
	round=1,
	index=2,
	level=5,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[416] = 
{
	id=416,
	type=12,
	round=1,
	index=3,
	level=10,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[417] = 
{
	id=417,
	type=12,
	round=1,
	index=4,
	level=15,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[418] = 
{
	id=418,
	type=12,
	round=1,
	index=5,
	level=20,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=50,
		},
	},
},
[419] = 
{
	id=419,
	type=12,
	round=1,
	index=6,
	level=25,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=300,
		},
	},
},
[420] = 
{
	id=420,
	type=12,
	round=1,
	index=7,
	level=30,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=50,
		},
	},
},
[421] = 
{
	id=421,
	type=12,
	round=1,
	index=8,
	level=35,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=50,
		},
	},
},
[422] = 
{
	id=422,
	type=12,
	round=1,
	index=9,
	level=40,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=50,
		},
	},
},
[423] = 
{
	id=423,
	type=12,
	round=1,
	index=10,
	level=45,
	free_rewards=
	{
		id=80,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=50,
		},
	},
},
[424] = 
{
	id=424,
	type=12,
	round=1,
	index=11,
	level=50,
	free_rewards=
	{
		id=3,
		num=100,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[425] = 
{
	id=425,
	type=12,
	round=1,
	index=12,
	level=55,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=50,
		},
	},
},
[426] = 
{
	id=426,
	type=12,
	round=1,
	index=13,
	level=60,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=50,
		},
	},
},
[427] = 
{
	id=427,
	type=12,
	round=1,
	index=14,
	level=65,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=50,
		},
	},
},
[428] = 
{
	id=428,
	type=12,
	round=1,
	index=15,
	level=70,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=50,
		},
	},
},
[429] = 
{
	id=429,
	type=12,
	round=1,
	index=16,
	level=75,
	free_rewards=
	{
		id=3,
		num=150,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=600,
		},
	},
},
[430] = 
{
	id=430,
	type=12,
	round=1,
	index=17,
	level=80,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[431] = 
{
	id=431,
	type=12,
	round=1,
	index=18,
	level=85,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[432] = 
{
	id=432,
	type=12,
	round=1,
	index=19,
	level=90,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[433] = 
{
	id=433,
	type=12,
	round=1,
	index=20,
	level=95,
	free_rewards=
	{
		id=50,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[434] = 
{
	id=434,
	type=12,
	round=1,
	index=21,
	level=100,
	free_rewards=
	{
		id=3,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[435] = 
{
	id=435,
	type=12,
	round=1,
	index=22,
	level=105,
	free_rewards=
	{
		id=80,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	},
},
[436] = 
{
	id=436,
	type=12,
	round=1,
	index=23,
	level=110,
	free_rewards=
	{
		id=80,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	},
},
[437] = 
{
	id=437,
	type=12,
	round=1,
	index=24,
	level=115,
	free_rewards=
	{
		id=80,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	},
},
[438] = 
{
	id=438,
	type=12,
	round=1,
	index=25,
	level=120,
	free_rewards=
	{
		id=80,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=100,
		},
	},
},
[439] = 
{
	id=439,
	type=12,
	round=1,
	index=26,
	level=125,
	free_rewards=
	{
		id=3,
		num=200,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=800,
		},
	},
},
[440] = 
{
	id=440,
	type=12,
	round=1,
	index=27,
	level=130,
	free_rewards=
	{
		id=33,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=100,
		},
	},
},
[441] = 
{
	id=441,
	type=12,
	round=1,
	index=28,
	level=135,
	free_rewards=
	{
		id=33,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=100,
		},
	},
},
[442] = 
{
	id=442,
	type=12,
	round=1,
	index=29,
	level=140,
	free_rewards=
	{
		id=33,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=100,
		},
	},
},
[443] = 
{
	id=443,
	type=12,
	round=1,
	index=30,
	level=145,
	free_rewards=
	{
		id=33,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=100,
		},
	},
},
[444] = 
{
	id=444,
	type=12,
	round=1,
	index=31,
	level=150,
	free_rewards=
	{
		id=3,
		num=300,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=1200,
		},
	},
},
[445] = 
{
	id=445,
	type=13,
	round=1,
	index=1,
	level=0,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=1,
			num=300,
		},
	},
},
[446] = 
{
	id=446,
	type=13,
	round=1,
	index=2,
	level=30,
	free_rewards=
	{
		id=50,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=50,
			num=100,
		},
	},
},
[447] = 
{
	id=447,
	type=13,
	round=1,
	index=3,
	level=60,
	free_rewards=
	{
		id=3,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=300,
		},
	},
},
[448] = 
{
	id=448,
	type=13,
	round=1,
	index=4,
	level=90,
	free_rewards=
	{
		id=80,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=200,
		},
	},
},
[449] = 
{
	id=449,
	type=13,
	round=1,
	index=5,
	level=120,
	free_rewards=
	{
		id=33,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=200,
		},
	},
},
[450] = 
{
	id=450,
	type=13,
	round=1,
	index=6,
	level=150,
	free_rewards=
	{
		id=43,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=43,
			num=20,
		},
	},
},
[451] = 
{
	id=451,
	type=13,
	round=1,
	index=7,
	level=180,
	free_rewards=
	{
		id=11,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=100,
		},
	},
},
[452] = 
{
	id=452,
	type=13,
	round=1,
	index=8,
	level=210,
	free_rewards=
	{
		id=12,
		num=5,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=50,
		},
	},
},
[453] = 
{
	id=453,
	type=13,
	round=1,
	index=9,
	level=240,
	free_rewards=
	{
		id=17,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=17,
			num=10,
		},
	},
},
[454] = 
{
	id=454,
	type=13,
	round=1,
	index=10,
	level=270,
	free_rewards=
	{
		id=39,
		num=1,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=10,
		},
	},
},
[455] = 
{
	id=455,
	type=13,
	round=1,
	index=11,
	level=300,
	free_rewards=
	{
		id=44,
		num=3,
	},
	pay_rewards=
	{
	
		{
			id=44,
			num=30,
		},
	},
},
[456] = 
{
	id=456,
	type=13,
	round=1,
	index=12,
	level=330,
	free_rewards=
	{
		id=51,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=51,
			num=20,
		},
	},
},
[457] = 
{
	id=457,
	type=13,
	round=1,
	index=13,
	level=360,
	free_rewards=
	{
		id=3,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=3,
			num=500,
		},
	},
},
[458] = 
{
	id=458,
	type=13,
	round=1,
	index=14,
	level=390,
	free_rewards=
	{
		id=80,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=80,
			num=300,
		},
	},
},
[459] = 
{
	id=459,
	type=13,
	round=1,
	index=15,
	level=420,
	free_rewards=
	{
		id=33,
		num=30,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=300,
		},
	},
},
[460] = 
{
	id=460,
	type=13,
	round=1,
	index=16,
	level=450,
	free_rewards=
	{
		id=43,
		num=3,
	},
	pay_rewards=
	{
	
		{
			id=43,
			num=30,
		},
	},
},
[461] = 
{
	id=461,
	type=13,
	round=1,
	index=17,
	level=480,
	free_rewards=
	{
		id=11,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=11,
			num=200,
		},
	},
},
[462] = 
{
	id=462,
	type=13,
	round=1,
	index=18,
	level=510,
	free_rewards=
	{
		id=12,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=12,
			num=100,
		},
	},
},
[463] = 
{
	id=463,
	type=13,
	round=1,
	index=19,
	level=540,
	free_rewards=
	{
		id=17,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=17,
			num=20,
		},
	},
},
[464] = 
{
	id=464,
	type=13,
	round=1,
	index=20,
	level=570,
	free_rewards=
	{
		id=39,
		num=2,
	},
	pay_rewards=
	{
	
		{
			id=39,
			num=20,
		},
	},
},
[465] = 
{
	id=465,
	type=13,
	round=1,
	index=21,
	level=600,
	free_rewards=
	{
		id=44,
		num=8,
	},
	pay_rewards=
	{
	
		{
			id=44,
			num=80,
		},
	},
},
[466] = 
{
	id=466,
	type=14,
	round=1,
	index=1,
	level=1,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=60,
		},
	},
},
[467] = 
{
	id=467,
	type=14,
	round=1,
	index=2,
	level=2,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=43,
			num=6,
		},
	},
},
[468] = 
{
	id=468,
	type=14,
	round=1,
	index=3,
	level=3,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=60,
		},
	},
},
[469] = 
{
	id=469,
	type=14,
	round=1,
	index=4,
	level=4,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=43,
			num=6,
		},
	},
},
[470] = 
{
	id=470,
	type=14,
	round=1,
	index=5,
	level=5,
	free_rewards=
	{
		id=33,
		num=10,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=60,
		},
	},
},
[471] = 
{
	id=471,
	type=14,
	round=1,
	index=6,
	level=6,
	free_rewards=
	{
		id=1,
		num=50,
	},
	pay_rewards=
	{
	
		{
			id=43,
			num=6,
		},
	},
},
[472] = 
{
	id=472,
	type=14,
	round=1,
	index=7,
	level=7,
	free_rewards=
	{
		id=33,
		num=20,
	},
	pay_rewards=
	{
	
		{
			id=33,
			num=120,
		},
	},
},
}
