local Log = require("common/logging")
local Time = require("common/time")

local ActivityConfig = import("config/activity/activity", true)
local DateOpenConfig = import("config/activity/date_open", true)
local ServerOpenConfig = import("config/activity/server_open", true)
local WeekOpenConfig = import("config/activity/week_open", true)

local Root = import("config/root", true)

local M = {}

M.ServerOpenMap = {}

local start_time = Time.TimeStampOfDayTs(Root.OpenServerTime)
local week_begin = Time.TimeStampOfWeek(start_time)
local now_time = os.now()

for _, item in pairs(ServerOpenConfig) do
    local begin_time = start_time + (item.start_offset or 0) + (item.open_day - 1) * Time.Unit.Day
    local end_time = 0 
    if item.duration ~= 0 then 
        end_time = begin_time + item.duration
    end
    if end_time > 0 and end_time + Time.Unit.Day * 30 > now_time then
        local param = {
            activity = item.activity,
            begin_time = begin_time,
            end_time = end_time,
        }
        M.ServerOpenMap[param.activity] = M.ServerOpenMap[param.activity] or {}
        table.insert(M.ServerOpenMap[param.activity], param)
    end
end

for _, item in pairs(WeekOpenConfig) do
    local begin_time = week_begin + item.start_offset + (item.open_week - 1) * Time.Unit.Week + (item.open_day - 1) * Time.Unit.Day
    local end_time = 0
    if item.duration ~= 0 then 
        end_time = begin_time + item.duration
    end
    if end_time > 0 and end_time + Time.Unit.Day * 30 > now_time then
        local param = {
            activity = item.activity,
            begin_time = begin_time,
            end_time = end_time,
        }
        M.ServerOpenMap[param.activity] = M.ServerOpenMap[param.activity] or {}
        table.insert(M.ServerOpenMap[param.activity], param)
    end
end

for _, item in pairs(DateOpenConfig) do
    local begin_time = start_time + (item.server_days - 1) * Time.Unit.Day
    begin_time = math.max(begin_time, item.begin_time)
    if item.end_time > 0 and item.end_time > begin_time and item.end_time + Time.Unit.Day * 30 > now_time then
        local param = {
            activity = item.activity,
            begin_time = begin_time,
            end_time = item.end_time,
        }
        M.ServerOpenMap[param.activity] = M.ServerOpenMap[param.activity] or {}
        table.insert(M.ServerOpenMap[param.activity], param)
    end
end

-- 活动配置
function M.ActivityConfig(id)
    if id == nil then 
        return ActivityConfig
    else 
        return ActivityConfig[id]
    end
end

function M.DateOpenConfig(id)
    if id == nil then
        return DateOpenConfig
    else
        return DateOpenConfig[id]
    end
end

function M.ServerOpenConfigByActivityId(activity_id)
    if activity_id == nil then
        return M.ServerOpenMap
    else
        return M.ServerOpenMap[activity_id]
    end
end

return M