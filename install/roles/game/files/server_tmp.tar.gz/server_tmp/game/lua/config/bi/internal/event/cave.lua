
-- pm.TbBiInternalEventCave



return
{
[1] = 
{
	id=1,
	field="resource",
	name="资源编号id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="goblin_num",
	name="哥布林数量",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="goblin_state",
	name="哥布林状态",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="gather_time",
	name="采集剩余时长",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="status",
	name="完成状态",
	type=0,
	opt=1,
	default_value="",
},
}
