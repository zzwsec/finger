local class = require "utils.class"

local BaseNode = require 'core.BaseNode'

local Condition = class("Condition", BaseNode)

function Condition:ctor(params)
    BaseNode.ctor(self, params)
end

return Condition