
-- pm.TbCompetitionRanks



return
{
[1] = 
{
	id=1,
	type=1,
	rank_range=
	{
	1,
	1,
	},
	mailid=1801,
	box_num=60,
	rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=500,
		},
	
		{
			id=3,
			num=100,
		},
	},
},
[2] = 
{
	id=2,
	type=1,
	rank_range=
	{
	2,
	2,
	},
	mailid=1802,
	box_num=30,
	rewards=
	{
	
		{
			id=39,
			num=8,
		},
	
		{
			id=1,
			num=400,
		},
	
		{
			id=3,
			num=80,
		},
	},
},
[3] = 
{
	id=3,
	type=1,
	rank_range=
	{
	3,
	3,
	},
	mailid=1803,
	box_num=20,
	rewards=
	{
	
		{
			id=39,
			num=7,
		},
	
		{
			id=1,
			num=300,
		},
	
		{
			id=3,
			num=60,
		},
	},
},
[4] = 
{
	id=4,
	type=1,
	rank_range=
	{
	4,
	4,
	},
	mailid=1804,
	box_num=15,
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	
		{
			id=1,
			num=250,
		},
	
		{
			id=3,
			num=50,
		},
	},
},
[5] = 
{
	id=5,
	type=1,
	rank_range=
	{
	5,
	5,
	},
	mailid=1805,
	box_num=10,
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	
		{
			id=1,
			num=200,
		},
	
		{
			id=3,
			num=40,
		},
	},
},
[6] = 
{
	id=6,
	type=1,
	rank_range=
	{
	6,
	6,
	},
	mailid=1806,
	box_num=8,
	rewards=
	{
	
		{
			id=39,
			num=4,
		},
	
		{
			id=1,
			num=200,
		},
	
		{
			id=3,
			num=35,
		},
	},
},
[7] = 
{
	id=7,
	type=1,
	rank_range=
	{
	7,
	7,
	},
	mailid=1807,
	box_num=5,
	rewards=
	{
	
		{
			id=39,
			num=3,
		},
	
		{
			id=1,
			num=150,
		},
	
		{
			id=3,
			num=30,
		},
	},
},
[8] = 
{
	id=8,
	type=1,
	rank_range=
	{
	8,
	8,
	},
	mailid=1808,
	box_num=3,
	rewards=
	{
	
		{
			id=39,
			num=2,
		},
	
		{
			id=1,
			num=150,
		},
	
		{
			id=3,
			num=25,
		},
	},
},
[9] = 
{
	id=9,
	type=1,
	rank_range=
	{
	9,
	9,
	},
	mailid=1809,
	box_num=2,
	rewards=
	{
	
		{
			id=39,
			num=1,
		},
	
		{
			id=1,
			num=100,
		},
	
		{
			id=3,
			num=20,
		},
	},
},
[10] = 
{
	id=10,
	type=1,
	rank_range=
	{
	10,
	10,
	},
	mailid=1810,
	box_num=1,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=3,
			num=10,
		},
	},
},
[11] = 
{
	id=11,
	type=2,
	rank_range=
	{
	1,
	1,
	},
	mailid=1901,
	box_num=60,
	rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=500,
		},
	
		{
			id=3,
			num=100,
		},
	},
},
[12] = 
{
	id=12,
	type=2,
	rank_range=
	{
	2,
	2,
	},
	mailid=1902,
	box_num=30,
	rewards=
	{
	
		{
			id=39,
			num=8,
		},
	
		{
			id=1,
			num=400,
		},
	
		{
			id=3,
			num=80,
		},
	},
},
[13] = 
{
	id=13,
	type=2,
	rank_range=
	{
	3,
	3,
	},
	mailid=1903,
	box_num=20,
	rewards=
	{
	
		{
			id=39,
			num=7,
		},
	
		{
			id=1,
			num=300,
		},
	
		{
			id=3,
			num=60,
		},
	},
},
[14] = 
{
	id=14,
	type=2,
	rank_range=
	{
	4,
	4,
	},
	mailid=1904,
	box_num=15,
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	
		{
			id=1,
			num=250,
		},
	
		{
			id=3,
			num=50,
		},
	},
},
[15] = 
{
	id=15,
	type=2,
	rank_range=
	{
	5,
	5,
	},
	mailid=1905,
	box_num=10,
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	
		{
			id=1,
			num=200,
		},
	
		{
			id=3,
			num=40,
		},
	},
},
[16] = 
{
	id=16,
	type=2,
	rank_range=
	{
	6,
	6,
	},
	mailid=1906,
	box_num=8,
	rewards=
	{
	
		{
			id=39,
			num=4,
		},
	
		{
			id=1,
			num=200,
		},
	
		{
			id=3,
			num=35,
		},
	},
},
[17] = 
{
	id=17,
	type=2,
	rank_range=
	{
	7,
	7,
	},
	mailid=1907,
	box_num=5,
	rewards=
	{
	
		{
			id=39,
			num=3,
		},
	
		{
			id=1,
			num=150,
		},
	
		{
			id=3,
			num=30,
		},
	},
},
[18] = 
{
	id=18,
	type=2,
	rank_range=
	{
	8,
	8,
	},
	mailid=1908,
	box_num=3,
	rewards=
	{
	
		{
			id=39,
			num=2,
		},
	
		{
			id=1,
			num=150,
		},
	
		{
			id=3,
			num=25,
		},
	},
},
[19] = 
{
	id=19,
	type=2,
	rank_range=
	{
	9,
	9,
	},
	mailid=1909,
	box_num=2,
	rewards=
	{
	
		{
			id=39,
			num=1,
		},
	
		{
			id=1,
			num=100,
		},
	
		{
			id=3,
			num=20,
		},
	},
},
[20] = 
{
	id=20,
	type=2,
	rank_range=
	{
	10,
	10,
	},
	mailid=1910,
	box_num=1,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=3,
			num=10,
		},
	},
},
[21] = 
{
	id=21,
	type=3,
	rank_range=
	{
	1,
	1,
	},
	mailid=2001,
	box_num=60,
	rewards=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=1,
			num=500,
		},
	
		{
			id=3,
			num=100,
		},
	},
},
[22] = 
{
	id=22,
	type=3,
	rank_range=
	{
	2,
	2,
	},
	mailid=2002,
	box_num=30,
	rewards=
	{
	
		{
			id=39,
			num=8,
		},
	
		{
			id=1,
			num=400,
		},
	
		{
			id=3,
			num=80,
		},
	},
},
[23] = 
{
	id=23,
	type=3,
	rank_range=
	{
	3,
	3,
	},
	mailid=2003,
	box_num=20,
	rewards=
	{
	
		{
			id=39,
			num=7,
		},
	
		{
			id=1,
			num=300,
		},
	
		{
			id=3,
			num=60,
		},
	},
},
[24] = 
{
	id=24,
	type=3,
	rank_range=
	{
	4,
	4,
	},
	mailid=2004,
	box_num=15,
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	
		{
			id=1,
			num=250,
		},
	
		{
			id=3,
			num=50,
		},
	},
},
[25] = 
{
	id=25,
	type=3,
	rank_range=
	{
	5,
	5,
	},
	mailid=2005,
	box_num=10,
	rewards=
	{
	
		{
			id=39,
			num=5,
		},
	
		{
			id=1,
			num=200,
		},
	
		{
			id=3,
			num=40,
		},
	},
},
[26] = 
{
	id=26,
	type=3,
	rank_range=
	{
	6,
	6,
	},
	mailid=2006,
	box_num=8,
	rewards=
	{
	
		{
			id=39,
			num=4,
		},
	
		{
			id=1,
			num=200,
		},
	
		{
			id=3,
			num=35,
		},
	},
},
[27] = 
{
	id=27,
	type=3,
	rank_range=
	{
	7,
	7,
	},
	mailid=2007,
	box_num=5,
	rewards=
	{
	
		{
			id=39,
			num=3,
		},
	
		{
			id=1,
			num=150,
		},
	
		{
			id=3,
			num=30,
		},
	},
},
[28] = 
{
	id=28,
	type=3,
	rank_range=
	{
	8,
	8,
	},
	mailid=2008,
	box_num=3,
	rewards=
	{
	
		{
			id=39,
			num=2,
		},
	
		{
			id=1,
			num=150,
		},
	
		{
			id=3,
			num=25,
		},
	},
},
[29] = 
{
	id=29,
	type=3,
	rank_range=
	{
	9,
	9,
	},
	mailid=2009,
	box_num=2,
	rewards=
	{
	
		{
			id=39,
			num=1,
		},
	
		{
			id=1,
			num=100,
		},
	
		{
			id=3,
			num=20,
		},
	},
},
[30] = 
{
	id=30,
	type=3,
	rank_range=
	{
	10,
	10,
	},
	mailid=2010,
	box_num=1,
	rewards=
	{
	
		{
			id=1,
			num=100,
		},
	
		{
			id=3,
			num=10,
		},
	},
},
}
