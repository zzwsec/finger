
-- pm.TbBiKingnetEventPetDevour



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="宠物id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="宠物老星级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="num1",
	name="宠物新星级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="config_id1",
	name="吞噬宠物id",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="num2",
	name="吞噬宠物等级",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="num3",
	name="吞噬宠物星级",
	type=0,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="info",
	name="新被动属性",
	type=1,
	opt=1,
	default_value="",
},
}
