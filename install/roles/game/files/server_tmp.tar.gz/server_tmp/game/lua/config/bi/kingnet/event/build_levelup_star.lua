
-- pm.TbBiKingnetEventBuildLevelupStar



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="建筑id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="建筑等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="config_id1",
	name="队列id",
	type=0,
	opt=1,
	default_value="",
},
}
