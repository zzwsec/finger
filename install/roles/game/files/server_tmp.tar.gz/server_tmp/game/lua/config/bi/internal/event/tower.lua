
-- pm.TbBiInternalEventTower



return
{
[1] = 
{
	id=1,
	field="layer",
	name="层数",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="level",
	name="关卡",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="win",
	name="输赢",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="buff",
	name="buff",
	type=1,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="player_power",
	name="玩家战力",
	type=0,
	opt=1,
	default_value="",
},
}
