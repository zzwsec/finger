local Log = require("common/logging")

local ByteArray = {}

ByteArray = {
    ENDIAN_LITTLE = "ENDIAN_LITTLE",
    ENDIAN_BIG = "ENDIAN_BIG",
    radix = {[10]="%03u",[8]="%03o",[16]="%02X"},
}

function ByteArray.toString(self, __radix, __separator)
    __radix = __radix or 16
    __radix = ByteArray.radix[__radix] or "%02X"
    __separator = __separator or " "

    local __fmt = __radix..__separator
    local __format = function (__s)
        return string.format(__fmt, string.byte(__s))
    end
    if type(self) == "string" then
        return string.gsub(self, "(.)", __format)
    end
    local __bytes = {}
    for i=1, #self._buf do
        __bytes[i] = __format(self._buf[i])
    end
    return table.concat(__bytes), #__bytes
end

function ByteArray.new(...)
    local o = {}
    setmetatable(o, ByteArray)
    ByteArray.__index = ByteArray
    o:ctor(...)
    return o
end

function ByteArray:ctor(__endian)
    self._endian = __endian
    self._buf = {}
    self._w_pos = 1
    self._r_pos = 1
end

function ByteArray:getLen()
    return #self._buf
end

function ByteArray:getAvailable()
    return #self._buf - self._w_pos + 1
end

function ByteArray:getEndian()
    return self._endian
end

function ByteArray:setEndian(__endian)
    self._endian = __endian
end

function ByteArray:clear()
    self._buf = {}
    self._w_pos = 1
    self._r_pos = 1
end

function ByteArray:getBytes(__offset, __length)
    __offset = __offset or 1
    __length = __length or #self._buf
    return table.concat(self._buf,"",__offset,__length)
end

function ByteArray:getPack(__offset, __length)
    __offset = __offset or 1
    __length = __length or #self._buf
    local __fmt = self:_getLC("c".. (__length - __offset + 1))
    local __s = string.pack(__fmt, self:getBytes(__offset, __length))
    return __s
end

function ByteArray:writeByte(__byte)
    local __s = string.pack(self:_getLC("b"), __byte)
    self:writeBuf(__s)
end

function ByteArray:writeUByte(__ubyte)
    local __s = string.pack(self:_getLC("B"), __ubyte)
    self:writeBuf(__s)
end

function ByteArray:writeChar(__char)
    local __s = string.pack(self:_getLC("c"), __char)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeBool(__bool)
    if __bool then
        self:writeByte(1)
    else
        self:writeByte(0)
    end
end

function ByteArray:writeInt(__int)
    local __s = string.pack(self:_getLC("i"), __int)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeUInt(__uint)
    local __s = string.pack(self:_getLC("I"), __uint)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeShort(__short)
    local __s = string.pack(self:_getLC("h"), __short)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeUShort(__ushort)
    local __s = string.pack(self:_getLC("H"), __ushort)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeLong(__long)
    local __s = string.pack(self:_getLC("l"), __long)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeULong(__ulong)
    local __s = string.pack(self:_getLC("L"), __ulong)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeFloat(__float)
    local __s = string.pack(self:_getLC("f"), __float)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeDouble(__double)
    local __s = string.pack(self:_getLC("d"), __double)
    self:writeBuf(__s)
    return self
end

function ByteArray:writeString(__string)
    self:writeBuf(__string)
    return self
end

function ByteArray:writeRawByte(__rawByte)
    if self._w_pos > #self._buf+1 then
        for i=#self._buf+1, self._w_pos-1 do
            self._buf[i] = string.char(0)
        end
    end
    self._buf[self._w_pos] = string.sub(__rawByte, 1, 1)
    self._w_pos = self._w_pos + 1
    return self
end

function ByteArray:writeBuf(__s)
    for i = 1, #__s do
        self:writeRawByte(string.sub(__s,i,i))
    end
    return self
end

function ByteArray:_getLC(__fmt)
    __fmt = __fmt or ""
    if self._endian == ByteArray.ENDIAN_LITTLE then
        return "<"..__fmt
    elseif self._endian == ByteArray.ENDIAN_BIG then
        return ">"..__fmt
    end
    return "="..__fmt
end

return ByteArray

