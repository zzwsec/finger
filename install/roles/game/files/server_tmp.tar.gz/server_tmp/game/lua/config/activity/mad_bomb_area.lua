
-- pm.TbActivityBombArea



return
{
[1] = 
{
	id=1,
	level=1,
	lateral_offset=0,
	vertical_offset=0,
},
[2] = 
{
	id=2,
	level=1,
	lateral_offset=0,
	vertical_offset=1,
},
[3] = 
{
	id=3,
	level=1,
	lateral_offset=0,
	vertical_offset=-1,
},
[4] = 
{
	id=4,
	level=1,
	lateral_offset=1,
	vertical_offset=0,
},
[5] = 
{
	id=5,
	level=1,
	lateral_offset=-1,
	vertical_offset=0,
},
[6] = 
{
	id=6,
	level=1,
	lateral_offset=1,
	vertical_offset=1,
},
[7] = 
{
	id=7,
	level=1,
	lateral_offset=1,
	vertical_offset=-1,
},
[8] = 
{
	id=8,
	level=1,
	lateral_offset=-1,
	vertical_offset=-1,
},
[9] = 
{
	id=9,
	level=1,
	lateral_offset=-1,
	vertical_offset=1,
},
}
