
-- pm.TbActivityChainGift



return
{
[101] = 
{
	id=101,
	index=1,
	gift=84001,
	pre_gift=0,
},
[102] = 
{
	id=102,
	index=1,
	gift=84002,
	pre_gift=84001,
},
[103] = 
{
	id=103,
	index=1,
	gift=84003,
	pre_gift=84002,
},
[104] = 
{
	id=104,
	index=1,
	gift=84004,
	pre_gift=84003,
},
[105] = 
{
	id=105,
	index=1,
	gift=84005,
	pre_gift=84004,
},
[106] = 
{
	id=106,
	index=1,
	gift=84006,
	pre_gift=84005,
},
[107] = 
{
	id=107,
	index=1,
	gift=84007,
	pre_gift=84006,
},
[108] = 
{
	id=108,
	index=1,
	gift=84008,
	pre_gift=84007,
},
[109] = 
{
	id=109,
	index=1,
	gift=84009,
	pre_gift=84008,
},
[110] = 
{
	id=110,
	index=1,
	gift=84010,
	pre_gift=84009,
},
[111] = 
{
	id=111,
	index=1,
	gift=84011,
	pre_gift=84010,
},
[112] = 
{
	id=112,
	index=1,
	gift=84012,
	pre_gift=84011,
},
[113] = 
{
	id=113,
	index=1,
	gift=84013,
	pre_gift=84012,
},
[114] = 
{
	id=114,
	index=1,
	gift=84014,
	pre_gift=84013,
},
[115] = 
{
	id=115,
	index=1,
	gift=84015,
	pre_gift=84014,
},
[116] = 
{
	id=116,
	index=1,
	gift=84016,
	pre_gift=84015,
},
[117] = 
{
	id=117,
	index=1,
	gift=84017,
	pre_gift=84016,
},
[118] = 
{
	id=118,
	index=1,
	gift=84018,
	pre_gift=84017,
},
[119] = 
{
	id=119,
	index=1,
	gift=84019,
	pre_gift=84018,
},
[120] = 
{
	id=120,
	index=1,
	gift=84020,
	pre_gift=84019,
},
[201] = 
{
	id=201,
	index=2,
	gift=84101,
	pre_gift=0,
},
[202] = 
{
	id=202,
	index=2,
	gift=84102,
	pre_gift=84101,
},
[203] = 
{
	id=203,
	index=2,
	gift=84103,
	pre_gift=84102,
},
[204] = 
{
	id=204,
	index=2,
	gift=84104,
	pre_gift=84103,
},
[205] = 
{
	id=205,
	index=2,
	gift=84105,
	pre_gift=84104,
},
[206] = 
{
	id=206,
	index=2,
	gift=84106,
	pre_gift=84105,
},
[207] = 
{
	id=207,
	index=2,
	gift=84107,
	pre_gift=84106,
},
[208] = 
{
	id=208,
	index=2,
	gift=84108,
	pre_gift=84107,
},
[209] = 
{
	id=209,
	index=2,
	gift=84109,
	pre_gift=84108,
},
[210] = 
{
	id=210,
	index=2,
	gift=84110,
	pre_gift=84109,
},
[211] = 
{
	id=211,
	index=2,
	gift=84111,
	pre_gift=84110,
},
[212] = 
{
	id=212,
	index=2,
	gift=84112,
	pre_gift=84111,
},
[213] = 
{
	id=213,
	index=2,
	gift=84113,
	pre_gift=84112,
},
[214] = 
{
	id=214,
	index=2,
	gift=84114,
	pre_gift=84113,
},
[215] = 
{
	id=215,
	index=2,
	gift=84115,
	pre_gift=84114,
},
[216] = 
{
	id=216,
	index=2,
	gift=84116,
	pre_gift=84115,
},
[217] = 
{
	id=217,
	index=2,
	gift=84117,
	pre_gift=84116,
},
[218] = 
{
	id=218,
	index=2,
	gift=84118,
	pre_gift=84117,
},
[219] = 
{
	id=219,
	index=2,
	gift=84119,
	pre_gift=84118,
},
[220] = 
{
	id=220,
	index=2,
	gift=84120,
	pre_gift=84119,
},
[221] = 
{
	id=221,
	index=2,
	gift=84121,
	pre_gift=84120,
},
[222] = 
{
	id=222,
	index=2,
	gift=84122,
	pre_gift=84121,
},
[223] = 
{
	id=223,
	index=2,
	gift=84123,
	pre_gift=84122,
},
[224] = 
{
	id=224,
	index=2,
	gift=84124,
	pre_gift=84123,
},
[225] = 
{
	id=225,
	index=2,
	gift=84125,
	pre_gift=84124,
},
[226] = 
{
	id=226,
	index=2,
	gift=84126,
	pre_gift=84125,
},
[301] = 
{
	id=301,
	index=3,
	gift=84201,
	pre_gift=0,
},
[302] = 
{
	id=302,
	index=3,
	gift=84202,
	pre_gift=84201,
},
[303] = 
{
	id=303,
	index=3,
	gift=84203,
	pre_gift=84202,
},
[304] = 
{
	id=304,
	index=3,
	gift=84204,
	pre_gift=84203,
},
[305] = 
{
	id=305,
	index=3,
	gift=84205,
	pre_gift=84204,
},
[306] = 
{
	id=306,
	index=3,
	gift=84206,
	pre_gift=84205,
},
[307] = 
{
	id=307,
	index=3,
	gift=84207,
	pre_gift=84206,
},
[308] = 
{
	id=308,
	index=3,
	gift=84208,
	pre_gift=84207,
},
[309] = 
{
	id=309,
	index=3,
	gift=84209,
	pre_gift=84208,
},
[310] = 
{
	id=310,
	index=3,
	gift=84210,
	pre_gift=84209,
},
[311] = 
{
	id=311,
	index=3,
	gift=84211,
	pre_gift=84210,
},
[312] = 
{
	id=312,
	index=3,
	gift=84212,
	pre_gift=84211,
},
[313] = 
{
	id=313,
	index=3,
	gift=84213,
	pre_gift=84212,
},
[314] = 
{
	id=314,
	index=3,
	gift=84214,
	pre_gift=84213,
},
[315] = 
{
	id=315,
	index=3,
	gift=84215,
	pre_gift=84214,
},
[316] = 
{
	id=316,
	index=3,
	gift=84216,
	pre_gift=84215,
},
[317] = 
{
	id=317,
	index=3,
	gift=84217,
	pre_gift=84216,
},
[318] = 
{
	id=318,
	index=3,
	gift=84218,
	pre_gift=84217,
},
[319] = 
{
	id=319,
	index=3,
	gift=84219,
	pre_gift=84218,
},
[320] = 
{
	id=320,
	index=3,
	gift=84220,
	pre_gift=84219,
},
[321] = 
{
	id=321,
	index=3,
	gift=84221,
	pre_gift=84220,
},
[322] = 
{
	id=322,
	index=3,
	gift=84222,
	pre_gift=84221,
},
[323] = 
{
	id=323,
	index=3,
	gift=84223,
	pre_gift=84222,
},
[324] = 
{
	id=324,
	index=3,
	gift=84224,
	pre_gift=84223,
},
[325] = 
{
	id=325,
	index=3,
	gift=84225,
	pre_gift=84224,
},
[326] = 
{
	id=326,
	index=3,
	gift=84226,
	pre_gift=84225,
},
[401] = 
{
	id=401,
	index=4,
	gift=84301,
	pre_gift=0,
},
[402] = 
{
	id=402,
	index=4,
	gift=84302,
	pre_gift=84301,
},
[403] = 
{
	id=403,
	index=4,
	gift=84303,
	pre_gift=84302,
},
[404] = 
{
	id=404,
	index=4,
	gift=84304,
	pre_gift=84303,
},
[405] = 
{
	id=405,
	index=4,
	gift=84305,
	pre_gift=84304,
},
[406] = 
{
	id=406,
	index=4,
	gift=84306,
	pre_gift=84305,
},
[407] = 
{
	id=407,
	index=4,
	gift=84307,
	pre_gift=84306,
},
[408] = 
{
	id=408,
	index=4,
	gift=84308,
	pre_gift=84307,
},
[409] = 
{
	id=409,
	index=4,
	gift=84309,
	pre_gift=84308,
},
[410] = 
{
	id=410,
	index=4,
	gift=84310,
	pre_gift=84309,
},
[411] = 
{
	id=411,
	index=4,
	gift=84311,
	pre_gift=84310,
},
[412] = 
{
	id=412,
	index=4,
	gift=84312,
	pre_gift=84311,
},
[413] = 
{
	id=413,
	index=4,
	gift=84313,
	pre_gift=84312,
},
[414] = 
{
	id=414,
	index=4,
	gift=84314,
	pre_gift=84313,
},
[415] = 
{
	id=415,
	index=4,
	gift=84315,
	pre_gift=84314,
},
[416] = 
{
	id=416,
	index=4,
	gift=84316,
	pre_gift=84315,
},
[417] = 
{
	id=417,
	index=4,
	gift=84317,
	pre_gift=84316,
},
[418] = 
{
	id=418,
	index=4,
	gift=84318,
	pre_gift=84317,
},
[419] = 
{
	id=419,
	index=4,
	gift=84319,
	pre_gift=84318,
},
[420] = 
{
	id=420,
	index=4,
	gift=84320,
	pre_gift=84319,
},
[421] = 
{
	id=421,
	index=4,
	gift=84321,
	pre_gift=84320,
},
[422] = 
{
	id=422,
	index=4,
	gift=84322,
	pre_gift=84321,
},
[423] = 
{
	id=423,
	index=4,
	gift=84323,
	pre_gift=84322,
},
[424] = 
{
	id=424,
	index=4,
	gift=84324,
	pre_gift=84323,
},
[425] = 
{
	id=425,
	index=4,
	gift=84325,
	pre_gift=84324,
},
[426] = 
{
	id=426,
	index=4,
	gift=84326,
	pre_gift=84325,
},
}
