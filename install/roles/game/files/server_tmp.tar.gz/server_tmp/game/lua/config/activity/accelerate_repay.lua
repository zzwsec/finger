
-- pm.TbActivityAccelerateRepay



return
{
[1] = 
{
	id=1,
	repay_ratio=10,
	weight=2250,
	pos=
	{
	1,
	6,
	},
	repay_limit=4320,
},
[2] = 
{
	id=2,
	repay_ratio=20,
	weight=2500,
	pos=
	{
	2,
	7,
	},
	repay_limit=4320,
},
[3] = 
{
	id=3,
	repay_ratio=30,
	weight=2500,
	pos=
	{
	3,
	8,
	},
	repay_limit=4320,
},
[4] = 
{
	id=4,
	repay_ratio=40,
	weight=1500,
	pos=
	{
	4,
	9,
	},
	repay_limit=4320,
},
[5] = 
{
	id=5,
	repay_ratio=50,
	weight=1250,
	pos=
	{
	5,
	10,
	},
	repay_limit=4320,
},
}
