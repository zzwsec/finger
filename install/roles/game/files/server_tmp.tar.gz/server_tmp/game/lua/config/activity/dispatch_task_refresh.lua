
-- pm.TbDispatchTaskRefresh



return
{
[1] = 
{
	id=1,
	refresh_range=
	{
	1,
	1,
	},
	refresh_cost=
	{
		id=1,
		num=0,
	},
	refresh_cd=3,
},
[2] = 
{
	id=2,
	refresh_range=
	{
	2,
	9999,
	},
	refresh_cost=
	{
		id=1,
		num=10,
	},
	refresh_cd=3,
},
}
