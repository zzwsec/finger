
-- pm.TbBiInternalEventMiningEvent



return
{
[1] = 
{
	id=1,
	field="event_type",
	name="触发事件类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="event_param",
	name="事件参数",
	type=0,
	opt=1,
	default_value="",
},
}
