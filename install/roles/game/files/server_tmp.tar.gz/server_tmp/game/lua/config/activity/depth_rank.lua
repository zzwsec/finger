
-- pm.TbDepthRank



return
{
[1] = 
{
	id=1,
	rank_range=
	{
		min=1,
		max=1,
	},
	chase_rank=2,
},
[2] = 
{
	id=2,
	rank_range=
	{
		min=2,
		max=2,
	},
	chase_rank=1,
},
[3] = 
{
	id=3,
	rank_range=
	{
		min=3,
		max=3,
	},
	chase_rank=2,
},
[4] = 
{
	id=4,
	rank_range=
	{
		min=4,
		max=4,
	},
	chase_rank=3,
},
[5] = 
{
	id=5,
	rank_range=
	{
		min=5,
		max=5,
	},
	chase_rank=4,
},
[6] = 
{
	id=6,
	rank_range=
	{
		min=6,
		max=6,
	},
	chase_rank=5,
},
[7] = 
{
	id=7,
	rank_range=
	{
		min=7,
		max=7,
	},
	chase_rank=6,
},
[8] = 
{
	id=8,
	rank_range=
	{
		min=8,
		max=8,
	},
	chase_rank=7,
},
[9] = 
{
	id=9,
	rank_range=
	{
		min=9,
		max=9,
	},
	chase_rank=8,
},
[10] = 
{
	id=10,
	rank_range=
	{
		min=10,
		max=10,
	},
	chase_rank=9,
},
[11] = 
{
	id=11,
	rank_range=
	{
		min=11,
		max=20,
	},
	chase_rank=10,
},
[12] = 
{
	id=12,
	rank_range=
	{
		min=21,
		max=30,
	},
	chase_rank=20,
},
[13] = 
{
	id=13,
	rank_range=
	{
		min=31,
		max=40,
	},
	chase_rank=30,
},
[14] = 
{
	id=14,
	rank_range=
	{
		min=41,
		max=50,
	},
	chase_rank=40,
},
[15] = 
{
	id=15,
	rank_range=
	{
		min=51,
		max=100,
	},
	chase_rank=50,
},
[16] = 
{
	id=16,
	rank_range=
	{
		min=101,
		max=150,
	},
	chase_rank=100,
},
[17] = 
{
	id=17,
	rank_range=
	{
		min=151,
		max=200,
	},
	chase_rank=150,
},
[18] = 
{
	id=18,
	rank_range=
	{
		min=201,
		max=9999,
	},
	chase_rank=200,
},
}
