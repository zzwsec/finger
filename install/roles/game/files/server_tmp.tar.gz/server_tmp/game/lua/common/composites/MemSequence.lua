local class = require "utils.class"
local Constants = require "core.Constants"

local Composite = require 'core.Composite'

local MemSequence = class("MemSequence", Composite)

function MemSequence:ctor()
    Composite.ctor(self)

    self.name = "MemSequence"
end

function MemSequence:open(tick)
    tick.blackboard:set("i", 1, tick.tree.id, self.id)
end

function MemSequence:tick(tick)
    local i = tick.blackboard:get("i", tick.tree.id, self.id)
    while i <= #self.children do
        local v = self.children[i]
        local status = v:_execute(tick)
        if status ~= Constants.SUCCESS then
            if status == Constants.RUNNING then
                tick.blackboard:set("i", i, tick.tree.id, self.id)
            end

            return status
        end
        i = i + 1
    end

    return Constants.SUCCESS
end

return MemSequence