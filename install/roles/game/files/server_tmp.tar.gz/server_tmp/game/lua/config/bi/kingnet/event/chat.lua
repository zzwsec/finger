
-- pm.TbBiKingnetEventChat



return
{
[1] = 
{
	id=1,
	field="type",
	name="聊天类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="id",
	name="发送者id",
	type=1,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="info",
	name="聊天消息",
	type=1,
	opt=1,
	default_value="",
},
}
