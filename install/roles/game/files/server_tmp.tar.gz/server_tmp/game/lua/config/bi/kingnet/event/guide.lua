
-- pm.TbBiKingnetEventGuide



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="引导id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="config_id1",
	name="引导组id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="type",
	name="引导类型",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="status",
	name="引导组完成状态",
	type=0,
	opt=1,
	default_value="",
},
}
