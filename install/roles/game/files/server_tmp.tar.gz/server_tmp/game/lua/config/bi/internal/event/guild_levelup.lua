
-- pm.TbBiInternalEventGuildLevelup



return
{
[1] = 
{
	id=1,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="old_level",
	name="老等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="new_level",
	name="新等级",
	type=0,
	opt=1,
	default_value="",
},
}
