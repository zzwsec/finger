local Log = require("common.logging")   
local Result = import("common.result")

local ConfigUtility = import("api.utility.config")
local InviteRemote = import("api.service.invite.remote")
local Record = import("api.service.invite.record")

local ServerOptions = ConfigUtility.ServerOptions
local ProjectId = ServerOptions.ProjectId

local _M = {}

-- 创建邀请码
function _M.Create(coro, message)
    local creator = message.creator 
    local player_id = creator.id or 0
    local zone_id = creator.zone_id or 0
    local cdkey = creator.cdkey or ""
    
    local now_time = os.now()
    local user_id = Record.EncodeId(player_id, zone_id)
    local create_result = InviteRemote.Create(coro, {
        project_id = ProjectId,
        user_id = user_id,
        cdkey = cdkey,
    })
    if create_result:is_err() then
        Log.Warn("CreateInvite", "Failed to create invite: {}", create_result:unwrap_err())
        return create_result
    end

    local invite = create_result:unwrap()
    if not invite then
        Log.Warn("CreateInvite", "invite is nil")
        return Result.err("SYSTEM_BUSY")
    end

    local stats = invite.stats or {}

    return Result.ok({
        id = invite.id,
        creator = {
            id = player_id,
            zone_id = zone_id,
            cdkey = cdkey,
        },
        stats = {
            total_count = stats.total_count or 0,
            daily_count = stats.daily_count or 0,
        },
        created_at = now_time,
    })
end

-- 获取邀请码
function _M.Get(coro, message)
    local id = message.id or "" 
    local get_result = InviteRemote.Get(coro, {
        project_id = ProjectId,
        id = id,
    })
    if get_result:is_err() then
        Log.Warn("GetInvite", "Failed to get invite: {}", get_result:unwrap_err())
        return get_result
    end

    local invite = get_result:unwrap()
    if not invite then
        Log.Warn("GetInvite", "invite is nil")
        return Result.err("SYSTEM_BUSY")
    end

    local stats = invite.stats or {}
    local player_id, zone_id = Record.DecodeId(invite.user_id)
    return Result.ok({
        id = invite.id,
        creator = {
            id = player_id,
            zone_id = zone_id,
            cdkey = invite.cdkey,
        },
        stats = {
            total_count = stats.total_count or 0,
            daily_count = stats.daily_count or 0,
        },
        created_at = tonumber(invite.created_at),
    })
end

-- 绑定邀请码
function _M.Bind(coro, message)
    local id = message.id or "" 
    local user = message.user 

    local player_id = user.id or 0
    local zone_id = user.zone_id or 0
    local cdkey = user.cdkey or ""

    Log.Debug("BindInvite", "Bind: {}", message)
    local user_id = Record.EncodeId(player_id, zone_id) 
    local bind_result = InviteRemote.Bind(coro, {
        project_id = ProjectId,
        id = id,
        cdkey = cdkey,
        user_id = user_id,
    })
    if bind_result:is_err() then
        Log.Warn("BindInvite", "Failed to bind invite: {}", bind_result:unwrap_err())
        return bind_result
    end

    local invite = bind_result:unwrap()
    if not invite then
        Log.Warn("BindInvite", "invite is nil")
        return Result.err("SYSTEM_BUSY")
    end

    local stats = invite.stats or {}
    local creator_cdkey = invite.cdkey
    local creator_id, creator_zone_id = Record.DecodeId(invite.user_id)
    return Result.ok({
        id = invite.id,
        creator = {
            id = creator_id,
            zone_id = creator_zone_id,
            cdkey = creator_cdkey,
        },
        stats = {
            total_count = stats.total_count or 0,
            daily_count = stats.daily_count or 0,
        },
        created_at = tonumber(invite.created_at),
    })
end

-- 获取邀请码关联记录
function _M.Relation(coro, message)
    Log.Debug("RelationInvite", "Relation: {}", message)

    local id = message.id or ""
    local relation_result = InviteRemote.Relation(coro, {
        project_id = ProjectId,
        id = id,
    })
    if relation_result:is_err() then
        Log.Warn("RelationInvite", "Failed to get relation: {}", relation_result:unwrap_err())
        return relation_result
    end

    local records = relation_result:unwrap()
    if not records then
        Log.Warn("RelationInvite", "records is nil")
        return Result.err("SYSTEM_BUSY")
    end

    local result = {}
    for _, record in ipairs(records) do
        local player_id, zone_id = Record.DecodeId(record.user_id)
        table.insert(result, {
            id = player_id,
            zone_id = zone_id,
            cdkey = record.cdkey,
            time = tonumber(record.time),
        })
    end
    Log.Debug("RelationInvite", "Relation: {}", result)
    return Result.ok(result)
end

return _M


