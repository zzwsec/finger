
-- pm.TbBiInternalEventTechTree



return
{
[1] = 
{
	id=1,
	field="tech_id",
	name="科技id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="attrs_id",
	name="属性id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="skill_id",
	name="技能id",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="attrs_value",
	name="属性值",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="level",
	name="科技当前等级",
	type=0,
	opt=1,
	default_value="",
},
}
