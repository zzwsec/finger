
-- pm.TbBiInternalEventClick



return
{
[1] = 
{
	id=1,
	field="way",
	name="主入口（1商城）",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="sub_way",
	name="子入口（和主入口相关）",
	type=0,
	opt=0,
	default_value="0",
},
}
