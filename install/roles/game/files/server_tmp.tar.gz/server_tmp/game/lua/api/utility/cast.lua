local Counter = {}
local Invite = {}
local Leaderboard = {}

function Counter.toCounter(content)
    if not content then return nil end

    return {
        counter_id = content.id,
        value = tonumber(content.value or "0"),
    }
end

function Invite.toErrorCode(code)
    if code == 6000 then
        return "ALREADY_BIND"
    elseif code == 6001 then
        return "SAME_USER_ID"
    elseif code == 6002 then
        return "SAME_CDKEY"
    elseif code == 6003 then
        return "BIND_LIMIT"
    end
    return "OK"
end

function Invite.toInvite(content)
    if not content then return nil end

    return {
        id = content.id,
        cdkey = content.cdkey,
        user_id = content.user_id,
        created_at = content.created_at,
        stats = {
            total_count = content.stats.total_count,
            daily_count = content.stats.daily_count,
        }
    }
end


function Leaderboard.toLeaderboard(content)
    if not content then return nil end

    return {
        leaderboard_id = content.id,
        project_id = content.project_id,
        sort_order = content.sort_order,
        update_type = content.update_type,
        limit = content.limit,
        created_at = content.created_at,
        updated_at = content.updated_at
    }
end

function Leaderboard.toRecord(content)
    if not content then return nil end

    return {
        user_id = content.id,
        score = content.score,
        rank = content.rank,
        time = content.time
    }
end

return {
    Counter = Counter,
    Invite = Invite,
    Leaderboard = Leaderboard,
}
