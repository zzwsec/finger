
-- pm.TbBiInternalEventGoodsGet



return
{
[1] = 
{
	id=1,
	field="detail_id",
	name="明细id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="goods_id",
	name="道具id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="get_num",
	name="获取数量",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="cur_num",
	name="当前数量",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="way",
	name="途径",
	type=0,
	opt=1,
	default_value="",
},
}
