
-- pm.TbActivityMiningArea



return
{
[1] = 
{
	id=1,
	mine_prob=
	{
	
		{
			value=0,
			pr=0.125,
		},
	
		{
			value=1,
			pr=0.565,
		},
	
		{
			value=2,
			pr=0.3,
		},
	
		{
			value=11,
			pr=0.01,
		},
	},
	depth_range=
	{
		min=0,
		max=5,
	},
	rand_template=
	{
	1,
	},
},
[2] = 
{
	id=2,
	mine_prob=
	{
	
		{
			value=0,
			pr=0.125,
		},
	
		{
			value=1,
			pr=0.565,
		},
	
		{
			value=2,
			pr=0.3,
		},
	
		{
			value=11,
			pr=0.01,
		},
	},
	depth_range=
	{
		min=6,
		max=50,
	},
	rand_template=
	{
	2,
	3,
	},
},
[3] = 
{
	id=3,
	mine_prob=
	{
	
		{
			value=0,
			pr=0.125,
		},
	
		{
			value=1,
			pr=0.565,
		},
	
		{
			value=2,
			pr=0.2,
		},
	
		{
			value=3,
			pr=0.1,
		},
	
		{
			value=11,
			pr=0.01,
		},
	},
	depth_range=
	{
		min=51,
		max=200,
	},
	rand_template=
	{
	4,
	5,
	6,
	},
},
[4] = 
{
	id=4,
	mine_prob=
	{
	
		{
			value=0,
			pr=0.125,
		},
	
		{
			value=1,
			pr=0.565,
		},
	
		{
			value=2,
			pr=0.14,
		},
	
		{
			value=3,
			pr=0.11,
		},
	
		{
			value=4,
			pr=0.05,
		},
	
		{
			value=11,
			pr=0.01,
		},
	},
	depth_range=
	{
		min=201,
		max=500,
	},
	rand_template=
	{
	7,
	8,
	9,
	10,
	},
},
[5] = 
{
	id=5,
	mine_prob=
	{
	
		{
			value=0,
			pr=0.125,
		},
	
		{
			value=1,
			pr=0.565,
		},
	
		{
			value=2,
			pr=0.1,
		},
	
		{
			value=3,
			pr=0.09,
		},
	
		{
			value=4,
			pr=0.08,
		},
	
		{
			value=5,
			pr=0.03,
		},
	
		{
			value=11,
			pr=0.01,
		},
	},
	depth_range=
	{
		min=501,
		max=1000,
	},
	rand_template=
	{
	11,
	12,
	13,
	14,
	},
},
[6] = 
{
	id=6,
	mine_prob=
	{
	
		{
			value=0,
			pr=0.125,
		},
	
		{
			value=1,
			pr=0.565,
		},
	
		{
			value=2,
			pr=0.05,
		},
	
		{
			value=3,
			pr=0.075,
		},
	
		{
			value=4,
			pr=0.105,
		},
	
		{
			value=5,
			pr=0.05,
		},
	
		{
			value=6,
			pr=0.02,
		},
	
		{
			value=11,
			pr=0.01,
		},
	},
	depth_range=
	{
		min=1001,
		max=2000,
	},
	rand_template=
	{
	15,
	16,
	17,
	18,
	19,
	},
},
[7] = 
{
	id=7,
	mine_prob=
	{
	
		{
			value=0,
			pr=0.125,
		},
	
		{
			value=1,
			pr=0.565,
		},
	
		{
			value=3,
			pr=0.06,
		},
	
		{
			value=4,
			pr=0.1,
		},
	
		{
			value=5,
			pr=0.08,
		},
	
		{
			value=6,
			pr=0.04,
		},
	
		{
			value=7,
			pr=0.02,
		},
	
		{
			value=11,
			pr=0.01,
		},
	},
	depth_range=
	{
		min=2001,
		max=9999999,
	},
	rand_template=
	{
	20,
	21,
	22,
	23,
	24,
	25,
	},
},
}
