
-- pm.TbBiInternalEventShop



return
{
[1] = 
{
	id=1,
	field="shop_type",
	name="商店类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="shop_index",
	name="商店索引",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="shop_pool_id",
	name="商品id",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="buy_num",
	name="购买商品数量",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="shop_pool_type",
	name="商品刷新类型",
	type=0,
	opt=1,
	default_value="",
},
}
