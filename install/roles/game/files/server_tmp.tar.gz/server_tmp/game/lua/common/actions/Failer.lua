local class = require "utils.class"
local Constants = require "core.Constants"

local Action = require 'core.Action'

local Failer = class("Failer", Action)

function Failer:ctor()
    Action.ctor(self)
    
    self.name = "Failer"
end

function Failer:tick()
    return Constants.SUCCESS
end

return Failer
