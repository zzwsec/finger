
-- pm.TbBusinessStore



return
{
[1] = 
{
	id=1,
	store_limit=100,
	cost=
	{
		id=61,
		num=800,
	},
},
[2] = 
{
	id=2,
	store_limit=200,
	cost=
	{
		id=61,
		num=2000,
	},
},
[3] = 
{
	id=3,
	store_limit=300,
	cost=
	{
		id=61,
		num=5000,
	},
},
[4] = 
{
	id=4,
	store_limit=400,
	cost=
	{
		id=61,
		num=8000,
	},
},
[5] = 
{
	id=5,
	store_limit=500,
	cost=
	{
		id=61,
		num=12000,
	},
},
[6] = 
{
	id=6,
	store_limit=600,
	cost=
	{
		id=0,
		num=0,
	},
},
}
