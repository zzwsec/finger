
-- pm.TbUndergroundGoodsPool



return
{
[102041] = 
{
	id=102041,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=3,
			num=10,
			pr=2480,
		},
	
		{
			id=33,
			num=5,
			pr=2500,
		},
	
		{
			id=11,
			num=3,
			pr=1500,
		},
	
		{
			id=5,
			num=3,
			pr=1500,
		},
	
		{
			id=14,
			num=3,
			pr=1000,
		},
	
		{
			id=12,
			num=2,
			pr=1000,
		},
	
		{
			id=156,
			num=1,
			pr=20,
		},
	},
},
[102042] = 
{
	id=102042,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=3,
			num=15,
			pr=2475,
		},
	
		{
			id=33,
			num=8,
			pr=2500,
		},
	
		{
			id=11,
			num=4,
			pr=1500,
		},
	
		{
			id=5,
			num=4,
			pr=1500,
		},
	
		{
			id=14,
			num=3,
			pr=1000,
		},
	
		{
			id=12,
			num=2,
			pr=1000,
		},
	
		{
			id=156,
			num=1,
			pr=25,
		},
	},
},
[102043] = 
{
	id=102043,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=3,
			num=15,
			pr=2420,
		},
	
		{
			id=33,
			num=10,
			pr=2500,
		},
	
		{
			id=11,
			num=5,
			pr=1500,
		},
	
		{
			id=5,
			num=5,
			pr=1500,
		},
	
		{
			id=14,
			num=4,
			pr=1000,
		},
	
		{
			id=12,
			num=3,
			pr=1000,
		},
	
		{
			id=17,
			num=1,
			pr=50,
		},
	
		{
			id=156,
			num=1,
			pr=30,
		},
	},
},
[102044] = 
{
	id=102044,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=3,
			num=20,
			pr=2365,
		},
	
		{
			id=33,
			num=12,
			pr=2500,
		},
	
		{
			id=11,
			num=5,
			pr=1500,
		},
	
		{
			id=5,
			num=6,
			pr=1500,
		},
	
		{
			id=14,
			num=5,
			pr=1000,
		},
	
		{
			id=12,
			num=3,
			pr=1000,
		},
	
		{
			id=17,
			num=1,
			pr=100,
		},
	
		{
			id=156,
			num=1,
			pr=35,
		},
	},
},
[102045] = 
{
	id=102045,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=3,
			num=20,
			pr=2260,
		},
	
		{
			id=33,
			num=15,
			pr=2500,
		},
	
		{
			id=11,
			num=6,
			pr=1500,
		},
	
		{
			id=5,
			num=7,
			pr=1500,
		},
	
		{
			id=14,
			num=5,
			pr=1000,
		},
	
		{
			id=12,
			num=3,
			pr=1000,
		},
	
		{
			id=17,
			num=1,
			pr=100,
		},
	
		{
			id=39,
			num=1,
			pr=100,
		},
	
		{
			id=156,
			num=1,
			pr=40,
		},
	},
},
[102046] = 
{
	id=102046,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=3,
			num=20,
			pr=2250,
		},
	
		{
			id=33,
			num=20,
			pr=2500,
		},
	
		{
			id=11,
			num=8,
			pr=1500,
		},
	
		{
			id=5,
			num=8,
			pr=1500,
		},
	
		{
			id=14,
			num=6,
			pr=1000,
		},
	
		{
			id=12,
			num=3,
			pr=1000,
		},
	
		{
			id=17,
			num=1,
			pr=100,
		},
	
		{
			id=39,
			num=1,
			pr=100,
		},
	
		{
			id=156,
			num=1,
			pr=50,
		},
	},
},
[102040] = 
{
	id=102040,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=156,
			num=1,
			pr=10000,
		},
	},
},
[102061] = 
{
	id=102061,
	grand=true,
	normal_pool=102041,
	reward=
	{
	
		{
			id=1,
			num=1000,
		},
	},
	probabilitys=
	{
	},
},
[102062] = 
{
	id=102062,
	grand=true,
	normal_pool=102041,
	reward=
	{
	
		{
			id=1,
			num=1000,
		},
	},
	probabilitys=
	{
	},
},
}
