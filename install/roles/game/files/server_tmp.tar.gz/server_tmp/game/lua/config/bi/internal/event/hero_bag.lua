
-- pm.TbBiInternalEventHeroBag



return
{
[1] = 
{
	id=1,
	field="old_grid",
	name="旧格子上限",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="new_grid",
	name="新格子上限",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="type",
	name="提升操作",
	type=0,
	opt=1,
	default_value="",
},
}
