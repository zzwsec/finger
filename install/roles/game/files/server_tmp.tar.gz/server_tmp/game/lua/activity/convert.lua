local Log = require("common/logging")
local Time = import("common/time")

local M = {}

local keywords = {"id", "type", "index", "mode", "visible", "order"}

function M.FormatOutput(from)
    local output = {}
    for _, key in ipairs(keywords or {}) do 
        output[key] = from[key]
    end
    if from.time_solt ~= nil then
        output.time_solt = {
            begin_time = os.date("%Y-%m-%dT%H:%M:%S", from.time_solt.begin_time),
            end_time = os.date("%Y-%m-%dT%H:%M:%S", from.time_solt.end_time)
        }
    else
        output.time_solt = {
            begin_time = os.date("%Y-%m-%dT%H:%M:%S", from.begin_time),
            end_time = os.date("%Y-%m-%dT%H:%M:%S", from.end_time)
        }
    end    
    return output
end

function M.FormatInput(from)
    local input = {}
    for _, key in ipairs(keywords or {}) do 
        input[key] = from[key]
    end 
    if from.time_solt ~= nil then
        input.time_solt = {
            begin_time = tonumber(from.time_solt.begin_time) ~= nil and from.time_solt.begin_time or Time.ParseDateTimeTs(from.time_solt.begin_time),
            end_time = tonumber(from.time_solt.end_time) ~= nil and from.time_solt.end_time or Time.ParseDateTimeTs(from.time_solt.end_time)
        }
    else
        input.time_solt = {
            begin_time = tonumber(from.begin_time) ~= nil and from.begin_time or Time.ParseDateTimeTs(from.begin_time),
            end_time = tonumber(from.end_time) ~= nil and from.end_time or Time.ParseDateTimeTs(from.end_time)
        }
    end
    return input
end

return M