local class = require "utils.class"
local Constants = require "core.Constants"

local Decorator = require "core.Decorator"

local RepeatUntilFailure = class("RepeatUntilFailure", Decorator)

function RepeatUntilFailure:ctor(params)
    Decorator.ctor(self)

    if not params then
        params = {}
    end

    self.name = "RepeatUntilFailure"
    self.title = "Repeat Until Failure"
    self.parameters = {maxLoop = -1}

    self.maxLoop = params.maxLoop or -1
end

function RepeatUntilFailure:open(tick)
    tick.blackboard.set("i", 0, tick.tree.id, self.id)
end

function RepeatUntilFailure:tick(tick)
    assert(self.child, "no chilld")

    local i = tick.blackboard.get("i", tick.tree.id , self.id)
    local status = Constants.ERROR

    while(self.maxLoop < 0 or i < self.maxLoop)
    do
        local status = self.child:_execute(tick)

        if status == Constants.SUCCESS then
            i = i + 1
        else
            break
        end
    end

    i = tick.blackboard.set("i", i, tick.tree.id, self.id)
    return status
end

return RepeatUntilFailure
