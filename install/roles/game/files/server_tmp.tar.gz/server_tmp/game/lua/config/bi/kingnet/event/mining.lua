
-- pm.TbBiKingnetEventMining



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="模板id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="矿场深度",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="type",
	name="矿石id",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="num1",
	name="矿石强度",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="value",
	name="矿镐强度",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="status",
	name="矿石状态",
	type=0,
	opt=1,
	default_value="",
},
}
