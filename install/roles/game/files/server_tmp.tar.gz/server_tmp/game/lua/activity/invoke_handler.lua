local Log = require("common/logging")
local AppGameLib = require("app.game.lib")
local System = require("common/system")

local Activity = import("activity/activity")
local Server = import("activity/server")

local g_game_activity_service = AppGameLib.ActivityService_Stub.new(g_channel)

local error_handler = function(err_msg)
    Log.Error("Lua", err_msg)
end

-- 拉取活动
local function OnHandle_FetchActivity(type_name, message, done)
    local coro = coroutine.create(function(coro, message, done)
        Log.Debug("Activity", "OnHandle_FetchActivity")
        local _, response = xpcall(function(coro, message)
            local response = {
                ["result"] = "SYSTEM_BUSY",
                ["activitys"] = {},
            }
            local game_service_ids = Server.GetGameServiceIds()
            local count_down_count = #game_service_ids + 1
            local count_down = function()
                count_down_count = count_down_count - 1
                if count_down_count == 0 then
                    coroutine.resume(coro)
                end
            end
            local fetch_activity_req = {}
            for _, game_service_id in pairs(game_service_ids) do
                assert(g_game_activity_service:FetchActivity(game_service_id, fetch_activity_req, function(fetch_activity_error, fetch_activity_resp)
                    for _, activity in pairs(fetch_activity_resp.activitys or {}) do
                        response.activitys[activity.id] = activity
                    end
                    if fetch_activity_error == "OK" and fetch_activity_resp.result == "OK" and response.result ~= "OK" then
                        response.result = "OK"
                    end
                    count_down()
                end))
            end
            count_down_count = count_down_count - 1
            if count_down_count > 0 then
                coroutine.yield()
            end
            return response
        end, error_handler, coro, message)
        response = response or {
            ["result"] = "SYSTEM_BUSY",
        }
        done(response)
    end)
    assert(coroutine.resume(coro, coro, message, done))
end
Handlers["app.activity.lib.FetchActivity"] = OnHandle_FetchActivity

-- 发布活动
local function OnHandle_PublishActivity(type_name, message, done)
    local coro = coroutine.create(function(coro, message, done)
        Log.Debug("Activity", "OnHandle_PublishActivity.")
        local _, response = xpcall(function(coro, message)
            local response = {
                ["result"] = "OK",
            }

            local now_time = os.now()
            local publish_activity_req = {activitys = message.activitys, time = now_time,}
            local game_service_ids = Server.GetGameServiceIds()
            for _, game_service_id in pairs(game_service_ids) do
                assert(g_game_activity_service:PublishActivity(game_service_id, publish_activity_req, function(publish_activity_error, publish_activity_resp)
                    coroutine.resume(coro, publish_activity_error, publish_activity_resp)
                end))
                local publish_activity_error, publish_activity_resp = coroutine.yield()
                if publish_activity_error ~= "OK" or publish_activity_resp.result ~= "OK" then
                    Log.Warn("OnHandle_PublishActivity", "push activity faield: error = {}, result = {}", publish_activity_error, publish_activity_resp.result)
                    response.result = "SYSTEM_BUSY"
                end
            end
            Activity.Publish(message, now_time)
            return response
        end, error_handler, coro, message)
        response = response or {
            ["result"] = "SYSTEM_BUSY",
        }
        done(response)
    end)
    assert(coroutine.resume(coro, coro, message, done))
end
Handlers["app.activity.lib.PublishActivity"] = OnHandle_PublishActivity

-- 撤销活动
local function OnHandle_RevokeActivity(type_name, message, done)
    local coro = coroutine.create(function(coro, message, done)
        Log.Debug("Activity", "OnHandle_RevokeActivity.")
        local _, response = xpcall(function(coro, message)
            local response = {
                ["result"] = "OK",
            }
            local now_time = os.now()
            local revoke_activity_req = {ids = {}}
            for _, activity_id in pairs(message.ids or {}) do
                revoke_activity_req.ids[activity_id] = now_time
            end
            local game_service_ids = Server.GetGameServiceIds()
            for _, game_service_id in pairs(game_service_ids) do
                assert(g_game_activity_service:RevokeActivity(game_service_id, revoke_activity_req, function(revoke_activity_error, revoke_activity_resp)
                    coroutine.resume(coro, revoke_activity_error, revoke_activity_resp)
                end))
                local revoke_activity_error, revoke_activity_resp = coroutine.yield()
                if revoke_activity_error ~= "OK" or revoke_activity_resp.result ~= "OK" then
                    Log.Warn("OnHandle_RevokeActivity", "revoke activity faield: error = {}, result = {}", revoke_activity_error, revoke_activity_resp.result)
                    response.result = "SYSTEM_BUSY"
                end
            end
            Activity.Revoke(message, now_time)
            return response
        end, error_handler, coro, message)
        response = response or {
            ["result"] = "SYSTEM_BUSY",
        }
        done(response)
    end)
    assert(coroutine.resume(coro, coro, message, done))
end
Handlers["app.activity.lib.RevokeActivity"] = OnHandle_RevokeActivity