
-- pm.TbActivityRegisterOpen



return
{
[1] = 
{
	id=1,
	open_day=1,
	activity=10101,
	start_offset=0,
	duration=86400000,
	delay=0,
},
[2] = 
{
	id=2,
	open_day=1,
	activity=10601,
	start_offset=0,
	duration=864000,
	delay=0,
},
}
