
-- pm.TbActivityMinesReward



return
{
[1] = 
{
	id=1,
	icon=10020,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	},
	rewards_random=
	{
	},
},
[2] = 
{
	id=2,
	icon=20020,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	
		{
			id=303,
			num=50,
		},
	
		{
			id=304,
			num=40,
		},
	},
	rewards_random=
	{
	},
},
[3] = 
{
	id=3,
	icon=30020,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	
		{
			id=303,
			num=100,
		},
	
		{
			id=304,
			num=40,
		},
	},
	rewards_random=
	{
	},
},
[4] = 
{
	id=4,
	icon=40020,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	
		{
			id=303,
			num=200,
		},
	
		{
			id=304,
			num=40,
		},
	},
	rewards_random=
	{
	},
},
[5] = 
{
	id=5,
	icon=50020,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	
		{
			id=303,
			num=500,
		},
	
		{
			id=304,
			num=40,
		},
	},
	rewards_random=
	{
	},
},
[6] = 
{
	id=6,
	icon=60020,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	
		{
			id=303,
			num=1000,
		},
	
		{
			id=304,
			num=40,
		},
	},
	rewards_random=
	{
	},
},
[7] = 
{
	id=7,
	icon=70020,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	
		{
			id=303,
			num=2000,
		},
	
		{
			id=304,
			num=40,
		},
	},
	rewards_random=
	{
	},
},
[11] = 
{
	id=11,
	icon=11,
	cost=
	{
		id=302,
		num=1,
	},
	open_rewards=
	{
	
		{
			id=304,
			num=40,
		},
	},
	rewards_random=
	{
	
		{
			id=303,
			num=100,
			pr=0.2,
		},
	
		{
			id=303,
			num=200,
			pr=0.2,
		},
	
		{
			id=303,
			num=500,
			pr=0.2,
		},
	
		{
			id=303,
			num=1000,
			pr=0.2,
		},
	
		{
			id=303,
			num=2000,
			pr=0.2,
		},
	},
},
}
