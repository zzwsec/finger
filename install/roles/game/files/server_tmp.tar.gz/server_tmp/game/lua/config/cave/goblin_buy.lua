
-- pm.TbCaveGoblinBuy



return
{
[1] = 
{
	id=1,
	cost=
	{
		id=0,
		num=0,
	},
},
[2] = 
{
	id=2,
	cost=
	{
		id=22,
		num=30,
	},
},
[3] = 
{
	id=3,
	cost=
	{
		id=22,
		num=300,
	},
},
[4] = 
{
	id=4,
	cost=
	{
		id=22,
		num=600,
	},
},
[5] = 
{
	id=5,
	cost=
	{
		id=22,
		num=900,
	},
},
[6] = 
{
	id=6,
	cost=
	{
		id=22,
		num=1200,
	},
},
[7] = 
{
	id=7,
	cost=
	{
		id=22,
		num=1500,
	},
},
[8] = 
{
	id=8,
	cost=
	{
		id=22,
		num=1500,
	},
},
[9] = 
{
	id=9,
	cost=
	{
		id=22,
		num=1500,
	},
},
[10] = 
{
	id=10,
	cost=
	{
		id=22,
		num=1500,
	},
},
[11] = 
{
	id=11,
	cost=
	{
		id=22,
		num=1500,
	},
},
[12] = 
{
	id=12,
	cost=
	{
		id=22,
		num=1500,
	},
},
[13] = 
{
	id=13,
	cost=
	{
		id=22,
		num=1500,
	},
},
[14] = 
{
	id=14,
	cost=
	{
		id=22,
		num=1500,
	},
},
[15] = 
{
	id=15,
	cost=
	{
		id=22,
		num=1500,
	},
},
[16] = 
{
	id=16,
	cost=
	{
		id=22,
		num=1500,
	},
},
[17] = 
{
	id=17,
	cost=
	{
		id=22,
		num=1500,
	},
},
[18] = 
{
	id=18,
	cost=
	{
		id=22,
		num=1500,
	},
},
[19] = 
{
	id=19,
	cost=
	{
		id=22,
		num=1500,
	},
},
[20] = 
{
	id=20,
	cost=
	{
		id=22,
		num=1500,
	},
},
[21] = 
{
	id=21,
	cost=
	{
		id=22,
		num=1500,
	},
},
[22] = 
{
	id=22,
	cost=
	{
		id=22,
		num=1500,
	},
},
[23] = 
{
	id=23,
	cost=
	{
		id=22,
		num=1500,
	},
},
[24] = 
{
	id=24,
	cost=
	{
		id=22,
		num=1500,
	},
},
[25] = 
{
	id=25,
	cost=
	{
		id=22,
		num=1500,
	},
},
[26] = 
{
	id=26,
	cost=
	{
		id=22,
		num=1500,
	},
},
[27] = 
{
	id=27,
	cost=
	{
		id=22,
		num=1500,
	},
},
[28] = 
{
	id=28,
	cost=
	{
		id=22,
		num=1500,
	},
},
[29] = 
{
	id=29,
	cost=
	{
		id=22,
		num=1500,
	},
},
[30] = 
{
	id=30,
	cost=
	{
		id=22,
		num=1500,
	},
},
}
