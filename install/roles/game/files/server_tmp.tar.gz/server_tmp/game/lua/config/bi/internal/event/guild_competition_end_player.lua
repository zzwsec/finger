
-- pm.TbBiInternalEventGuildCompetitionEndPlayer



return
{
[1] = 
{
	id=1,
	field="player_id",
	name="玩家id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="guild_id",
	name="公会id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="player_contribute",
	name="个人今日贡献",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="player_totle_contribute",
	name="个人总贡献",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="day_mail",
	name="每日邮件状态",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="week_mail",
	name="每周邮件状态",
	type=0,
	opt=1,
	default_value="0",
},
}
