
-- pm.TbActivityDateOpen



return
{
[1] = 
{
	id=1,
	activity=20701,
	begin_time=1736697600,
	end_time=1737036000,
	server_days=15,
	delay=0,
},
[2] = 
{
	id=2,
	activity=12701,
	begin_time=1737043200,
	end_time=1737302390,
	server_days=15,
	delay=0,
},
[3] = 
{
	id=3,
	activity=20901,
	begin_time=1736697600,
	end_time=1737302390,
	server_days=15,
	delay=0,
},
}
