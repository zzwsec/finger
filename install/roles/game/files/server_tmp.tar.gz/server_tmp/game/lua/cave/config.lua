
local ResourceConfig = import("config/cave/resource", true)

local M = {}

function M.ResourcePoolConfig(level)
    local configs = {}
    for _, item in pairs(ResourceConfig or {}) do
        if item.player_level <= level then
            table.insert(configs, item)
        end
    end
    return configs
end

return M