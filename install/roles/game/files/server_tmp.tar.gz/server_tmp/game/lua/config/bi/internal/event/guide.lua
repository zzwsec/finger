
-- pm.TbBiInternalEventGuide



return
{
[1] = 
{
	id=1,
	field="guide_id",
	name="引导id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="guide_group",
	name="引导组id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="guide_type",
	name="引导类型",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="group_status",
	name="引导组完成状态",
	type=0,
	opt=1,
	default_value="",
},
}
