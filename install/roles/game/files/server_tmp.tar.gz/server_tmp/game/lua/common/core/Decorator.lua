local class = require "utils.class"

local BaseNode = require 'core.BaseNode'

local Decorator = class("Decorator", BaseNode)

function Decorator:ctor(params)
    BaseNode.ctor(self, params)

    if not params then
        params = {}
    end

    self.child = params.child or nil
end

return Decorator
