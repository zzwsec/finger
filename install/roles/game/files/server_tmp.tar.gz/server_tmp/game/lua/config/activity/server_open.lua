
-- pm.TbActivityServerOpen



return
{
[1] = 
{
	id=1,
	open_day=1,
	activity=10401,
	start_offset=0,
	duration=252000,
	delay=0,
},
[2] = 
{
	id=2,
	open_day=1,
	activity=10501,
	start_offset=0,
	duration=597600,
	delay=0,
},
[3] = 
{
	id=3,
	open_day=1,
	activity=11201,
	start_offset=0,
	duration=604799,
	delay=0,
},
[4] = 
{
	id=4,
	open_day=1,
	activity=11401,
	start_offset=0,
	duration=604799,
	delay=0,
},
[5] = 
{
	id=5,
	open_day=1,
	activity=11601,
	start_offset=0,
	duration=604799,
	delay=0,
},
[6] = 
{
	id=6,
	open_day=1,
	activity=20301,
	start_offset=0,
	duration=604799,
	delay=0,
},
[7] = 
{
	id=7,
	open_day=1,
	activity=20501,
	start_offset=0,
	duration=604799,
	delay=0,
},
[8] = 
{
	id=8,
	open_day=1,
	activity=20601,
	start_offset=0,
	duration=604799,
	delay=0,
},
[9] = 
{
	id=9,
	open_day=1,
	activity=20101,
	start_offset=0,
	duration=1727999,
	delay=0,
},
[10] = 
{
	id=10,
	open_day=2,
	activity=10301,
	start_offset=0,
	duration=252000,
	delay=0,
},
[11] = 
{
	id=11,
	open_day=2,
	activity=10701,
	start_offset=0,
	duration=252000,
	delay=93600,
},
[12] = 
{
	id=12,
	open_day=2,
	activity=11701,
	start_offset=0,
	duration=345599,
	delay=0,
},
[13] = 
{
	id=13,
	open_day=3,
	activity=20701,
	start_offset=0,
	duration=252000,
	delay=0,
},
[14] = 
{
	id=14,
	open_day=4,
	activity=12701,
	start_offset=0,
	duration=259199,
	delay=0,
},
[16] = 
{
	id=16,
	open_day=5,
	activity=11901,
	start_offset=0,
	duration=431999,
	delay=0,
},
[18] = 
{
	id=18,
	open_day=1,
	activity=20401,
	start_offset=0,
	duration=86399999,
	delay=0,
},
}
