
-- pm.TbBiKingnetEventActivityRanks



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="活动id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="type",
	name="排名类型",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="num1",
	name="活动排行",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="num2",
	name="活动数据",
	type=0,
	opt=1,
	default_value="0",
},
}
