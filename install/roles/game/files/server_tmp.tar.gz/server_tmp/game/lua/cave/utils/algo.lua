
local Lamda = require("common/lamda")
local Log = require("common/logging")

local M = {}

-- 加权随机选择算法 alias method
local AliasMultionmial = class("AliasMultionmial")
M.AliasMultionmial = AliasMultionmial

function AliasMultionmial:ctor(weights)
    assert(type(weights) == 'table' and next(weights) ~= nil, "weights invaild.")
    self.weights_ = weights
    self.total_weight = Lamda.sum(self.weights_)
    assert(self.total_weight > 0, "total weight is zero.")

    self.len = #weights
    self.alias_ = {}
    self.probs_ = {}
    self:_preprocess()
end

function AliasMultionmial:alias()
    return self.alias_
end

function AliasMultionmial:probs()
    return self.probs_
end

function AliasMultionmial:_preprocess()
    local smaller = {}
    local larger = {}
    local q = {}
    local normalize = self.len / self.total_weight
    for i, w in ipairs(self.weights_) do 
        q[i] = w * normalize
        if q[i] < 1 then 
            table.insert(smaller, i)
        else 
            table.insert(larger, i)
        end
    end

    while #smaller > 0 and #larger > 0 do 
        local small = table.remove(smaller)
        local large = table.remove(larger)
        
        self.probs_[small] = q[small]
        self.alias_[small] = large
        q[large] = q[large] - (1.0 - q[small])

        if q[large] < 1 then 
            table.insert(smaller, large)
        else 
            table.insert(larger, large)
        end
    end

    for _, v in ipairs(larger) do self.probs_[v] = 1 end
    for _, v in ipairs(smaller) do self.probs_[v] = 1 end
end

function AliasMultionmial:next()
    local index = g_random:Next(1, self.len)
    if g_random:Next() < self.probs_[index] then 
        return index
    else 
        return self.alias_[index]
    end
end 

return M