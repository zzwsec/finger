
-- pm.TbBiInternalEventRelicSlotPet



return
{
[1] = 
{
	id=1,
	field="area_id",
	name="区域id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="pet_id",
	name="宠物id",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="pet_star",
	name="宠物星级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="old_pet_id",
	name="宠物id",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="old_pet_star",
	name="宠物星级",
	type=0,
	opt=1,
	default_value="0",
},
[6] = 
{
	id=6,
	field="reward",
	name="累计积分",
	type=0,
	opt=1,
	default_value="",
},
}
