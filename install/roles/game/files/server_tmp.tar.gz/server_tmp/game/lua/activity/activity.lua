local Log = require("common/logging")

local Const = import("activity/const")
local Config = import("activity/config")
local Convert = import("activity/convert")
local LastCheck = import("activity/last_check")
local TimePolicy = import("activity/time_policy")

Modules.Activity_MODULE = Modules.Activity_MODULE or {}
local M = Modules.Activity_MODULE

Globals.LastRankList = Globals.LastRankList or {}

-- 编码
function M.Encode(type, index)
    return type * 100 + index
end

-- 解码
function M.Decode(id)
    return id // 100, id % 100
end

function M.LastRankList()
    return Globals.LastRankList
end

function M.IsRank(id, active, begin_time, end_time, now_time)
    local active_type, active_index = M.Decode(id)
    local isChanged = function(ac_type)
        local last_rank_list = M.LastRankList()
        local active = last_rank_list[ac_type]
        if active == nil then
            if begin_time < now_time and end_time > now_time then
                return true
            end
            return false
        end
        if begin_time < now_time and end_time > now_time and (active.start_time ~= begin_time or active.end_time ~= end_time) then
            return true
        end
        return false
    end
    local rank_type = active.rank ~= 0 and active.rank or active.guild_rank
    if rank_type == 0 then
        return false
    end
    if not isChanged(active_type) then
        return false
    end
    return true, {
        ["id"] = rank_type,
        ["active_id"] = id,
        ["active_type"] = active_type,
        ["start_time"] = begin_time,
        ["duration_time"] = end_time - begin_time,
        ["interval_time"] = 0,
        ["reset_type"] = 1,
        ["records"] = 1,
        ["index"] = active_index,
    }
end

function M.UpdateLastRankList(rank_list)
    for _, active in pairs(rank_list or {}) do
        Globals.LastRankList[active.active_type] = {
            ["start_time"] = active.start_time,
            ["end_time"] = active.start_time + active.duration_time,
        }
    end
    Log.Debug("UpdateLastRankList", "Last Rank List = {}", Globals.LastRankList)
end

-- 检测活动开放
function M.CheckOpen(now_time, last_time)
    local change = false
    local open_list = {}
    local rank_list = {}
    local guild_rank_list = {}
    local active_list = M.ActivityList(now_time)
    local last_check_list = LastCheck.OpenLastCheckList()

    local state_handlers = {
        [Const.ActiveState.OPEN] = function(id, state, time) 
            M.OpenActive(id)
            last_check_list[id] = time
            open_list[id] = state
            return true
        end,
        [Const.ActiveState.CLOSED] = function(id, state, time)
            M.CloseActive(id)
            last_check_list[id] = nil
            open_list[id] = state
            return true
        end
    }

    local active_state = function(id, begin_time, end_time, time, now)
        local state = 0
        repeat
            if begin_time == 0 or end_time == 0 then 
                state = Const.ActiveState.CLOSED
                break
            end

            if time == 0 then 
                if now >= begin_time and now < end_time then
                    state = Const.ActiveState.OPEN
                end
                break
            end
            if time >= begin_time and time <= end_time then 
                if now >= begin_time and now < end_time then 
                    state = Const.ActiveState.RUNING
                else 
                    state = Const.ActiveState.CLOSED
                end
            else
                if now >= begin_time and now < end_time then 
                    state = Const.ActiveState.OPEN
                else 
                    state = Const.ActiveState.CLOSED
                end
            end
        until true
        return state
    end

    local check_state = function(id, begin_time, end_time, time, now) 
        local state = active_state(id, begin_time, end_time, time, now)
        local handler = state_handlers[state] or function(...) return false end
        return handler(id, state, now)
    end

    -- Log.Debug("CheckOpen", "active_list = {}, last_check_list = {}", active_list, last_check_list)
    for id, active in pairs(active_list or {}) do 
        local begin_time, end_time = M.ActivityTime(active, now_time)
        local is_rank, rank_active = M.IsRank(id, active, begin_time, end_time, now_time)
        if is_rank then
            if active.rank > 0 then
                rank_list[rank_active.id] = rank_active
            end
            if active.guild_rank > 0 then
                guild_rank_list[rank_active.id] = rank_active
            end
        end
        local result = check_state(id, begin_time, end_time, last_check_list[id] or 0, now_time)
        change = change or result
    end
    if change then
        LastCheck.Merge()
    end
    return open_list, rank_list, guild_rank_list
end

-- 活动列表
function M.ActivityList(now_time)
    now_time = now_time or os.now()
    local open_list = {}
    TimePolicy.Invoke(open_list, now_time)
    return open_list
end


-- 通过配置中的活动时间转换为时间戳
function M.ActivityTime(config, now_time)
    local begin_time, end_time = 0, 0
    local time_solt = config.time_solt
    if time_solt ~= nil then 
        begin_time, end_time = time_solt.begin_time, time_solt.end_time
    end
    return begin_time, end_time
end

-- 活动开放
function M.OpenActive(id)
    g_player_manager:ClearActivityById(id)
end

-- 活动关闭
function M.CloseActive(activity_id)
    local player_ids = g_player_manager:GetPlayersByActivityId(activity_id)
    for _, player_id in pairs(player_ids or {}) do 
        local player = g_player_manager:GetPlayerById(player_id)
        if player ~= nil then 
            player:PostEvent("ActivityOpenTimeEvent", {
                ["id"] = activity_id, 
                ["state"] = Const.ActiveState.CLOSED,
            })
        end
    end
    g_player_manager:ClearActivityById(activity_id)
end

-- 活动撤销
function M.Revoke(msg, now)
end

-- 活动发布
function M.Publish(msg, now)
end

return M