
-- pm.TbBiInternalEventBuildLevelupStar



return
{
[1] = 
{
	id=1,
	field="build_id",
	name="建筑id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="level",
	name="建筑等级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="queue_id",
	name="队列id",
	type=0,
	opt=1,
	default_value="",
},
}
