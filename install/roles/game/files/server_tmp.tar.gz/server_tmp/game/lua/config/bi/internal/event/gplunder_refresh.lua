
-- pm.TbBiInternalEventGplunderRefresh



return
{
[1] = 
{
	id=1,
	field="times",
	name="次数",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="stage",
	name="阶段",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="monsters",
	name="怪物信息",
	type=1,
	opt=1,
	default_value="0",
},
}
