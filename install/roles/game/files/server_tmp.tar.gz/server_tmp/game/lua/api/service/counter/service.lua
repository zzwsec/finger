local Log = require("common.logging")
local Result = import("common.result")

local ConfigUtility = import("api.utility.config")
local CounterRemote = import("api.service.counter.remote")

local ServerOptions = ConfigUtility.ServerOptions
local ProjectId = ServerOptions.ProjectId

local _M = {}

-- 创建计数器
function _M.Create(coro, message)
    local counter_id = message.counter_id or ""
    local value = message.value or 0
    local ttl = message.ttl or 0

    local create_result = CounterRemote.Create(coro, {
        project_id = ProjectId,
        counter_id = counter_id,
        value = value,
        ttl = ttl
    })
    if create_result:is_err() then
        Log.Warn("CreateCounter", "Failed to create counter: {}", create_result:unwrap_err())
        return create_result
    end

    local counter = create_result:unwrap()
    if not counter then
        Log.Warn("CreateCounter", "counter is nil")
        return Result.err("SYSTEM_BUSY")
    end
    return Result.ok(counter)
end

-- 获取计数器
function _M.Get(coro, message)
    local counter_id = message.counter_id or ""

    local get_result = CounterRemote.Get(coro, {
        project_id = ProjectId,
        counter_id = counter_id
    })
    if get_result:is_err() then
        Log.Warn("GetCounter", "Failed to get counter: {}", get_result:unwrap_err())
        return get_result
    end

    local counter = get_result:unwrap()
    if not counter then
        Log.Warn("GetCounter", "counter is nil")
        return Result.err("SYSTEM_BUSY")
    end
    return Result.ok(counter)
end

-- 批量获取计数器
function _M.BatchGet(coro, message)
    local counter_ids = message.counter_ids or {}
    return CounterRemote.BatchGet(coro, {
        ids = counter_ids,
        project_id = ProjectId
    })
end

-- 删除计数器
function _M.Delete(coro, message)
    local counter_id = message.counter_id or ""
    local delete_result = CounterRemote.Delete(coro, {
        project_id = ProjectId,
        counter_id = counter_id
    })
    return delete_result
end

-- 增加计数器
function _M.Increment(coro, message)
    local counter_id = message.counter_id or ""
    local step = message.step or 1
    return CounterRemote.Increment(coro, {
        project_id = ProjectId,
        counter_id = counter_id,
        step = step
    })
end

-- 减少计数器
function _M.Decrement(coro, message)
    local counter_id = message.counter_id or ""
    local step = message.step or 1
    return CounterRemote.Decrement(coro, {
        project_id = ProjectId,
        counter_id = counter_id,
        step = step
    })
end

return _M