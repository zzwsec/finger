
-- pm.TbGoldCaveLevel



return
{
[1] = 
{
	id=1,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	3,
	3,
	},
	max_times=9,
	reverse_guart=4,
	guart_times=9,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=33,
			num=100,
		},
	
		{
			id=17,
			num=3,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=1000,
		},
	
		{
			id=102041,
			num=9000,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.1,
		},
	
		{
			value=2,
			pr=0.27,
		},
	
		{
			value=3,
			pr=0.63,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=100,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=3,
			limit=1,
			type=1,
		},
	},
},
[2] = 
{
	id=2,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	3,
	3,
	},
	max_times=9,
	reverse_guart=4,
	guart_times=9,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=33,
			num=150,
		},
	
		{
			id=17,
			num=4,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=1000,
		},
	
		{
			id=102041,
			num=9000,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.1,
		},
	
		{
			value=2,
			pr=0.27,
		},
	
		{
			value=3,
			pr=0.63,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=150,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=4,
			limit=1,
			type=1,
		},
	},
},
[3] = 
{
	id=3,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	3,
	3,
	},
	max_times=9,
	reverse_guart=4,
	guart_times=9,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=33,
			num=200,
		},
	
		{
			id=17,
			num=5,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=1000,
		},
	
		{
			id=102041,
			num=9000,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.1,
		},
	
		{
			value=2,
			pr=0.27,
		},
	
		{
			value=3,
			pr=0.63,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=200,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=5,
			limit=1,
			type=1,
		},
	},
},
[4] = 
{
	id=4,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	4,
	4,
	},
	max_times=16,
	reverse_guart=8,
	guart_times=16,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=33,
			num=250,
		},
	
		{
			id=17,
			num=8,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=500,
		},
	
		{
			id=102041,
			num=9500,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.05,
		},
	
		{
			value=2,
			pr=0.285,
		},
	
		{
			value=3,
			pr=0.665,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=250,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=8,
			limit=1,
			type=1,
		},
	},
},
[5] = 
{
	id=5,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	4,
	4,
	},
	max_times=16,
	reverse_guart=8,
	guart_times=16,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=33,
			num=300,
		},
	
		{
			id=17,
			num=10,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=500,
		},
	
		{
			id=102041,
			num=9500,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.05,
		},
	
		{
			value=2,
			pr=0.285,
		},
	
		{
			value=3,
			pr=0.665,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=300,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=10,
			limit=1,
			type=1,
		},
	},
},
[6] = 
{
	id=6,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	4,
	4,
	},
	max_times=16,
	reverse_guart=8,
	guart_times=16,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=117,
			num=1,
		},
	
		{
			id=17,
			num=10,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=500,
		},
	
		{
			id=102041,
			num=9500,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.05,
		},
	
		{
			value=2,
			pr=0.285,
		},
	
		{
			value=3,
			pr=0.665,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=117,
			num=1,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=10,
			limit=1,
			type=1,
		},
	},
},
[7] = 
{
	id=7,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	4,
	4,
	},
	max_times=16,
	reverse_guart=8,
	guart_times=16,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=39,
			num=8,
		},
	
		{
			id=17,
			num=12,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=500,
		},
	
		{
			id=102041,
			num=9500,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.05,
		},
	
		{
			value=2,
			pr=0.285,
		},
	
		{
			value=3,
			pr=0.665,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=39,
			num=8,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=12,
			limit=1,
			type=1,
		},
	},
},
[8] = 
{
	id=8,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	5,
	5,
	},
	max_times=25,
	reverse_guart=12,
	guart_times=25,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=39,
			num=10,
		},
	
		{
			id=17,
			num=15,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=300,
		},
	
		{
			id=102041,
			num=9700,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.03,
		},
	
		{
			value=2,
			pr=0.291,
		},
	
		{
			value=3,
			pr=0.679,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=39,
			num=10,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=15,
			limit=1,
			type=1,
		},
	},
},
[9] = 
{
	id=9,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	5,
	5,
	},
	max_times=25,
	reverse_guart=12,
	guart_times=25,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=118,
			num=1,
		},
	
		{
			id=17,
			num=15,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=300,
		},
	
		{
			id=102041,
			num=9700,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.03,
		},
	
		{
			value=2,
			pr=0.291,
		},
	
		{
			value=3,
			pr=0.679,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=118,
			num=1,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=15,
			limit=1,
			type=1,
		},
	},
},
[10] = 
{
	id=10,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	5,
	5,
	},
	max_times=25,
	reverse_guart=12,
	guart_times=25,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=119,
			num=1,
		},
	
		{
			id=17,
			num=20,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=300,
		},
	
		{
			id=102041,
			num=9700,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.03,
		},
	
		{
			value=2,
			pr=0.291,
		},
	
		{
			value=3,
			pr=0.679,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=119,
			num=1,
			limit=1,
			type=1,
		},
	
		{
			id=17,
			num=20,
			limit=1,
			type=1,
		},
	},
},
[11] = 
{
	id=11,
	cost=
	{
		id=301,
		num=1,
	},
	map_range=
	{
	5,
	5,
	},
	max_times=25,
	reverse_guart=12,
	guart_times=25,
	guart_pool=102061,
	optional_num=1,
	optional_reward=
	{
	
		{
			id=17,
			num=20,
		},
	},
	pool_prob=
	{
	
		{
			id=102061,
			num=300,
		},
	
		{
			id=102041,
			num=9700,
		},
	},
	show_prob=
	{
	
		{
			value=1,
			pr=0.03,
		},
	
		{
			value=2,
			pr=0.291,
		},
	
		{
			value=3,
			pr=0.679,
		},
	},
	show_goods=
	{
	
		{
			id=50,
			num=10,
			limit=0,
			type=3,
		},
	
		{
			id=50,
			num=5,
			limit=0,
			type=3,
		},
	
		{
			id=33,
			num=50,
			limit=0,
			type=2,
		},
	
		{
			id=33,
			num=30,
			limit=0,
			type=3,
		},
	
		{
			id=3,
			num=100,
			limit=0,
			type=2,
		},
	
		{
			id=3,
			num=50,
			limit=0,
			type=3,
		},
	
		{
			id=17,
			num=1,
			limit=0,
			type=2,
		},
	
		{
			id=17,
			num=20,
			limit=1,
			type=1,
		},
	},
},
}
