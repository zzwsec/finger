
-- pm.TbBiInternalEventPetBag



return
{
[1] = 
{
	id=1,
	field="bag_id",
	name="背包位置",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="cost_id",
	name="消耗道具id",
	type=0,
	opt=1,
	default_value="",
},
}
