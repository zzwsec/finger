local _M = {}

-- 编码Id
function _M.EncodeId(id, region_id)
    id = id or 0
    region_id = region_id or 0
    return string.format("%d_%d", id, region_id)
end

-- 解码id
function _M.DecodeId(id)
    local parts = string.split(id, "_") 
    if #parts ~= 2 then
        return 0, 0
    end
    -- id: region_id
    return tonumber(parts[1]), tonumber(parts[2])
end

return _M