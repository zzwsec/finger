
-- pm.TbRuinBoss



return
{
[1] = 
{
	id=1,
	damage=50000,
	total_damage=50000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[2] = 
{
	id=2,
	damage=100000,
	total_damage=150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[3] = 
{
	id=3,
	damage=200000,
	total_damage=350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[4] = 
{
	id=4,
	damage=400000,
	total_damage=750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[5] = 
{
	id=5,
	damage=600000,
	total_damage=1350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[6] = 
{
	id=6,
	damage=800000,
	total_damage=2150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[7] = 
{
	id=7,
	damage=1000000,
	total_damage=3150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[8] = 
{
	id=8,
	damage=1200000,
	total_damage=4350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[9] = 
{
	id=9,
	damage=1400000,
	total_damage=5750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[10] = 
{
	id=10,
	damage=1600000,
	total_damage=7350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[11] = 
{
	id=11,
	damage=1800000,
	total_damage=9150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[12] = 
{
	id=12,
	damage=2000000,
	total_damage=11150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[13] = 
{
	id=13,
	damage=2200000,
	total_damage=13350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[14] = 
{
	id=14,
	damage=2400000,
	total_damage=15750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[15] = 
{
	id=15,
	damage=2600000,
	total_damage=18350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[16] = 
{
	id=16,
	damage=2800000,
	total_damage=21150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[17] = 
{
	id=17,
	damage=3000000,
	total_damage=24150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[18] = 
{
	id=18,
	damage=3200000,
	total_damage=27350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[19] = 
{
	id=19,
	damage=3400000,
	total_damage=30750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[20] = 
{
	id=20,
	damage=3600000,
	total_damage=34350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=0.5,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[21] = 
{
	id=21,
	damage=3800000,
	total_damage=38150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[22] = 
{
	id=22,
	damage=4000000,
	total_damage=42150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[23] = 
{
	id=23,
	damage=4200000,
	total_damage=46350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[24] = 
{
	id=24,
	damage=4400000,
	total_damage=50750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[25] = 
{
	id=25,
	damage=4600000,
	total_damage=55350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[26] = 
{
	id=26,
	damage=4800000,
	total_damage=60150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[27] = 
{
	id=27,
	damage=5000000,
	total_damage=65150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[28] = 
{
	id=28,
	damage=5200000,
	total_damage=70350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[29] = 
{
	id=29,
	damage=5400000,
	total_damage=75750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[30] = 
{
	id=30,
	damage=5600000,
	total_damage=81350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[31] = 
{
	id=31,
	damage=5800000,
	total_damage=87150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[32] = 
{
	id=32,
	damage=6000000,
	total_damage=93150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[33] = 
{
	id=33,
	damage=6200000,
	total_damage=99350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[34] = 
{
	id=34,
	damage=6400000,
	total_damage=105750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[35] = 
{
	id=35,
	damage=6600000,
	total_damage=112350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[36] = 
{
	id=36,
	damage=6800000,
	total_damage=119150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[37] = 
{
	id=37,
	damage=7000000,
	total_damage=126150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[38] = 
{
	id=38,
	damage=7200000,
	total_damage=133350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[39] = 
{
	id=39,
	damage=7400000,
	total_damage=140750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[40] = 
{
	id=40,
	damage=7600000,
	total_damage=148350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=1,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[41] = 
{
	id=41,
	damage=7800000,
	total_damage=156150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[42] = 
{
	id=42,
	damage=8000000,
	total_damage=164150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[43] = 
{
	id=43,
	damage=8200000,
	total_damage=172350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[44] = 
{
	id=44,
	damage=8400000,
	total_damage=180750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[45] = 
{
	id=45,
	damage=8600000,
	total_damage=189350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[46] = 
{
	id=46,
	damage=8800000,
	total_damage=198150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[47] = 
{
	id=47,
	damage=9000000,
	total_damage=207150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[48] = 
{
	id=48,
	damage=9200000,
	total_damage=216350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[49] = 
{
	id=49,
	damage=9400000,
	total_damage=225750000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[50] = 
{
	id=50,
	damage=9600000,
	total_damage=235350000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[51] = 
{
	id=51,
	damage=9800000,
	total_damage=245150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[52] = 
{
	id=52,
	damage=10000000,
	total_damage=255150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[53] = 
{
	id=53,
	damage=11000000,
	total_damage=266150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[54] = 
{
	id=54,
	damage=12000000,
	total_damage=278150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[55] = 
{
	id=55,
	damage=13000000,
	total_damage=291150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[56] = 
{
	id=56,
	damage=14000000,
	total_damage=305150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[57] = 
{
	id=57,
	damage=15000000,
	total_damage=320150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[58] = 
{
	id=58,
	damage=16000000,
	total_damage=336150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[59] = 
{
	id=59,
	damage=17000000,
	total_damage=353150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[60] = 
{
	id=60,
	damage=18000000,
	total_damage=371150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=2,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[61] = 
{
	id=61,
	damage=19000000,
	total_damage=390150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[62] = 
{
	id=62,
	damage=20000000,
	total_damage=410150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[63] = 
{
	id=63,
	damage=22000000,
	total_damage=432150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[64] = 
{
	id=64,
	damage=24000000,
	total_damage=456150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[65] = 
{
	id=65,
	damage=26000000,
	total_damage=482150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[66] = 
{
	id=66,
	damage=28000000,
	total_damage=510150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[67] = 
{
	id=67,
	damage=30000000,
	total_damage=540150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[68] = 
{
	id=68,
	damage=32000000,
	total_damage=572150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[69] = 
{
	id=69,
	damage=34000000,
	total_damage=606150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[70] = 
{
	id=70,
	damage=36000000,
	total_damage=642150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[71] = 
{
	id=71,
	damage=38000000,
	total_damage=680150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[72] = 
{
	id=72,
	damage=40000000,
	total_damage=720150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[73] = 
{
	id=73,
	damage=42000000,
	total_damage=762150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[74] = 
{
	id=74,
	damage=44000000,
	total_damage=806150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[75] = 
{
	id=75,
	damage=46000000,
	total_damage=852150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[76] = 
{
	id=76,
	damage=48000000,
	total_damage=900150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[77] = 
{
	id=77,
	damage=50000000,
	total_damage=950150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[78] = 
{
	id=78,
	damage=52000000,
	total_damage=1002150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[79] = 
{
	id=79,
	damage=54000000,
	total_damage=1056150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
[80] = 
{
	id=80,
	damage=56000000,
	total_damage=1112150000,
	npc_attrs=
	{
	
		{
			id=202,
			value=3,
		},
	},
	rewards=
	{
	
		{
			id=30,
			num=2,
		},
	
		{
			id=1,
			num=30,
		},
	},
},
}
