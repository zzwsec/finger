
-- pm.TbBiKingnetEventMailAdd



return
{
[1] = 
{
	id=1,
	field="mail_id",
	name="邮件id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="mail_index",
	name="邮件索引",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="create_time",
	name="创建时间",
	type=1,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="begin_time",
	name="生效时间",
	type=1,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="expire_time",
	name="过期时间",
	type=1,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="goods",
	name="道具",
	type=1,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="way",
	name="途径",
	type=0,
	opt=1,
	default_value="",
},
}
