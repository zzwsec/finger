
-- pm.TbBiInternalEventBoss



return
{
[1] = 
{
	id=1,
	field="round",
	name="轮数id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="damage",
	name="伤害",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="player_power",
	name="玩家战力",
	type=0,
	opt=1,
	default_value="",
},
}
