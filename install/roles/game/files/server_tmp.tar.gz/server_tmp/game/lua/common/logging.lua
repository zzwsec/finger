﻿local M = {}

local Log = require("app.common")
local Fmt = require("format")

-- 日志对象
assert(g_logger, "no set logger environment variablies")

-- 日志级别
local SeverityLevel = {
    --追踪级别
    TRACE = 0,
    -- 调试级别
    DEBUG = 1,
    -- 信息级别
    INFO = 2,
    -- 警告级别
    WARN = 3,
    -- 错误级别
    ERROR = 4,
}

-- 格式化参数
local function FormatArgs(...)
    local args = {...}
    for i = 0, #args do 
        if type(args[i]) == 'table' then 
            args[i] = table.dump(args[i])
        elseif args[i] == nil then
            args[i] = 'nil'
        end
    end
    return table.unpack(args)
end

-- 追踪
function M.Trace(tag, fmt, ...)
    Log.Log(g_logger, SeverityLevel.TRACE, tag, Fmt.Format(fmt, FormatArgs(...)))
end

-- 追
function M.Debug(tag, fmt, ...)
    Log.Log(g_logger, SeverityLevel.DEBUG, tag, Fmt.Format(fmt, FormatArgs(...)))
end

-- 信息
function M.Info(tag, fmt, ...)
    Log.Log(g_logger, SeverityLevel.INFO, tag, Fmt.Format(fmt, FormatArgs(...)))
end

-- 警告
function M.Warn(tag, fmt, ...)
    Log.Logp(g_logger, SeverityLevel.WARN, tag, Fmt.Format(fmt, FormatArgs(...)), debug.traceback(nil, 2))
end

-- 错误
function M.Error(tag, fmt, ...)
    Log.Logp(g_logger, SeverityLevel.ERROR, tag, Fmt.Format(fmt, FormatArgs(...)), debug.traceback(nil, 2))
end

return M