
-- pm.TbActivityAccelerateRepayRefresh



return
{
[1] = 
{
	id=1,
	refresh_range=
	{
	1,
	3,
	},
	refresh_cost=
	{
		id=1,
		num=0,
	},
	refresh_cd=3,
},
[2] = 
{
	id=2,
	refresh_range=
	{
	4,
	5,
	},
	refresh_cost=
	{
		id=1,
		num=20,
	},
	refresh_cd=3,
},
[3] = 
{
	id=3,
	refresh_range=
	{
	6,
	8,
	},
	refresh_cost=
	{
		id=1,
		num=50,
	},
	refresh_cd=3,
},
[4] = 
{
	id=4,
	refresh_range=
	{
	9,
	10,
	},
	refresh_cost=
	{
		id=1,
		num=100,
	},
	refresh_cd=3,
},
}
