local class = require "utils.class"
local Constants = require "core.Constants"
local uuid = require "utils.uuid"

local BaseNode = class("BaseNode")

function BaseNode:ctor(params)
    self.id = uuid()
    self.name = ""
    self.title = self.title or self.name
    self.description = ""
    self.parameters = {}
    self.properties = {}
end

function BaseNode:_execute(tick)
    --ENTER
    self:_enter(tick)

    --OPEN
    if not (tick.blackboard:get("isOpen", tick.tree.id, self.id)) then
        self:_open(tick)
    end

    --TICK
    local status = self:_tick(tick)

    --CLOSE
    if status ~= Constants.RUNNING then
        self:_close(tick)
    end

    --EXIT
    self:_exit(tick)

    return status
end

function BaseNode:_enter(tick)
    tick:_enterNode(self)
    self:enter(tick)
end

function BaseNode:_open(tick)
    tick:_openNode(self)
    tick.blackboard:set("isOpen", true, tick.tree.id, self.id)
    self:open(tick)
end

function BaseNode:_tick(tick)
    tick:_tickNode(self)
    return self:tick(tick)
end

function BaseNode:_close(tick)
    tick:_closeNode(self)
    tick.blackboard:set("isOpen", false, tick.tree.id, self.id)
    self:close(tick)
end

function BaseNode:_exit(tick)
    tick:_exitNode(self)
    self:exit(tick)
end

function BaseNode:enter(tick)
end

function BaseNode:open(tick)
end

function BaseNode:tick(tick)
end

function BaseNode:close(tick)
end

function BaseNode:exit(tick)
end

return BaseNode

