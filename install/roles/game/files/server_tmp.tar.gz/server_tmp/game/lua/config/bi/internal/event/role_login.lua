
-- pm.TbBiInternalEventRoleLogin



return
{
[1] = 
{
	id=1,
	field="client_ip",
	name="用户的客户端ip",
	type=1,
	opt=1,
	default_value="",
},
}
