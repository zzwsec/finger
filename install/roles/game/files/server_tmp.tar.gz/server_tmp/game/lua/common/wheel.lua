local math = require("math")
local table = require("table")

local M = {}

M.Wheel = M.Wheel or {}
M.Wheel.__index = M.Wheel

-- 创建函数
function M.Wheel.new(...)
    local o = {}
    setmetatable(o, M.Wheel)
    o:ctor(...)
    return o
end

-- 构造函数
function M.Wheel:ctor(base, len)
    base = base or 0
    len = len or 120
    self.base_ = base
    self.value_ = base
    self.slots_ = {}
    for i = 1, len do
        self.slots_[i] = {}
    end
    self.temps_ = {}
end

-- 添加时间点
-- timepoint:wheel_value()
-- timepoint:wheel_index()
-- timepoint:set_wheel_index(index)
function M.Wheel:Add(timepoint)
    local slot_size = #self.slots_
    local next_base = self.base_ + slot_size
    local value = timepoint:wheel_value()
    local pos
    if value >= next_base then
        if self.value_ > self.base_ then
            pos = math.min(value, self.value_ + slot_size - 1) - next_base + 1
        else
            pos = slot_size
        end
    else
        pos = math.max(value, self.value_) - self.base_ + 1
    end
    local slots = self.slots_[pos]
    timepoint:set_wheel_index(pos)
    slots[timepoint] = timepoint
end

-- 移除时间点
function M.Wheel:Remove(timepoint)
    local pos = timepoint:wheel_index()
    local slots = self.slots_[pos]
    slots[timepoint] = nil
end

local function WheelCheck(slots, value, expireds, temps)
    for timepoint in pairs(slots) do
        if timepoint:wheel_value() < value then
            timepoint:set_wheel_index(0)
            table.insert(expireds, timepoint)
        else
            table.insert(temps, timepoint)
        end
        slots[timepoint] = nil
    end
end

-- 滴答超时
function M.Wheel:Check(value, expireds)
    local slots_size = #self.slots_
    local temps = self.temps_
    if self.value_ + slots_size > value then
        while self.value_ < value do
            local pos = self.value_ - self.base_ + 1
            local slots = self.slots_[pos]
            WheelCheck(slots, value, expireds, temps)
            self.value_ = self.value_ + 1
            if self.value_ == self.base_ + slots_size then
                self.base_ = self.value_
            end
        end
    else
        for _, slots in ipairs(self.slots_) do
            WheelCheck(slots, value, expireds, temps)
        end
        self.base_ = value
        self.value_ = value 
    end
    for i, timepoint in ipairs(temps) do
        self:Add(timepoint)
        temps[i] = nil
    end
    return expireds
end

return M.Wheel