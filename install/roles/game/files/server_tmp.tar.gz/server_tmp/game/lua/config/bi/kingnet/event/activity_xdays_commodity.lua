
-- pm.TbBiKingnetEventActivityXdaysCommodity



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="活动id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="num",
	name="活动开启天数",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="num1",
	name="购买商品对应天数",
	type=0,
	opt=1,
	default_value="0",
},
}
