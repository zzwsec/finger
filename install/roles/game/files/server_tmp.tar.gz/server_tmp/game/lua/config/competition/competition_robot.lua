
-- pm.TbCompetitionRobot



return
{
[20001] = 
{
	id=20001,
	name={key='pvp_robot/20001',text="汤森德阿瑞斯"},
	title_level=11,
	head=3001,
	add_num=10,
},
[20002] = 
{
	id=20002,
	name={key='pvp_robot/20002',text="卡伦达内森"},
	title_level=11,
	head=3001,
	add_num=11,
},
[20003] = 
{
	id=20003,
	name={key='pvp_robot/20003',text="梅尔梅森"},
	title_level=11,
	head=3001,
	add_num=12,
},
[20004] = 
{
	id=20004,
	name={key='pvp_robot/20004',text="姬娜哈里斯"},
	title_level=11,
	head=3001,
	add_num=13,
},
[20005] = 
{
	id=20005,
	name={key='pvp_robot/20005',text="罗伯特科俄斯"},
	title_level=11,
	head=3001,
	add_num=14,
},
[20006] = 
{
	id=20006,
	name={key='pvp_robot/20006',text="拉特尔葛妮丝"},
	title_level=11,
	head=3001,
	add_num=15,
},
[20007] = 
{
	id=20007,
	name={key='pvp_robot/20007',text="罗比梅森"},
	title_level=11,
	head=3001,
	add_num=16,
},
[20008] = 
{
	id=20008,
	name={key='pvp_robot/20008',text="温蒂列达尼"},
	title_level=11,
	head=3001,
	add_num=17,
},
[20009] = 
{
	id=20009,
	name={key='pvp_robot/20009',text="兰迪奥尔本"},
	title_level=11,
	head=3001,
	add_num=18,
},
[20010] = 
{
	id=20010,
	name={key='pvp_robot/20010',text="哈兰德保拉"},
	title_level=11,
	head=3001,
	add_num=20,
},
[20011] = 
{
	id=20011,
	name={key='pvp_robot/20011',text="克洛怡汉考克"},
	title_level=11,
	head=3001,
	add_num=100,
},
[20012] = 
{
	id=20012,
	name={key='pvp_robot/20012',text="赛西亚艾尔莎"},
	title_level=11,
	head=3001,
	add_num=110,
},
[20013] = 
{
	id=20013,
	name={key='pvp_robot/20013',text="尼斯提亚"},
	title_level=11,
	head=3001,
	add_num=120,
},
[20014] = 
{
	id=20014,
	name={key='pvp_robot/20014',text="玛琪伊娃"},
	title_level=11,
	head=3001,
	add_num=130,
},
[20015] = 
{
	id=20015,
	name={key='pvp_robot/20015',text="伊娃阿布"},
	title_level=11,
	head=3001,
	add_num=140,
},
[20016] = 
{
	id=20016,
	name={key='pvp_robot/20016',text="金伯利贝基"},
	title_level=11,
	head=3001,
	add_num=150,
},
[20017] = 
{
	id=20017,
	name={key='pvp_robot/20017',text="雷尔夫埃布尔"},
	title_level=11,
	head=3001,
	add_num=160,
},
[20018] = 
{
	id=20018,
	name={key='pvp_robot/20018',text="简安葛妮丝"},
	title_level=11,
	head=3001,
	add_num=170,
},
[20019] = 
{
	id=20019,
	name={key='pvp_robot/20019',text="美索亚奥尔丁"},
	title_level=11,
	head=3001,
	add_num=180,
},
[20020] = 
{
	id=20020,
	name={key='pvp_robot/20020',text="汤姆森特雷尔"},
	title_level=11,
	head=3001,
	add_num=200,
},
[20021] = 
{
	id=20021,
	name={key='pvp_robot/20021',text="阿方索罗威尔"},
	title_level=11,
	head=3001,
	add_num=200,
},
[20022] = 
{
	id=20022,
	name={key='pvp_robot/20022',text="罗比默多克"},
	title_level=11,
	head=3001,
	add_num=220,
},
[20023] = 
{
	id=20023,
	name={key='pvp_robot/20023',text="梅克尔哈桑"},
	title_level=11,
	head=3001,
	add_num=240,
},
[20024] = 
{
	id=20024,
	name={key='pvp_robot/20024',text="基利斯厄尔"},
	title_level=11,
	head=3001,
	add_num=260,
},
[20025] = 
{
	id=20025,
	name={key='pvp_robot/20025',text="露西娅马修"},
	title_level=11,
	head=3001,
	add_num=280,
},
[20026] = 
{
	id=20026,
	name={key='pvp_robot/20026',text="萨莉霍兰"},
	title_level=11,
	head=3001,
	add_num=300,
},
[20027] = 
{
	id=20027,
	name={key='pvp_robot/20027',text="爱德华梅森"},
	title_level=11,
	head=3001,
	add_num=320,
},
[20028] = 
{
	id=20028,
	name={key='pvp_robot/20028',text="哈纳米勒"},
	title_level=11,
	head=3001,
	add_num=340,
},
[20029] = 
{
	id=20029,
	name={key='pvp_robot/20029',text="埃斯艾肯"},
	title_level=11,
	head=3001,
	add_num=360,
},
[20030] = 
{
	id=20030,
	name={key='pvp_robot/20030',text="埃德丝珂"},
	title_level=11,
	head=3001,
	add_num=380,
},
}
