
-- pm.TbBiInternalEventHeroLottery



return
{
[1] = 
{
	id=1,
	field="lottery_id",
	name="卡池id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="lottery_times",
	name="累计次数",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="lottery_info",
	name="抽取详情",
	type=1,
	opt=1,
	default_value="",
},
}
