local Msgpack = require("msgpack")

local Metatable = { __reset = true, }
local Bools = { ["true"] = true, ["1"] = true, [1] = true, [true] = true, ["false"] = false, ["0"] = false, [0] = false, [false] = false, }
local M = {}

M.Player = {}
M.Player.levels_ = {}
M.Player.fields_ = {}
M.Player.indexs_ = {}
M.Player.labels_ = {}

M.Player.levels_[1] = function(self, packer, level)
  local dirties = self[9]
  local values = self[8]
  packer:pack_key("activitys")
  packer:pack_map_begin()
  for key, status in pairs(dirties) do
    local value = values[key]
    if status == 1 or status == 2 then
      packer:pack_key(key)
      value:Dirty(packer, level, true)
    elseif status == 3 then
      packer:pack_kv(key, Msgpack.null)
    elseif status == 4 then
      packer:pack_key(key)
      value:Data(packer, level, true, true)
    end
  end
  packer:pack_map_end_compress()
end

M.Player.levels_[2] = function(self, packer, level)
  packer:pack_kv("id", self[5])
end

M.Player.levels_[3] = function(self, packer, level)
  packer:pack_kv("zone_id", self[6])
end

M.Player.levels_[4] = function(self, packer, level)
  packer:pack_kv("serial_no", self[7])
end

M.Player.levels_[5] = function(self, packer, level)
  packer:pack_key("activitys")
  packer:pack_map_begin(self[10])
  for key, value in pairs(self[8]) do
    packer:pack_key(key)
    value:Data(packer, level, true, false)
  end
  packer:pack_map_end()
end

M.Player.levels_[6] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] > 0 then
    levels[1](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Player.levels_[7] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] > 0 then
    levels[1](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Player.levels_[8] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(2)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(1)
  end
  levels[5](self, packer, level)
  packer:pack_map_end()
end

M.Player.levels_[9] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(2)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(1)
  end
  levels[5](self, packer, level)
  packer:pack_map_end()
end

M.Player.levels_[10] = function(self)
  local values = self[8]
  local dirties = self[9]
  for key, status in pairs(dirties) do
    if status ~= 3 then
      values[key]:ClearDirty()
    end
    dirties[key] = nil
  end
  self[4] = 0
end

M.Player.levels_[11] = {
  [4] = 4,
}

M.Player.levels_[12] = {
  [4] = 4,
}

M.Player.fields_["id"] = function(self, data)
  self:set_id(data)
end

M.Player.fields_["zone_id"] = function(self, data)
  self:set_zone_id(data)
end

M.Player.fields_["serial_no"] = function(self, data)
  self:set_serial_no(data)
end

M.Player.fields_["activitys"] = function(self, data)
  for key, value in pairs(data) do
    key = tonumber(key)
    if value ~= Msgpack.null then
      self:add_activitys(key):Patch(value)
    else
      self:remove_activitys(key)
    end
  end
end

M.Player.name_ = "t_activity"
M.Player.table_ = [[CREATE TABLE IF NOT EXISTS `t_activity`(
  `id` BIGINT UNSIGNED,
  `zone_id` INT UNSIGNED,
  `serial_no` BIGINT UNSIGNED,
  `activitys` JSON,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]]
M.Player.key_ = { "id", }

M.Player.indexs_[1] = {
  1, "id", "id", "int", false,
  "ALTER TABLE `t_activity` ADD COLUMN `id` BIGINT UNSIGNED",
}
M.Player.labels_["id"] = M.Player.indexs_[1]

M.Player.indexs_[2] = {
  2, "zone_id", "zone_id", "int", false,
  "ALTER TABLE `t_activity` ADD COLUMN `zone_id` INT UNSIGNED",
}
M.Player.labels_["zone_id"] = M.Player.indexs_[2]

M.Player.indexs_[3] = {
  3, "serial_no", "serial_no", "int", false,
  "ALTER TABLE `t_activity` ADD COLUMN `serial_no` BIGINT UNSIGNED",
}
M.Player.labels_["serial_no"] = M.Player.indexs_[3]

M.Player.indexs_[4] = {
  4, "activitys", "activitys", "nested_map", false,
  "ALTER TABLE `t_activity` ADD COLUMN `activitys` JSON",
  "UPDATE `t_activity` SET `activitys` = '{}' WHERE `activitys` IS NULL",
}
M.Player.labels_["activitys"] = M.Player.indexs_[4]

M.Player.persist_ = {
}

function M.Player.new(...)
  local o = {
    false, false, false, false, false, false, false, false, false, false, 
  }
  setmetatable(o, M.Player)
  M.Player.__index = M.Player
  o:ctor(...)
  return o
end

function M.Player:ctor(data, parent)
  self:Reset(data, parent)
end

function M.Player:Reset(data, parent)
  data = data or {}
  parent = parent or function() end

  self[1] = parent
  self[2] = false
  self[3] = false

  self[5] = data.id or 0

  self[6] = data.zone_id or 0

  self[7] = data.serial_no or 0

  local values4 = {}
  local dirties4 = {}
  local size4 = 0
  for key, value in pairs(data.activitys or {}) do
    key = tonumber(key)
    values4[key] = M.Activity.new(value, function()
      if dirties4[key] == nil then
        if self[4] == 0 then
          if not self[2] then
            self[1]()
            self[2] = true
          end
        end
        dirties4[key] = 2
        self[4] = self[4] + 1
      end
    end)
    size4 = size4 + 1
  end
  self[4] = 0
  self[8] = values4
  self[9] = dirties4
  self[10] = size4
end

function M.Player:CopyFrom(another)
  self:set_id(another:id())
  self:set_zone_id(another:zone_id())
  self:set_serial_no(another:serial_no())
  for key, value in another:activitys() do
    self:add_activitys(key):CopyFrom(value)
  end
end

function M.Player:Data(packer, level, child, reset)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  if (child and level > 1) or (level > 1) then
    level = 0
  end
  levels[8 + level](self, packer, level, reset)
end

function M.Player:ClearData()
  self:clear_id()
  self:clear_zone_id()
  self:clear_serial_no()
  self:clear_activitys()
end

function M.Player:Dirty(packer, level, child)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  local cb = levels[6 + level]
  if child and level > 1 then
    level = 0
    cb = levels[8]
  elseif level > 1 then
    level = 0
    cb = levels[6]
  end
  cb(self, packer, level)
end

function M.Player:ClearDirty()
  local levels = self.levels_
  if self[2] then
    self[2] = false
  end
  if self[4] > 0 then
    levels[10](self)
  end
end

function M.Player:Clear(persists)
  self[2] = false

  if not persists or not persists.id then
    self[5] = 0
  end

  if not persists or not persists.zone_id then
    self[6] = 0
  end

  if not persists or not persists.serial_no then
    self[7] = 0
  end

  local values4 = self[8]
  local dirties4 = self[9]
  if not persists or not persists.activitys then
    for key, value in pairs(values4) do
      value[1] = function() end
      values4[key] = nil
    end
    self[10] = 0
  else
    for key, value in pairs(values4) do
      value:ClearDirty()
    end
  end
  for key in pairs(dirties4) do
    dirties4[key] = nil
  end
  self[4] = 0
end

function M.Player:Patch(data)
  data = data or {}
  if data.__reset or getmetatable(data) then
    self:ClearData()
  end
  local fields = self.fields_
  for key, value in pairs(data) do
    local field = fields[key]
    if field then
      field(self, value)
    end
  end
end

function M.Player:id()
  return self[5]
end

function M.Player:set_id(value)
  assert(value ~= nil)
  self[5] = value
end

function M.Player:clear_id()
  self:set_id(0)
end

function M.Player:zone_id()
  return self[6]
end

function M.Player:set_zone_id(value)
  assert(value ~= nil)
  self[6] = value
end

function M.Player:clear_zone_id()
  self:set_zone_id(0)
end

function M.Player:serial_no()
  return self[7]
end

function M.Player:set_serial_no(value)
  assert(value ~= nil)
  self[7] = value
end

function M.Player:clear_serial_no()
  self:set_serial_no(0)
end

function M.Player:activitys(key)
  if key ~= nil then
    return self[8][key]
  else
    return pairs(self[8])
  end
end

function M.Player:add_activitys(key)
  local values = self[8]
  local value = values[key]
  if value == nil then
    local dirties = self[9]
    if self[4] == 0 then
      if not self[2] then
        self[1]()
        self[2] = true
      end
    end
    if dirties[key] == nil then
      dirties[key] = 1
      self[4] = self[4] + 1
    elseif dirties[key] == 3 then
      dirties[key] = 4
    end
    value = M.Activity.new({}, function()
      if dirties[key] == nil then
        if self[4] == 0 then
          if not self[2] then
            self[1]()
            self[2] = true
          end
        end
        dirties[key] = 2
        self[4] = self[4] + 1
      end
    end)
    values[key] = value
    self[10] = self[10] + 1
  end
  return value
end

function M.Player:remove_activitys(key)
  local values = self[8]
  local value = values[key]
  if value ~= nil then
    local dirties = self[9]
    if self[4] == 0 then
      if not self[2] then
        self[1]()
        self[2] = true
      end
    end
    local status = dirties[key]
    if status == 1 then
      dirties[key] = nil
      self[4] = self[4] - 1
    elseif status == nil then
      dirties[key] = 3
      self[4] = self[4] + 1
    else
      dirties[key] = 3
    end
    value[1] = function() end
    values[key] = nil
    self[10] = self[10] - 1
  end
end

function M.Player:clear_activitys()
  local values = self[8]
  local dirties = self[9]
  if self[10] ~= 0 and self[4] == 0 then
    if not self[2] then
      self[1]()
      self[2] = true
    end
  end
  for key, value in pairs(values) do
    local status = dirties[key]
    if status == 1 then
      dirties[key] = nil
      self[4] = self[4] - 1
    elseif status == nil then
      dirties[key] = 3
      self[4] = self[4] + 1
    else
      dirties[key] = 3
    end
    value[1] = function() end
    values[key] = nil
  end
  self[10] = 0
end

function M.Player:activitys_size()
  return self[10]
end

M.Team = {}
M.Team.levels_ = {}
M.Team.fields_ = {}
M.Team.indexs_ = {}
M.Team.labels_ = {}

M.Team.levels_[1] = function(self, packer, level)
  packer:pack_kv("id", self[13])
end

M.Team.levels_[2] = function(self, packer, level)
  packer:pack_kv("zone_id", self[14])
end

M.Team.levels_[3] = function(self, packer, level)
  packer:pack_kv("name", self[15])
end

M.Team.levels_[4] = function(self, packer, level)
  packer:pack_kv("create_time", self[16])
end

M.Team.levels_[5] = function(self, packer, level)
  packer:pack_kv("serial_no", self[17])
end

M.Team.levels_[6] = function(self, packer, level)
  local dirties = self[22]
  local values = self[18]
  packer:pack_key("members")
  packer:pack_map_begin()
  for key, status in pairs(dirties) do
    local value = values[key]
    if status == 1 or status == 2 then
      packer:pack_key(key)
      value:Dirty(packer, level, true)
    elseif status == 3 then
      packer:pack_kv(key, Msgpack.null)
    elseif status == 4 then
      packer:pack_key(key)
      value:Data(packer, level, true, true)
    end
  end
  packer:pack_map_end_compress()
end

M.Team.levels_[7] = function(self, packer, level)
  local dirties = self[24]
  local values = self[19]
  packer:pack_key("applys")
  packer:pack_map_begin()
  for key, status in pairs(dirties) do
    local value = values[key]
    if status == 1 or status == 2 then
      packer:pack_key(key)
      value:Dirty(packer, level, true)
    elseif status == 3 then
      packer:pack_kv(key, Msgpack.null)
    elseif status == 4 then
      packer:pack_key(key)
      value:Data(packer, level, true, true)
    end
  end
  packer:pack_map_end_compress()
end

M.Team.levels_[8] = function(self, packer, level)
  packer:pack_kv("season_id", self[20])
end

M.Team.levels_[9] = function(self, packer, level)
  packer:pack_kv("rank_id", self[21])
end

M.Team.levels_[10] = function(self, packer, level)
  packer:pack_kv("id", self[13])
end

M.Team.levels_[11] = function(self, packer, level)
  packer:pack_kv("zone_id", self[14])
end

M.Team.levels_[12] = function(self, packer, level)
  packer:pack_kv("name", self[15])
end

M.Team.levels_[13] = function(self, packer, level)
  packer:pack_kv("create_time", self[16])
end

M.Team.levels_[14] = function(self, packer, level)
  packer:pack_kv("serial_no", self[17])
end

M.Team.levels_[15] = function(self, packer, level)
  packer:pack_key("members")
  packer:pack_map_begin(self[23])
  for key, value in pairs(self[18]) do
    packer:pack_key(key)
    value:Data(packer, level, true, false)
  end
  packer:pack_map_end()
end

M.Team.levels_[16] = function(self, packer, level)
  packer:pack_key("applys")
  packer:pack_map_begin(self[25])
  for key, value in pairs(self[19]) do
    packer:pack_key(key)
    value:Data(packer, level, true, false)
  end
  packer:pack_map_end()
end

M.Team.levels_[17] = function(self, packer, level)
  packer:pack_kv("season_id", self[20])
end

M.Team.levels_[18] = function(self, packer, level)
  packer:pack_kv("rank_id", self[21])
end

M.Team.levels_[19] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  if self[6] then
    levels[3](self, packer, level)
  end
  if self[7] then
    levels[4](self, packer, level)
  end
  if self[8] then
    levels[5](self, packer, level)
  end
  if self[9] > 0 then
    levels[6](self, packer, level)
  end
  if self[10] > 0 then
    levels[7](self, packer, level)
  end
  if self[11] then
    levels[8](self, packer, level)
  end
  if self[12] then
    levels[9](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Team.levels_[20] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  if self[6] then
    levels[3](self, packer, level)
  end
  if self[7] then
    levels[4](self, packer, level)
  end
  if self[8] then
    levels[5](self, packer, level)
  end
  if self[9] > 0 then
    levels[6](self, packer, level)
  end
  if self[10] > 0 then
    levels[7](self, packer, level)
  end
  if self[11] then
    levels[8](self, packer, level)
  end
  if self[12] then
    levels[9](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Team.levels_[21] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(10)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(9)
  end
  packer:pack_kv("id", self[13])
  packer:pack_kv("zone_id", self[14])
  packer:pack_kv("name", self[15])
  packer:pack_kv("create_time", self[16])
  packer:pack_kv("serial_no", self[17])
  levels[15](self, packer, level)
  levels[16](self, packer, level)
  packer:pack_kv("season_id", self[20])
  packer:pack_kv("rank_id", self[21])
  packer:pack_map_end()
end

M.Team.levels_[22] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(10)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(9)
  end
  packer:pack_kv("id", self[13])
  packer:pack_kv("zone_id", self[14])
  packer:pack_kv("name", self[15])
  packer:pack_kv("create_time", self[16])
  packer:pack_kv("serial_no", self[17])
  levels[15](self, packer, level)
  levels[16](self, packer, level)
  packer:pack_kv("season_id", self[20])
  packer:pack_kv("rank_id", self[21])
  packer:pack_map_end()
end

M.Team.levels_[23] = function(self)
  self[4] = false
end

M.Team.levels_[24] = function(self)
  self[5] = false
end

M.Team.levels_[25] = function(self)
  self[6] = false
end

M.Team.levels_[26] = function(self)
  self[7] = false
end

M.Team.levels_[27] = function(self)
  self[8] = false
end

M.Team.levels_[28] = function(self)
  local values = self[18]
  local dirties = self[22]
  for key, status in pairs(dirties) do
    if status ~= 3 then
      values[key]:ClearDirty()
    end
    dirties[key] = nil
  end
  self[9] = 0
end

M.Team.levels_[29] = function(self)
  local values = self[19]
  local dirties = self[24]
  for key, status in pairs(dirties) do
    if status ~= 3 then
      values[key]:ClearDirty()
    end
    dirties[key] = nil
  end
  self[10] = 0
end

M.Team.levels_[30] = function(self)
  self[11] = false
end

M.Team.levels_[31] = function(self)
  self[12] = false
end

M.Team.levels_[32] = {
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 7,
  [8] = 8,
  [9] = 9,
  [10] = 10,
  [11] = 11,
  [12] = 12,
}

M.Team.levels_[33] = {
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 7,
  [8] = 8,
  [9] = 9,
  [10] = 10,
  [11] = 11,
  [12] = 12,
}

M.Team.fields_["id"] = function(self, data)
  self:set_id(data)
end

M.Team.fields_["zone_id"] = function(self, data)
  self:set_zone_id(data)
end

M.Team.fields_["name"] = function(self, data)
  self:set_name(data)
end

M.Team.fields_["create_time"] = function(self, data)
  self:set_create_time(data)
end

M.Team.fields_["serial_no"] = function(self, data)
  self:set_serial_no(data)
end

M.Team.fields_["members"] = function(self, data)
  for key, value in pairs(data) do
    key = tonumber(key)
    if value ~= Msgpack.null then
      self:add_members(key):Patch(value)
    else
      self:remove_members(key)
    end
  end
end

M.Team.fields_["applys"] = function(self, data)
  for key, value in pairs(data) do
    key = tonumber(key)
    if value ~= Msgpack.null then
      self:add_applys(key):Patch(value)
    else
      self:remove_applys(key)
    end
  end
end

M.Team.fields_["season_id"] = function(self, data)
  self:set_season_id(data)
end

M.Team.fields_["rank_id"] = function(self, data)
  self:set_rank_id(data)
end

M.Team.name_ = "t_team"
M.Team.table_ = [[CREATE TABLE IF NOT EXISTS `t_team`(
  `id` BIGINT UNSIGNED,
  `zone_id` INT UNSIGNED,
  `name` VARCHAR(255),
  `create_time` INT UNSIGNED,
  `serial_no` BIGINT UNSIGNED,
  `members` JSON,
  `applys` JSON,
  `season_id` INT UNSIGNED,
  `rank_id` INT UNSIGNED,
  PRIMARY KEY (`id`),
  KEY (`season_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]]
M.Team.key_ = { "id", }

M.Team.indexs_[1] = {
  1, "id", "id", "int", false,
  "ALTER TABLE `t_team` ADD COLUMN `id` BIGINT UNSIGNED",
}
M.Team.labels_["id"] = M.Team.indexs_[1]

M.Team.indexs_[2] = {
  2, "zone_id", "zone_id", "int", false,
  "ALTER TABLE `t_team` ADD COLUMN `zone_id` INT UNSIGNED",
}
M.Team.labels_["zone_id"] = M.Team.indexs_[2]

M.Team.indexs_[3] = {
  3, "name", "name", "string", false,
  "ALTER TABLE `t_team` ADD COLUMN `name` VARCHAR(255)",
}
M.Team.labels_["name"] = M.Team.indexs_[3]

M.Team.indexs_[4] = {
  4, "create_time", "create_time", "int", false,
  "ALTER TABLE `t_team` ADD COLUMN `create_time` INT UNSIGNED",
}
M.Team.labels_["create_time"] = M.Team.indexs_[4]

M.Team.indexs_[5] = {
  5, "serial_no", "serial_no", "int", false,
  "ALTER TABLE `t_team` ADD COLUMN `serial_no` BIGINT UNSIGNED",
}
M.Team.labels_["serial_no"] = M.Team.indexs_[5]

M.Team.indexs_[6] = {
  6, "members", "members", "nested_map", false,
  "ALTER TABLE `t_team` ADD COLUMN `members` JSON",
  "UPDATE `t_team` SET `members` = '{}' WHERE `members` IS NULL",
}
M.Team.labels_["members"] = M.Team.indexs_[6]

M.Team.indexs_[7] = {
  7, "applys", "applys", "nested_map", false,
  "ALTER TABLE `t_team` ADD COLUMN `applys` JSON",
  "UPDATE `t_team` SET `applys` = '{}' WHERE `applys` IS NULL",
}
M.Team.labels_["applys"] = M.Team.indexs_[7]

M.Team.indexs_[8] = {
  8, "season_id", "season_id", "int", false,
  "ALTER TABLE `t_team` ADD COLUMN `season_id` INT UNSIGNED",
}
M.Team.labels_["season_id"] = M.Team.indexs_[8]

M.Team.indexs_[9] = {
  9, "rank_id", "rank_id", "int", false,
  "ALTER TABLE `t_team` ADD COLUMN `rank_id` INT UNSIGNED",
}
M.Team.labels_["rank_id"] = M.Team.indexs_[9]

M.Team.persist_ = {
  ["id"] = true,
  ["zone_id"] = true,
  ["name"] = true,
  ["serial_no"] = true,
  ["members"] = true,
  ["season_id"] = true,
  ["rank_id"] = true,
}

function M.Team.new(...)
  local o = {
    false, false, false, false, false, false, false, false, false, false, 
    false, false, false, false, false, false, false, false, false, false, 
    false, false, false, false, false, 
  }
  setmetatable(o, M.Team)
  M.Team.__index = M.Team
  o:ctor(...)
  return o
end

function M.Team:ctor(data, parent)
  self:Reset(data, parent)
end

function M.Team:Reset(data, parent)
  data = data or {}
  parent = parent or function() end

  self[1] = parent
  self[2] = false
  self[3] = false

  self[4] = false
  self[13] = data.id or 0

  self[5] = false
  self[14] = data.zone_id or 0

  self[6] = false
  self[15] = data.name or ""

  self[7] = false
  self[16] = data.create_time or 0

  self[8] = false
  self[17] = data.serial_no or 0

  local values6 = {}
  local dirties6 = {}
  local size6 = 0
  for key, value in pairs(data.members or {}) do
    key = tonumber(key)
    values6[key] = M.Member.new(value, function()
      if dirties6[key] == nil then
        if self[9] == 0 then
          if not self[2] then
            self[1]()
            self[2] = true
          end
        end
        dirties6[key] = 2
        self[9] = self[9] + 1
      end
    end)
    size6 = size6 + 1
  end
  self[9] = 0
  self[18] = values6
  self[22] = dirties6
  self[23] = size6

  local values7 = {}
  local dirties7 = {}
  local size7 = 0
  for key, value in pairs(data.applys or {}) do
    key = tonumber(key)
    values7[key] = M.Apply.new(value, function()
      if dirties7[key] == nil then
        if self[10] == 0 then
          if not self[2] then
            self[1]()
            self[2] = true
          end
        end
        dirties7[key] = 2
        self[10] = self[10] + 1
      end
    end)
    size7 = size7 + 1
  end
  self[10] = 0
  self[19] = values7
  self[24] = dirties7
  self[25] = size7

  self[11] = false
  self[20] = data.season_id or 0

  self[12] = false
  self[21] = data.rank_id or 0
end

function M.Team:CopyFrom(another)
  self:set_id(another:id())
  self:set_zone_id(another:zone_id())
  self:set_name(another:name())
  self:set_create_time(another:create_time())
  self:set_serial_no(another:serial_no())
  for key, value in another:members() do
    self:add_members(key):CopyFrom(value)
  end
  for key, value in another:applys() do
    self:add_applys(key):CopyFrom(value)
  end
  self:set_season_id(another:season_id())
  self:set_rank_id(another:rank_id())
end

function M.Team:Data(packer, level, child, reset)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  if (child and level > 1) or (level > 1) then
    level = 0
  end
  levels[21 + level](self, packer, level, reset)
end

function M.Team:ClearData()
  self:clear_id()
  self:clear_zone_id()
  self:clear_name()
  self:clear_create_time()
  self:clear_serial_no()
  self:clear_members()
  self:clear_applys()
  self:clear_season_id()
  self:clear_rank_id()
end

function M.Team:Dirty(packer, level, child)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  local cb = levels[19 + level]
  if child and level > 1 then
    level = 0
    cb = levels[21]
  elseif level > 1 then
    level = 0
    cb = levels[19]
  end
  cb(self, packer, level)
end

function M.Team:ClearDirty()
  local levels = self.levels_
  if self[2] then
    self[2] = false
  end
  if self[4] then
    levels[23](self)
  end
  if self[5] then
    levels[24](self)
  end
  if self[6] then
    levels[25](self)
  end
  if self[7] then
    levels[26](self)
  end
  if self[8] then
    levels[27](self)
  end
  if self[9] > 0 then
    levels[28](self)
  end
  if self[10] > 0 then
    levels[29](self)
  end
  if self[11] then
    levels[30](self)
  end
  if self[12] then
    levels[31](self)
  end
end

function M.Team:Clear(persists)
  self[2] = false

  if not persists or not persists.id then
    self[13] = 0
  end
  self[4] = false

  if not persists or not persists.zone_id then
    self[14] = 0
  end
  self[5] = false

  if not persists or not persists.name then
    self[15] = ""
  end
  self[6] = false

  if not persists or not persists.create_time then
    self[16] = 0
  end
  self[7] = false

  if not persists or not persists.serial_no then
    self[17] = 0
  end
  self[8] = false

  local values6 = self[18]
  local dirties6 = self[22]
  if not persists or not persists.members then
    for key, value in pairs(values6) do
      value[1] = function() end
      values6[key] = nil
    end
    self[23] = 0
  else
    for key, value in pairs(values6) do
      value:ClearDirty()
    end
  end
  for key in pairs(dirties6) do
    dirties6[key] = nil
  end
  self[9] = 0

  local values7 = self[19]
  local dirties7 = self[24]
  if not persists or not persists.applys then
    for key, value in pairs(values7) do
      value[1] = function() end
      values7[key] = nil
    end
    self[25] = 0
  else
    for key, value in pairs(values7) do
      value:ClearDirty()
    end
  end
  for key in pairs(dirties7) do
    dirties7[key] = nil
  end
  self[10] = 0

  if not persists or not persists.season_id then
    self[20] = 0
  end
  self[11] = false

  if not persists or not persists.rank_id then
    self[21] = 0
  end
  self[12] = false
end

function M.Team:Patch(data)
  data = data or {}
  if data.__reset or getmetatable(data) then
    self:ClearData()
  end
  local fields = self.fields_
  for key, value in pairs(data) do
    local field = fields[key]
    if field then
      field(self, value)
    end
  end
end

function M.Team:id()
  return self[13]
end

function M.Team:set_id(value)
  assert(value ~= nil)
  if not self[4] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[4] = true
  end
  self[13] = value
end

function M.Team:clear_id()
  self:set_id(0)
end

function M.Team:zone_id()
  return self[14]
end

function M.Team:set_zone_id(value)
  assert(value ~= nil)
  if not self[5] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[5] = true
  end
  self[14] = value
end

function M.Team:clear_zone_id()
  self:set_zone_id(0)
end

function M.Team:name()
  return self[15]
end

function M.Team:set_name(value)
  assert(value ~= nil)
  if not self[6] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[6] = true
  end
  self[15] = value
end

function M.Team:clear_name()
  self:set_name("")
end

function M.Team:create_time()
  return self[16]
end

function M.Team:set_create_time(value)
  assert(value ~= nil)
  if not self[7] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[7] = true
  end
  self[16] = value
end

function M.Team:clear_create_time()
  self:set_create_time(0)
end

function M.Team:serial_no()
  return self[17]
end

function M.Team:set_serial_no(value)
  assert(value ~= nil)
  if not self[8] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[8] = true
  end
  self[17] = value
end

function M.Team:clear_serial_no()
  self:set_serial_no(0)
end

function M.Team:members(key)
  if key ~= nil then
    return self[18][key]
  else
    return pairs(self[18])
  end
end

function M.Team:add_members(key)
  local values = self[18]
  local value = values[key]
  if value == nil then
    local dirties = self[22]
    if self[9] == 0 then
      if not self[2] then
        self[1]()
        self[2] = true
      end
    end
    if dirties[key] == nil then
      dirties[key] = 1
      self[9] = self[9] + 1
    elseif dirties[key] == 3 then
      dirties[key] = 4
    end
    value = M.Member.new({}, function()
      if dirties[key] == nil then
        if self[9] == 0 then
          if not self[2] then
            self[1]()
            self[2] = true
          end
        end
        dirties[key] = 2
        self[9] = self[9] + 1
      end
    end)
    values[key] = value
    self[23] = self[23] + 1
  end
  return value
end

function M.Team:remove_members(key)
  local values = self[18]
  local value = values[key]
  if value ~= nil then
    local dirties = self[22]
    if self[9] == 0 then
      if not self[2] then
        self[1]()
        self[2] = true
      end
    end
    local status = dirties[key]
    if status == 1 then
      dirties[key] = nil
      self[9] = self[9] - 1
    elseif status == nil then
      dirties[key] = 3
      self[9] = self[9] + 1
    else
      dirties[key] = 3
    end
    value[1] = function() end
    values[key] = nil
    self[23] = self[23] - 1
  end
end

function M.Team:clear_members()
  local values = self[18]
  local dirties = self[22]
  if self[23] ~= 0 and self[9] == 0 then
    if not self[2] then
      self[1]()
      self[2] = true
    end
  end
  for key, value in pairs(values) do
    local status = dirties[key]
    if status == 1 then
      dirties[key] = nil
      self[9] = self[9] - 1
    elseif status == nil then
      dirties[key] = 3
      self[9] = self[9] + 1
    else
      dirties[key] = 3
    end
    value[1] = function() end
    values[key] = nil
  end
  self[23] = 0
end

function M.Team:members_size()
  return self[23]
end

function M.Team:applys(key)
  if key ~= nil then
    return self[19][key]
  else
    return pairs(self[19])
  end
end

function M.Team:add_applys(key)
  local values = self[19]
  local value = values[key]
  if value == nil then
    local dirties = self[24]
    if self[10] == 0 then
      if not self[2] then
        self[1]()
        self[2] = true
      end
    end
    if dirties[key] == nil then
      dirties[key] = 1
      self[10] = self[10] + 1
    elseif dirties[key] == 3 then
      dirties[key] = 4
    end
    value = M.Apply.new({}, function()
      if dirties[key] == nil then
        if self[10] == 0 then
          if not self[2] then
            self[1]()
            self[2] = true
          end
        end
        dirties[key] = 2
        self[10] = self[10] + 1
      end
    end)
    values[key] = value
    self[25] = self[25] + 1
  end
  return value
end

function M.Team:remove_applys(key)
  local values = self[19]
  local value = values[key]
  if value ~= nil then
    local dirties = self[24]
    if self[10] == 0 then
      if not self[2] then
        self[1]()
        self[2] = true
      end
    end
    local status = dirties[key]
    if status == 1 then
      dirties[key] = nil
      self[10] = self[10] - 1
    elseif status == nil then
      dirties[key] = 3
      self[10] = self[10] + 1
    else
      dirties[key] = 3
    end
    value[1] = function() end
    values[key] = nil
    self[25] = self[25] - 1
  end
end

function M.Team:clear_applys()
  local values = self[19]
  local dirties = self[24]
  if self[25] ~= 0 and self[10] == 0 then
    if not self[2] then
      self[1]()
      self[2] = true
    end
  end
  for key, value in pairs(values) do
    local status = dirties[key]
    if status == 1 then
      dirties[key] = nil
      self[10] = self[10] - 1
    elseif status == nil then
      dirties[key] = 3
      self[10] = self[10] + 1
    else
      dirties[key] = 3
    end
    value[1] = function() end
    values[key] = nil
  end
  self[25] = 0
end

function M.Team:applys_size()
  return self[25]
end

function M.Team:season_id()
  return self[20]
end

function M.Team:set_season_id(value)
  assert(value ~= nil)
  if not self[11] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[11] = true
  end
  self[20] = value
end

function M.Team:clear_season_id()
  self:set_season_id(0)
end

function M.Team:rank_id()
  return self[21]
end

function M.Team:set_rank_id(value)
  assert(value ~= nil)
  if not self[12] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[12] = true
  end
  self[21] = value
end

function M.Team:clear_rank_id()
  self:set_rank_id(0)
end

M.Activity = {}
M.Activity.levels_ = {}
M.Activity.fields_ = {}

M.Activity.levels_[1] = function(self, packer, level)
  packer:pack_kv("id", self[8])
end

M.Activity.levels_[2] = function(self, packer, level)
  packer:pack_kv("type", self[9])
end

M.Activity.levels_[3] = function(self, packer, level)
  packer:pack_kv("index", self[10])
end

M.Activity.levels_[4] = function(self, packer, level)
  packer:pack_key("data")
  self[11]:Dirty(packer, level)
end

M.Activity.levels_[5] = function(self, packer, level)
  packer:pack_kv("id", self[8])
end

M.Activity.levels_[6] = function(self, packer, level)
  packer:pack_kv("type", self[9])
end

M.Activity.levels_[7] = function(self, packer, level)
  packer:pack_kv("index", self[10])
end

M.Activity.levels_[8] = function(self, packer, level)
  packer:pack_key("data")
  self[11]:Data(packer, level, true, false)
end

M.Activity.levels_[9] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  if self[6] then
    levels[3](self, packer, level)
  end
  if self[7] then
    levels[4](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Activity.levels_[10] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  if self[6] then
    levels[3](self, packer, level)
  end
  if self[7] then
    levels[4](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Activity.levels_[11] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(5)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(4)
  end
  packer:pack_kv("id", self[8])
  packer:pack_kv("type", self[9])
  packer:pack_kv("index", self[10])
  levels[8](self, packer, level)
  packer:pack_map_end()
end

M.Activity.levels_[12] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(5)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(4)
  end
  packer:pack_kv("id", self[8])
  packer:pack_kv("type", self[9])
  packer:pack_kv("index", self[10])
  levels[8](self, packer, level)
  packer:pack_map_end()
end

M.Activity.levels_[13] = function(self)
  self[4] = false
end

M.Activity.levels_[14] = function(self)
  self[5] = false
end

M.Activity.levels_[15] = function(self)
  self[6] = false
end

M.Activity.levels_[16] = function(self)
  self[11]:ClearDirty()
  self[7] = false
end

M.Activity.levels_[17] = {
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 7,
}

M.Activity.levels_[18] = {
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 7,
}

M.Activity.fields_["id"] = function(self, data)
  self:set_id(data)
end

M.Activity.fields_["type"] = function(self, data)
  self:set_type(data)
end

M.Activity.fields_["index"] = function(self, data)
  self:set_index(data)
end

M.Activity.fields_["data"] = function(self, data)
  self:data():Patch(data)
end

function M.Activity.new(...)
  local o = {
    false, false, false, false, false, false, false, false, false, false, 
    false, 
  }
  setmetatable(o, M.Activity)
  M.Activity.__index = M.Activity
  o:ctor(...)
  return o
end

function M.Activity:ctor(data, parent)
  self:Reset(data, parent)
end

function M.Activity:Reset(data, parent)
  data = data or {}
  parent = parent or function() end

  self[1] = parent
  self[2] = false
  self[3] = false

  self[4] = false
  self[8] = data.id or 0

  self[5] = false
  self[9] = data.type or 0

  self[6] = false
  self[10] = data.index or 0

  self[7] = false
  self[11] = M.Activity_Data.new(data.data or {}, function()
    if not self[7] then
      if not self[2] then
        self[1]()
        self[2] = true
      end
      self[7] = true
    end
  end)
end

function M.Activity:CopyFrom(another)
  self:set_id(another:id())
  self:set_type(another:type())
  self:set_index(another:index())
  self:data():CopyFrom(another:data())
end

function M.Activity:Data(packer, level, child, reset)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  if (child and level > 1) or (level > 1) then
    level = 0
  end
  levels[11 + level](self, packer, level, reset)
end

function M.Activity:ClearData()
  self:clear_id()
  self:clear_type()
  self:clear_index()
  self:clear_data()
end

function M.Activity:Dirty(packer, level, child)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  local cb = levels[9 + level]
  if child and level > 1 then
    level = 0
    cb = levels[11]
  elseif level > 1 then
    level = 0
    cb = levels[9]
  end
  cb(self, packer, level)
end

function M.Activity:ClearDirty()
  local levels = self.levels_
  if self[2] then
    self[2] = false
  end
  if self[4] then
    levels[13](self)
  end
  if self[5] then
    levels[14](self)
  end
  if self[6] then
    levels[15](self)
  end
  if self[7] then
    levels[16](self)
  end
end

function M.Activity:Clear(persists)
  self[2] = false

  if not persists or not persists.id then
    self[8] = 0
  end
  self[4] = false

  if not persists or not persists.type then
    self[9] = 0
  end
  self[5] = false

  if not persists or not persists.index then
    self[10] = 0
  end
  self[6] = false

  if not persists or not persists.data then
    self[11]:Clear()
  else
    self[11]:ClearDirty()
  end
  self[7] = false
end

function M.Activity:Patch(data)
  data = data or {}
  if data.__reset or getmetatable(data) then
    self:ClearData()
  end
  local fields = self.fields_
  for key, value in pairs(data) do
    local field = fields[key]
    if field then
      field(self, value)
    end
  end
end

function M.Activity:id()
  return self[8]
end

function M.Activity:set_id(value)
  assert(value ~= nil)
  if not self[4] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[4] = true
  end
  self[8] = value
end

function M.Activity:clear_id()
  self:set_id(0)
end

function M.Activity:type()
  return self[9]
end

function M.Activity:set_type(value)
  assert(value ~= nil)
  if not self[5] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[5] = true
  end
  self[9] = value
end

function M.Activity:clear_type()
  self:set_type(0)
end

function M.Activity:index()
  return self[10]
end

function M.Activity:set_index(value)
  assert(value ~= nil)
  if not self[6] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[6] = true
  end
  self[10] = value
end

function M.Activity:clear_index()
  self:set_index(0)
end

function M.Activity:data()
  return self[11]
end

function M.Activity:clear_data()
  self[11]:ClearData()
end

M.Member = {}
M.Member.levels_ = {}
M.Member.fields_ = {}

M.Member.levels_[1] = function(self, packer, level)
  packer:pack_kv("zone_id", self[8])
end

M.Member.levels_[2] = function(self, packer, level)
  packer:pack_kv("score", self[9])
end

M.Member.levels_[3] = function(self, packer, level)
  packer:pack_kv("leader", self[10])
end

M.Member.levels_[4] = function(self, packer, level)
  packer:pack_kv("time", self[11])
end

M.Member.levels_[5] = function(self, packer, level)
  packer:pack_kv("zone_id", self[8])
end

M.Member.levels_[6] = function(self, packer, level)
  packer:pack_kv("score", self[9])
end

M.Member.levels_[7] = function(self, packer, level)
  packer:pack_kv("leader", self[10])
end

M.Member.levels_[8] = function(self, packer, level)
  packer:pack_kv("time", self[11])
end

M.Member.levels_[9] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  if self[6] then
    levels[3](self, packer, level)
  end
  if self[7] then
    levels[4](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Member.levels_[10] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  if self[6] then
    levels[3](self, packer, level)
  end
  if self[7] then
    levels[4](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Member.levels_[11] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(5)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(4)
  end
  packer:pack_kv("zone_id", self[8])
  packer:pack_kv("score", self[9])
  packer:pack_kv("leader", self[10])
  packer:pack_kv("time", self[11])
  packer:pack_map_end()
end

M.Member.levels_[12] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(5)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(4)
  end
  packer:pack_kv("zone_id", self[8])
  packer:pack_kv("score", self[9])
  packer:pack_kv("leader", self[10])
  packer:pack_kv("time", self[11])
  packer:pack_map_end()
end

M.Member.levels_[13] = function(self)
  self[4] = false
end

M.Member.levels_[14] = function(self)
  self[5] = false
end

M.Member.levels_[15] = function(self)
  self[6] = false
end

M.Member.levels_[16] = function(self)
  self[7] = false
end

M.Member.levels_[17] = {
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 7,
}

M.Member.levels_[18] = {
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 7,
}

M.Member.fields_["zone_id"] = function(self, data)
  self:set_zone_id(data)
end

M.Member.fields_["score"] = function(self, data)
  self:set_score(data)
end

M.Member.fields_["leader"] = function(self, data)
  self:set_leader(data)
end

M.Member.fields_["time"] = function(self, data)
  self:set_time(data)
end

function M.Member.new(...)
  local o = {
    false, false, false, false, false, false, false, false, false, false, 
    false, 
  }
  setmetatable(o, M.Member)
  M.Member.__index = M.Member
  o:ctor(...)
  return o
end

function M.Member:ctor(data, parent)
  self:Reset(data, parent)
end

function M.Member:Reset(data, parent)
  data = data or {}
  parent = parent or function() end

  self[1] = parent
  self[2] = false
  self[3] = false

  self[4] = false
  self[8] = data.zone_id or 0

  self[5] = false
  self[9] = data.score or 0

  self[6] = false
  self[10] = data.leader or false

  self[7] = false
  self[11] = data.time or 0
end

function M.Member:CopyFrom(another)
  self:set_zone_id(another:zone_id())
  self:set_score(another:score())
  self:set_leader(another:leader())
  self:set_time(another:time())
end

function M.Member:Data(packer, level, child, reset)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  if (child and level > 1) or (level > 1) then
    level = 0
  end
  levels[11 + level](self, packer, level, reset)
end

function M.Member:ClearData()
  self:clear_zone_id()
  self:clear_score()
  self:clear_leader()
  self:clear_time()
end

function M.Member:Dirty(packer, level, child)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  local cb = levels[9 + level]
  if child and level > 1 then
    level = 0
    cb = levels[11]
  elseif level > 1 then
    level = 0
    cb = levels[9]
  end
  cb(self, packer, level)
end

function M.Member:ClearDirty()
  local levels = self.levels_
  if self[2] then
    self[2] = false
  end
  if self[4] then
    levels[13](self)
  end
  if self[5] then
    levels[14](self)
  end
  if self[6] then
    levels[15](self)
  end
  if self[7] then
    levels[16](self)
  end
end

function M.Member:Clear(persists)
  self[2] = false

  if not persists or not persists.zone_id then
    self[8] = 0
  end
  self[4] = false

  if not persists or not persists.score then
    self[9] = 0
  end
  self[5] = false

  if not persists or not persists.leader then
    self[10] = false
  end
  self[6] = false

  if not persists or not persists.time then
    self[11] = 0
  end
  self[7] = false
end

function M.Member:Patch(data)
  data = data or {}
  if data.__reset or getmetatable(data) then
    self:ClearData()
  end
  local fields = self.fields_
  for key, value in pairs(data) do
    local field = fields[key]
    if field then
      field(self, value)
    end
  end
end

function M.Member:zone_id()
  return self[8]
end

function M.Member:set_zone_id(value)
  assert(value ~= nil)
  if not self[4] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[4] = true
  end
  self[8] = value
end

function M.Member:clear_zone_id()
  self:set_zone_id(0)
end

function M.Member:score()
  return self[9]
end

function M.Member:set_score(value)
  assert(value ~= nil)
  if not self[5] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[5] = true
  end
  self[9] = value
end

function M.Member:clear_score()
  self:set_score(0)
end

function M.Member:leader()
  return self[10]
end

function M.Member:set_leader(value)
  assert(value ~= nil)
  if not self[6] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[6] = true
  end
  self[10] = value
end

function M.Member:clear_leader()
  self:set_leader(false)
end

function M.Member:time()
  return self[11]
end

function M.Member:set_time(value)
  assert(value ~= nil)
  if not self[7] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[7] = true
  end
  self[11] = value
end

function M.Member:clear_time()
  self:set_time(0)
end

M.Apply = {}
M.Apply.levels_ = {}
M.Apply.fields_ = {}

M.Apply.levels_[1] = function(self, packer, level)
  packer:pack_kv("zone_id", self[6])
end

M.Apply.levels_[2] = function(self, packer, level)
  packer:pack_kv("time", self[7])
end

M.Apply.levels_[3] = function(self, packer, level)
  packer:pack_kv("zone_id", self[6])
end

M.Apply.levels_[4] = function(self, packer, level)
  packer:pack_kv("time", self[7])
end

M.Apply.levels_[5] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Apply.levels_[6] = function(self, packer, level)
  local levels = self.levels_
  packer:pack_map_begin()
  if self[4] then
    levels[1](self, packer, level)
  end
  if self[5] then
    levels[2](self, packer, level)
  end
  packer:pack_map_end_compress()
end

M.Apply.levels_[7] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(3)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(2)
  end
  packer:pack_kv("zone_id", self[6])
  packer:pack_kv("time", self[7])
  packer:pack_map_end()
end

M.Apply.levels_[8] = function(self, packer, level, reset)
  local levels = self.levels_
  if reset then
    packer:pack_map_begin(3)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(2)
  end
  packer:pack_kv("zone_id", self[6])
  packer:pack_kv("time", self[7])
  packer:pack_map_end()
end

M.Apply.levels_[9] = function(self)
  self[4] = false
end

M.Apply.levels_[10] = function(self)
  self[5] = false
end

M.Apply.levels_[11] = {
  [4] = 4,
  [5] = 5,
}

M.Apply.levels_[12] = {
  [4] = 4,
  [5] = 5,
}

M.Apply.fields_["zone_id"] = function(self, data)
  self:set_zone_id(data)
end

M.Apply.fields_["time"] = function(self, data)
  self:set_time(data)
end

function M.Apply.new(...)
  local o = {
    false, false, false, false, false, false, false, 
  }
  setmetatable(o, M.Apply)
  M.Apply.__index = M.Apply
  o:ctor(...)
  return o
end

function M.Apply:ctor(data, parent)
  self:Reset(data, parent)
end

function M.Apply:Reset(data, parent)
  data = data or {}
  parent = parent or function() end

  self[1] = parent
  self[2] = false
  self[3] = false

  self[4] = false
  self[6] = data.zone_id or 0

  self[5] = false
  self[7] = data.time or 0
end

function M.Apply:CopyFrom(another)
  self:set_zone_id(another:zone_id())
  self:set_time(another:time())
end

function M.Apply:Data(packer, level, child, reset)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  if (child and level > 1) or (level > 1) then
    level = 0
  end
  levels[7 + level](self, packer, level, reset)
end

function M.Apply:ClearData()
  self:clear_zone_id()
  self:clear_time()
end

function M.Apply:Dirty(packer, level, child)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  local cb = levels[5 + level]
  if child and level > 1 then
    level = 0
    cb = levels[7]
  elseif level > 1 then
    level = 0
    cb = levels[5]
  end
  cb(self, packer, level)
end

function M.Apply:ClearDirty()
  local levels = self.levels_
  if self[2] then
    self[2] = false
  end
  if self[4] then
    levels[9](self)
  end
  if self[5] then
    levels[10](self)
  end
end

function M.Apply:Clear(persists)
  self[2] = false

  if not persists or not persists.zone_id then
    self[6] = 0
  end
  self[4] = false

  if not persists or not persists.time then
    self[7] = 0
  end
  self[5] = false
end

function M.Apply:Patch(data)
  data = data or {}
  if data.__reset or getmetatable(data) then
    self:ClearData()
  end
  local fields = self.fields_
  for key, value in pairs(data) do
    local field = fields[key]
    if field then
      field(self, value)
    end
  end
end

function M.Apply:zone_id()
  return self[6]
end

function M.Apply:set_zone_id(value)
  assert(value ~= nil)
  if not self[4] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[4] = true
  end
  self[6] = value
end

function M.Apply:clear_zone_id()
  self:set_zone_id(0)
end

function M.Apply:time()
  return self[7]
end

function M.Apply:set_time(value)
  assert(value ~= nil)
  if not self[5] then
    if not self[2] then
      self[1]()
      self[2] = true
    end
    self[5] = true
  end
  self[7] = value
end

function M.Apply:clear_time()
  self:set_time(0)
end

M.Activity_Data = {}
M.Activity_Data.levels_ = {}
M.Activity_Data.fields_ = {}

M.Activity_Data.levels_[1] = function(self, packer, level)
  packer:pack_map_begin()
  packer:pack_map_end_compress()
end

M.Activity_Data.levels_[2] = function(self, packer, level)
  packer:pack_map_begin()
  packer:pack_map_end_compress()
end

M.Activity_Data.levels_[3] = function(self, packer, level, reset)
  if reset then
    packer:pack_map_begin(1)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(0)
  end
  packer:pack_map_end()
end

M.Activity_Data.levels_[4] = function(self, packer, level, reset)
  if reset then
    packer:pack_map_begin(1)
    packer:pack_reset(Metatable)
  else
    packer:pack_map_begin(0)
  end
  packer:pack_map_end()
end

M.Activity_Data.levels_[5] = {
}

M.Activity_Data.levels_[6] = {
}

function M.Activity_Data.new(...)
  local o = {
    false, false, false, 
  }
  setmetatable(o, M.Activity_Data)
  M.Activity_Data.__index = M.Activity_Data
  o:ctor(...)
  return o
end

function M.Activity_Data:ctor(data, parent)
  self:Reset(data, parent)
end

function M.Activity_Data:Reset(data, parent)
  data = data or {}
  parent = parent or function() end

  self[1] = parent
  self[2] = false
  self[3] = false
end

function M.Activity_Data:CopyFrom(another)
end

function M.Activity_Data:Data(packer, level, child, reset)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  if (child and level > 1) or (level > 1) then
    level = 0
  end
  levels[3 + level](self, packer, level, reset)
end

function M.Activity_Data:ClearData()
end

function M.Activity_Data:Dirty(packer, level, child)
  level = level or 0
  assert(level >= 0)
  local levels = self.levels_
  local cb = levels[1 + level]
  if child and level > 1 then
    level = 0
    cb = levels[3]
  elseif level > 1 then
    level = 0
    cb = levels[1]
  end
  cb(self, packer, level)
end

function M.Activity_Data:ClearDirty()
  local levels = self.levels_
  if self[2] then
    self[2] = false
  end
end

function M.Activity_Data:Clear(persists)
  self[2] = false
end

function M.Activity_Data:Patch(data)
  data = data or {}
  if data.__reset or getmetatable(data) then
    self:ClearData()
  end
  local fields = self.fields_
  for key, value in pairs(data) do
    local field = fields[key]
    if field then
      field(self, value)
    end
  end
end

return M
