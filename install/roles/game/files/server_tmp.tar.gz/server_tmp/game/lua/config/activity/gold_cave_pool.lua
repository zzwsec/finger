
-- pm.TbGoldCavePool



return
{
[102041] = 
{
	id=102041,
	grand=false,
	normal_pool=0,
	reward=
	{
	},
	probabilitys=
	{
	
		{
			id=3,
			num=100,
			pr=1000,
		},
	
		{
			id=3,
			num=50,
			pr=1500,
		},
	
		{
			id=33,
			num=50,
			pr=1000,
		},
	
		{
			id=33,
			num=30,
			pr=2000,
		},
	
		{
			id=50,
			num=10,
			pr=1500,
		},
	
		{
			id=50,
			num=5,
			pr=2000,
		},
	
		{
			id=17,
			num=1,
			pr=1000,
		},
	},
},
[102061] = 
{
	id=102061,
	grand=true,
	normal_pool=102041,
	reward=
	{
	},
	probabilitys=
	{
	},
},
}
