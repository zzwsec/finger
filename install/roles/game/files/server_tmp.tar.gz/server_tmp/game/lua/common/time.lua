local Date = require("common/date")

local M = {}

-- 时间单位
M.Unit = {
    ["Sec"]     = 1,
    ["Min"]     = 60,
    ["Hour"]    = 3600,
    ["Day"]     = 86400,
    ["Week"]    = 604800,
}

-- 回去0点开始的秒数
function M.SecondsOfDay(tm)
    return tm.hour * M.Unit.Hour + tm.min * M.Unit.Min + tm.sec
end

-- 回去0点开始的秒数ts版本
function M.SecondsOfDayTs(time)
    local tm = os.date("*t", time)
    return M.SecondsOfDay(tm)
end

-- 获取当天开始时间戳
function M.TimeStampOfDay(tm)
    tm.hour, tm.min, tm.sec = 0, 0, 0
    return os.time(tm)
end

-- 获取当日时间戳ts版本
function M.TimeStampOfDayTs(time)
    local tm = os.date("*t", time)
    return M.TimeStampOfDay(tm)
end

-- 获取时间小时
function M.HourOfTime(time)
    local tm = os.date("*t", time)
    return tm.hour
end

-- 获取本周开始的秒数(从周一开始算)
function M.SecondsOfWeek(tm)
    local wday = (tm.wday ~= 1) and tm.wday - 2 or 6
    local seconds = wday * M.Unit.Day + M.SecondsOfDay(tm)
    return seconds
end

-- 获取本周开始秒数ts版本
function M.SecondsOfWeekTs(time)
    local tm = os.date("*t", time)
    return M.SecondsOfWeek(tm)
end

-- 获取本周开始时间戳
function M.TimeStampOfWeek(time)
    local pass_time = M.SecondsOfWeekTs(time)
    return math.max(time - pass_time, 0)
end

-- 获取时间戳通过星期和时间
function M.TimeStampOfWeekTime(now_time, weekday, time_text)
    local start_time = M.TimeStampOfWeek(now_time)
    local pass_seconds = M.ParseTimeTs(time_text)
    return math.floor(start_time + (weekday - 1) * M.Unit.Day + pass_seconds)
end

-- 星期一开始的天数, 1-7
function M.DayOfWeek(tm)
    return tm.wday ~= 1 and tm.wday - 1 or 7
end

function M.DayOfYearTs(time)
    local tm = os.date("*t", time)
    return tm.yday
end

function M.DayOfWeekTs(time)
    local tm = os.date("*t", time)
    return M.DayOfWeek(tm)
end

function M.IsNewDay(time1, time2)
    local t1 = time1
    local t2 = time2
    if time2 < time1 then
        t1 = time2
        t2 = time1
    end
    local tm1 = os.date("*t", t1)
    local tm2 = os.date("*t", t2)
    return tm1.year == tm2.year and tm1.month == tm2.month and tm1.day + 1 == tm2.day
end

-- 获取当前周是当年的第几周, 0-53
function M.WeekOfYear(tm)
    local yday = tm.yday + ((tm.wday == 1) and 0 or (8 - tm.wday))
    return yday // 7
end

-- 是否是同一周
function M.IsSameWeek(tm1, tm2)
    local yday1 = tm1.yday + ((tm1.wday == 1) and 0 or (8 - tm1.wday))
    local yday2 = tm2.yday + ((tm2.wday == 1) and 0 or (8 - tm2.wday))
    -- 一年的同一周
    if tm1.year == tm2.year and yday1 == yday2 then
        return true
    end
    -- 一周跨两年
    if tm1.year + 1 == tm2.year and yday2 + 365 - yday1 <= 1 then
        return true
    end
    return false
end

-- Ts版本
function M.IsSameWeekTs(time1, time2)
    local tm1 = os.date("*t", time1)
    local tm2 = os.date("*t", time2)
    return M.IsSameWeek(tm1, tm2)
end

-- 是否是同一月
function M.IsSameMonth(tm1, tm2)
    if tm1.year == tm2.year and tm1.month == tm2.month then
        return true
    end
    return false
end

-- Ts版本
function M.IsSameMonthTs(time1, time2)
    local tm1 = os.date("*t", time1)
    local tm2 = os.date("*t", time2)
    return M.IsSameMonth(tm1, tm2)
end

-- 是否同一天
function M.IsSameDay(tm1, tm2)
    if (tm1 ~= nil and tm2 ~= nil) and (tm1.year == tm2.year and tm1.yday == tm2.yday) then
        return true
    end
    return false 
end

-- Ts版本
function M.IsSameDayTs(t1, t2)
    local tm1 = os.date("*t", t1)
    local tm2 = os.date("*t", t2)
    return M.IsSameDay(tm1, tm2)
end

function M.IsSameHour(tm1, tm2)
    if (tm1 ~= nil and tm2 ~= nil) and (tm1.year == tm2.year and tm1.yday == tm2.yday and tm1.hour == tm2.hour) then
        return true
    end
    return false 
end

-- Ts版本
function M.IsSameHourTs(t1, t2)
    local tm1 = os.date("*t", t1)
    local tm2 = os.date("*t", t2)
    return M.IsSameHour(tm1, tm2)
end

-- 解析时间
function M.ParseTime(s)
    local tm = os.date("*t")
    tm.hour = 0
    tm.min = 0
    tm.sec = 0
    local f, s, i = string.gmatch(s, "(%d+)")
    repeat
        local hour = f(s, i)
        if hour == nil then
            break
        end
        tm.hour = tonumber(hour)
        local min = f(s, hour)
        if min == nil then
            break
        end
        tm.min = tonumber(min)
        local sec = f(s, min)
        if sec == nil then
            break
        end
        tm.sec = tonumber(sec)
    until true
    return tm
end

-- 解析时间
function M.ParseTimeTs(s)
    local tm = M.ParseTime(s)
    return M.SecondsOfDay(tm)
end

-- 解析日期文本为tm
function M.ParseDate(s)
    local count = 0
    local time_struct = {hour = 0, min = 0, sec = 0}
    local time_token = {"year", "month", "day"}
    for token in string.gmatch(s, "(%d+)") do
        count = count + 1 
        local key = time_token[count]
        if key ~= nil then 
            time_struct[key] = tonumber(token)
        end
    end
    if next(time_struct) ~= nil and count ~= 0 then 
        time_struct = os.date("*t", os.time(time_struct))
    else 
        time_struct = os.date("*t", 0)
    end
    return time_struct
end

-- 解析日期文本成时间戳
function M.ParseDateTs(s)
    local tm = M.ParseDate(s)
    return os.time(tm)
end

-- 解析日期时间文本为tm
function M.ParseDateTime(s)
    local count = 0
    local time_struct = {}
    local time_token = {"year", "month", "day", "hour", "min", "sec"}
    for token in string.gmatch(s, "(%d+)") do
        count = count + 1 
        local key = time_token[count]
        if key ~= nil then 
            time_struct[key] = tonumber(token)
        end
    end
    if next(time_struct) ~= nil and (#time_token == count) then 
        time_struct = os.date("*t", os.time(time_struct))
    else
        time_struct = os.date("*t", 0)
    end
    return time_struct
end

-- 解析日期时间文本为时间戳
function M.ParseDateTimeTs(s)
    local tm = M.ParseDateTime(s)
    return os.time(tm)
end

-- 计算时间差
function M.DiffTimeSpan(tm1, tm2)
    local d1 = Date(tm1)
    local d2 = Date(tm2)
    local timespan = Date.diff(d1, d2)
    return timespan
end

-- 计算时间差Ts版本
function M.DiffTimeSpanTs(t1, t2)
    local max_time, min_time = math.max(t1, t2), math.min(t1, t2)
    local tm1 = os.date("*t", max_time)
    local tm2 = os.date("*t", min_time)
    return M.DiffTimeSpan(tm1, tm2)
end

-- 计算时差天数
function M.DiffDaysTs(t1, t2)
    local day1 = M.TimeStampOfDayTs(t1)
    local day2 = M.TimeStampOfDayTs(t2)
    local timespan = M.DiffTimeSpanTs(day1, day2)
    return math.floor(timespan:spandays())
end

return M