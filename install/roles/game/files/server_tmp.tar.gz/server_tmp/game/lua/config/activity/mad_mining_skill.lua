
-- pm.TbActivityMiningSkill



return
{
[102] = 
{
	id=102,
	cost=
	{
		id=304,
		num=2000,
	},
	cd=20,
	param=8,
	param2=0,
	name={key='mining_skill_name/102',text="火力全开"},
	desc={key='mining_skill/102',text=[[释放后，发射8枚导弹轰炸矿区。
<color=#fafba3>点击矿区任意位置释放。</color>]]},
},
[101] = 
{
	id=101,
	cost=
	{
		id=304,
		num=1000,
	},
	cd=10,
	param=2,
	param2=0,
	name={key='mining_skill_name/101',text="炸弹"},
	desc={key='mining_skill/101',text=[[放置后，将范围内9个矿石全部炸开。
<color=#fafba3>点击矿区指定位置释放。</color>]]},
},
}
