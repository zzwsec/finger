
-- pm.TbBiKingnetEventBoss



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="轮数id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="num",
	name="伤害",
	type=0,
	opt=1,
	default_value="",
},
}
