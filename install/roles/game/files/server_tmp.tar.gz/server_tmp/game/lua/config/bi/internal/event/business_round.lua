
-- pm.TbBiInternalEventBusinessRound



return
{
[1] = 
{
	id=1,
	field="round_id",
	name="轮数id",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="hearsay_id",
	name="传闻id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="refresh_goods",
	name="刷新商品",
	type=1,
	opt=1,
	default_value="0",
},
}
