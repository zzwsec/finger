local Log = require("common.logging") 
local Result = require("common.result")
local Rapidjson = require("rapidjson")

local Http = require("api.utility.http")
local Validator = require("api.utility.validator")
local DataCast = import("api.utility.cast").Invite
local ServerOptions = import("api.utility.config").ServerOptions

local BaseUrl = ServerOptions.Url


local _M = {}

-- 创建邀请码
function _M.Create(coro, message)
    if not Validator.validateParams(message, {"project_id", "user_id", "cdkey"}) then
        Log.Warn("CreateInvite", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/shares", BaseUrl, message.project_id)
    local ok, resp = Http.Post(coro, url, {
        body = {
            user_id = message.user_id,
            cdkey = message.cdkey,
        }
    })
    local result = Http.HandleResponse(ok, resp, "CreateInvite")
    if result:is_err() then
        Log.Warn("CreateInvite", "Failed to create invite: {}", result:unwrap_err())
        return result
    end

    local invite = DataCast.toInvite(result:unwrap())
    if not invite then
        Log.Warn("CreateInviteCode", "invite is nil")
        return Result.err("SYSTEM_BUSY")
    end

    Log.Debug("CreateInviteCode", "Created invite: {}", invite)
    return Result.ok(invite)
end

-- 获取邀请码
function _M.Get(coro, message)
    if not Validator.validateParams(message, {"project_id", "id"}) then
        Log.Warn("GetInvite", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/shares/%s", BaseUrl, message.project_id, message.id)
    local ok, resp = Http.Get(coro, url)
    local result = Http.HandleResponse(ok, resp, "GetInvite")
    if result:is_err() then
        Log.Warn("GetInvite", "Failed to get invite: {}", result:unwrap_err())
        return result
    end

    local invite = DataCast.toInvite(result:unwrap())
    if not invite then
        Log.Warn("GetInvite", "invite is nil")
        return Result.err("SYSTEM_BUSY")
    end

    Log.Debug("GetInvite", "Get invite: {}", invite)
    return Result.ok(invite)
end

-- 绑定邀请码
function _M.Bind(coro, message)
    if not Validator.validateParams(message, {"project_id", "id", "cdkey", "user_id"}) then
        Log.Warn("BindInvite", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/shares/%s/bind", BaseUrl, message.project_id, message.id)
    local ok, reply = Http.Post(coro, url, {
        body = {
            user_id = message.user_id,
            cdkey = message.cdkey,
        }
    })
    local content = Rapidjson.unpack(reply.body or "{}")
    if not content then
        Log.Warn("BindInvite", "Failed to decode response body")
        return Result.err("SYSTEM_BUSY")
    end 

    if content.code ~= nil then
        Log.Warn("BindInvite", "Failed to bind invite: {}", content.code)
        return Result.err(DataCast.toErrorCode(content.code))
    end

    local invite = DataCast.toInvite(content.share or {})
    if not invite then
        Log.Warn("BindInvite", "invite is nil")
        return Result.err("SYSTEM_BUSY")
    end
    Log.Debug("BindInvite", "Bind invite: {}", invite)
    return Result.ok(invite)
end

-- 获取邀请码关联记录
function _M.Relation(coro, message)
    if not Validator.validateParams(message, {"project_id", "id"}) then
        Log.Warn("Relation", "Invalid request: {}", message)
        return Result.err("BAD_ARGUMENT")
    end

    local url = string.format("%s/api/v1/projects/%s/shares/%s/list", BaseUrl, message.project_id, message.id)
    local ok, resp = Http.Get(coro, url)
    local result = Http.HandleResponse(ok, resp, "Relation")
    if result:is_err() then
        Log.Warn("GetBindUsers", "Failed to get bind users: {}", result:unwrap_err())
        return result
    end
    local content = result:unwrap()
    Log.Debug("Relation", "Relation: {}", content.records or {})
    return Result.ok(content.records or {})
end

return _M
