--[[ 
类似Rust中的Result类型，用于处理函数返回值和错误。
]]--


local Result = class("Result")

function Result:ctor(value, err)
    self.value = value
    self.err = err
    self.ok = (err == nil)
end

function Result:is_ok()
    return self.ok
end

function Result:is_err()
    return not self.ok
end

function Result:unwrap()
    if self:is_err() then
        error(self.err or "called unwrap on an error result")
    end
    return self.value
end

function Result:unwrap_err()
    if self:is_ok() then
        error("called unwrap_err on an ok result")
    end
    return self.err
end

function Result:unwrap_or(fallback)
    if self:is_err() then
        return fallback
    end
    return self.value
end

function Result:map(fn)
    if self:is_err() then
        return self
    end
    return Result.ok(fn(self.value))
end

function Result:map_err(fn)
    if self:is_ok() then
        return self
    end
    return Result.err(fn(self.err))
end

function Result:and_then(fn)
    if self:is_err() then
        return self
    end
    return fn(self.value)
end

local function ok(value)
    return Result.new(value, nil)
end

local function err(err)
    return Result.new(nil, err)
end

return {
    Result = Result,
    ok = ok,
    err = err,
}
