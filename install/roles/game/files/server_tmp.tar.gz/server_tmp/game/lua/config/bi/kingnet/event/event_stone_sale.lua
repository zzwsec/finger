
-- pm.TbBiKingnetEventEventStoneSale



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="事件类型",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="type1",
	name="石头类型",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="type2",
	name="石头颜色",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="type3",
	name="石头星级",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="num",
	name="累计切割次数",
	type=0,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="num1",
	name="第1次用鉴定切面颜色",
	type=0,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="num2",
	name="第2次用鉴定切面颜色",
	type=0,
	opt=1,
	default_value="",
},
[8] = 
{
	id=8,
	field="value",
	name="售卖倍率",
	type=0,
	opt=1,
	default_value="",
},
}
