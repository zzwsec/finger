
-- pm.TbBiInternalEventRanks



return
{
[1] = 
{
	id=1,
	field="type",
	name="排名类型",
	type=0,
	opt=1,
	default_value="0",
},
[2] = 
{
	id=2,
	field="player_id",
	name="角色id",
	type=0,
	opt=1,
	default_value="0",
},
[3] = 
{
	id=3,
	field="zone_id",
	name="区服id",
	type=0,
	opt=1,
	default_value="0",
},
[4] = 
{
	id=4,
	field="rank",
	name="排名",
	type=0,
	opt=1,
	default_value="0",
},
[5] = 
{
	id=5,
	field="value",
	name="数据",
	type=0,
	opt=1,
	default_value="0",
},
}
