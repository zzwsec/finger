
-- pm.TbBiInternalEventTowerSweep



return
{
[1] = 
{
	id=1,
	field="layer_id",
	name="停留层数",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="layer_num",
	name="扫荡层数",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="buff",
	name="buff",
	type=1,
	opt=1,
	default_value="",
},
}
