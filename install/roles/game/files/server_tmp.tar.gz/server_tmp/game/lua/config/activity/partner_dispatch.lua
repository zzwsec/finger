
-- pm.TbPartnerDispatch



return
{
[1] = 
{
	id=1,
	desc={key='partner_dispatch/1',text="初级情报"},
	weight=7000,
	cost=
	{
		id=78,
		num=1,
	},
	partner_num=1,
	score_reward=
	{
		id=79,
		num=500,
	},
	rewards=
	{
	
		{
			id=67,
			num=1,
		},
	
		{
			id=3,
			num=10,
		},
	},
},
[2] = 
{
	id=2,
	desc={key='partner_dispatch/2',text="中级情报"},
	weight=2500,
	cost=
	{
		id=78,
		num=2,
	},
	partner_num=2,
	score_reward=
	{
		id=79,
		num=1500,
	},
	rewards=
	{
	
		{
			id=67,
			num=3,
		},
	
		{
			id=3,
			num=20,
		},
	},
},
[3] = 
{
	id=3,
	desc={key='partner_dispatch/3',text="高级情报"},
	weight=500,
	cost=
	{
		id=78,
		num=3,
	},
	partner_num=3,
	score_reward=
	{
		id=79,
		num=3000,
	},
	rewards=
	{
	
		{
			id=67,
			num=5,
		},
	
		{
			id=3,
			num=30,
		},
	},
},
}
