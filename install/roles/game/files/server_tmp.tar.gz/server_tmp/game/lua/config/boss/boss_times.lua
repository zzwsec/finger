
-- pm.TbBossTimes



return
{
[1] = 
{
	id=1,
	date=0,
	times=3,
	max_times=3,
},
[2] = 
{
	id=2,
	date=12,
	times=1,
	max_times=3,
},
[3] = 
{
	id=3,
	date=18,
	times=1,
	max_times=3,
},
}
