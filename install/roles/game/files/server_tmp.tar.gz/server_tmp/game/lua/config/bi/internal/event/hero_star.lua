
-- pm.TbBiInternalEventHeroStar



return
{
[1] = 
{
	id=1,
	field="hero_id",
	name="佣兵id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="old_star",
	name="佣兵老星级",
	type=0,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="new_star",
	name="佣兵新星级",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="cost_info",
	name="升星消耗",
	type=1,
	opt=1,
	default_value="",
},
}
