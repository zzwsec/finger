local class = require "utils.class"
local Constants = require "core.Constants"

local Composite = require 'core.Composite'

local MemPriority = class("MemPriority", Composite)

function MemPriority:ctor()
    Composite.ctor(self)

    self.name = "MemPriority"
end

function MemPriority:open(tick)
    tick.blackboard:set("i", 1, tick.tree.id, self.id)
end

function MemPriority:tick(tick)
    local i = tick.blackboard:get("i", tick.tree.id, self.id)
    while i <= #self.children do
        local v = self.children[i]
        local status = v:_execute(tick)
        if status ~= Constants.FAILURE then
            if status == Constants.RUNNING then
                tick.blackboard:set("i", i, tick.tree.id, self.id)
            end
            return status
        end
        i = i + 1
    end
    
    return Constants.FAILURE
end

return MemPriority