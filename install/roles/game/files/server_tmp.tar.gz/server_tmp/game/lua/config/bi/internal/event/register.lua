
-- pm.TbBiInternalEventRegister



return
{
[1] = 
{
	id=1,
	field="account_id",
	name="账号id",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="cdkey",
	name="cdkey",
	type=1,
	opt=1,
	default_value="",
},
[3] = 
{
	id=3,
	field="channel",
	name="渠道",
	type=0,
	opt=1,
	default_value="",
},
[4] = 
{
	id=4,
	field="platform",
	name="平台",
	type=0,
	opt=1,
	default_value="",
},
[5] = 
{
	id=5,
	field="device",
	name="设备",
	type=1,
	opt=1,
	default_value="",
},
[6] = 
{
	id=6,
	field="device_id",
	name="设备id",
	type=1,
	opt=1,
	default_value="",
},
[7] = 
{
	id=7,
	field="ip",
	name="ip",
	type=1,
	opt=1,
	default_value="",
},
}
