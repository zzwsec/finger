
-- pm.TbBiKingnetEventPetBag



return
{
[1] = 
{
	id=1,
	field="config_id",
	name="背包位置",
	type=0,
	opt=1,
	default_value="",
},
[2] = 
{
	id=2,
	field="item_id",
	name="消耗道具id",
	type=0,
	opt=1,
	default_value="",
},
}
